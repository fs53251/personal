package hr.fer.oprpp1.custom.collections;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CollectionLinkedAndArrayTest {
	@Test
	public void testAlociranjeDefaultKonstrukora() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection();
		assertEquals(16, aic.capacity());
	}
	
	@Test
	public void testKonstruktorPrimaInicijalnuVrijednost() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(20);
		assertEquals(20,aic.capacity());
	}
	
	@Test
	public void testKonstruktorPrimaInicijalnuVrijednostManjuOd1() {
		assertThrows(IllegalArgumentException.class, ()->new ArrayIndexedCollection(0));
	}
	
	@Test
	public void testKonstruktorPrimaNullKolekciju() {
		assertThrows(NullPointerException.class, ()->new ArrayIndexedCollection(null));
	}
	
	@Test
	public void testKonstruktorPrimaNullKolekcijuIInicVrijednost() {
		assertThrows(NullPointerException.class, ()->new ArrayIndexedCollection(null,20));
	}
	
	//add
	@Test
	public void testAddThrowsNullArray() {
		AddThrowsNull(new ArrayIndexedCollection());
	}
	
	@Test
	public void testAddThrowsNullLinked() {
		AddThrowsNull(new LinkedListIndexedCollection());
	}
	
	public void AddThrowsNull(Collection c) {
		assertThrows(NullPointerException.class, ()->c.add(null));
	}
	
	
	@Test
	public void testArrayIsReallocatedAndDoubledWhenFull() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(2);
		aic.add(1);
		aic.add(2);
		aic.add(3);
		assertEquals(4,aic.capacity());
	}
	
	@Test
	public void testStvaraSeReferencaNaPrvoPraznoMjesto() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(2);
		aic.add(1);
		assertEquals(0,aic.indexOf(1));
	}
	
	@Test
	public void testGetIznimkaZaPremaliIndex() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(2);
		assertThrows(IndexOutOfBoundsException.class, ()->aic.get(-1));
	}
	
	@Test
	public void testGetIznimkaZaPrevelikiIndex() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(2);
		assertThrows(IndexOutOfBoundsException.class, ()->aic.get(100));
	}
	
	@Test
	public void testVratiElementNaIndexu() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		aic.add(100);
		aic.add(200);
		aic.add(300);
		assertEquals(200, aic.get(1));
	}
	
	//clear
	@Test
	public void testMaknutiElementiArray() {
		MaknutiElementiKolekcije(new ArrayIndexedCollection(5));
	}
	
	@Test
	public void testMaknutiElementiLinked() {
		MaknutiElementiKolekcije(new LinkedListIndexedCollection());
	}
	
	public void MaknutiElementiKolekcije(Collection c) {
		c.add(100);
		c.add(200);
		c.add(300);
		c.clear();
		assertEquals(0,c.size());
	}
	
	@Test
	public void MetodaClearNeMijenjaKapacitetArray() {
		MetodaClearNeMijenjaKapacitet(new ArrayIndexedCollection());
	}
	
	public void MetodaClearNeMijenjaKapacitet(Collection c) {
		c.add(100);
		c.add(200);
		c.add(300);
		int kapac=c.capacity();
		c.clear();
		assertEquals(kapac, c.capacity());
	}
	
	@Test
	public void testInsertPremalaPozicija() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		assertThrows(IndexOutOfBoundsException.class, ()->aic.insert(1, -1));
	}
	
	@Test
	public void testInsertPrevelikaPozicija() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		assertThrows(IndexOutOfBoundsException.class, ()->aic.insert(1, 7));
	}
	
	@Test
	public void testInsertNullPredan() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		assertThrows(NullPointerException.class, ()->aic.insert(null, 0));
	}
	
	@Test
	public void testInsertPovecavaBrojElemenata() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		aic.insert(1, 0);
		assertEquals(1, aic.size());
	}
	
	@Test
	public void testMetodiIndexOfPredamoNull(){
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		assertEquals(-1,aic.indexOf(null));
	}
	
	@Test
	public void testIndexOfVracaMinusJedanAkoNeNade() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		aic.add(100);
		aic.add(200);
		assertEquals(-1,aic.indexOf(300));
	}
	
	@Test
	public void testIndexOfVracaPrviElementNaden() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		aic.add(100);
		aic.add(200);
		aic.add(100);
		assertEquals(0,aic.indexOf(100));
	}
	
	@Test
	public void testRemovePremalaPozicija() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		assertThrows(IndexOutOfBoundsException.class, ()->aic.remove(-1));
	}
	
	@Test
	public void testRemovePrevelikaPozicija() {
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		assertThrows(IndexOutOfBoundsException.class, ()->aic.remove(6));
	}
	
	@Test
	public void testRemoveMiceElement(){
		ArrayIndexedCollection aic=new ArrayIndexedCollection(5);
		aic.add(100);
		aic.add(200);
		aic.add(100);
		aic.remove(0);
		assertEquals(2, aic.size());
	}
	
	@Test
	public void testLinkedDefaultKonstruktor() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertEquals(ll.first,null);
		assertEquals(ll.last, null);
	}
	
	@Test
	public void testLinkedReferencaKonstruktor() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		ll.add(1);
		LinkedListIndexedCollection ll2=new LinkedListIndexedCollection(ll);
		assertEquals(1, ll2.size());
	}
	
	@Test
	public void testGetIznimkaZaPremaliIndexLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertThrows(IndexOutOfBoundsException.class, ()->ll.get(-1));
	}
	
	@Test
	public void testGetIznimkaZaPrevelikiIndexLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertThrows(IndexOutOfBoundsException.class, ()->ll.get(1));
	}
	
	@Test
	public void testVratiElementNaIndexuLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		ll.add(100);
		ll.add(200);
		ll.add(300);
		assertEquals(200, ll.get(1));
	}
	
	@Test
	public void testInsertIznimkaZaPremaliIndexLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertThrows(IndexOutOfBoundsException.class,()->ll.insert(1, -1));
	}
	
	@Test
	public void testInsertIznimkaZaPrevelikIndexLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertThrows(IndexOutOfBoundsException.class,()->ll.insert(1,2));
	}
	
	@Test
	public void testNullExceptionLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertThrows(NullPointerException.class,()->ll.insert(null,0));
	}
	
	
	@Test
	public void testIndexOfLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertEquals(-1,ll.indexOf(null));
	}
	
	@Test
	public void testIndexOfNotFoundLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		ll.add(1);
		ll.add(2);
		assertEquals(-1,ll.indexOf(3));
	}
	
	@Test
	public void testIndexOfPrvaPojavaLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		ll.add(1);
		ll.add(2);
		ll.add(1);
		assertEquals(0, ll.indexOf(1));
	}
	
	@Test
	public void testPremaliIndexRemoveLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertThrows(IndexOutOfBoundsException.class, ()->ll.remove(-1));
	}
	
	@Test
	public void testPrevelikiIndexRemoveLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		assertThrows(IndexOutOfBoundsException.class, ()->ll.remove(3));
	}
	
	@Test
	public void testSanjiElementRemoveLinked() {
		LinkedListIndexedCollection ll=new LinkedListIndexedCollection();
		ll.add(1);
		ll.add(2);
		ll.add(1);
		ll.remove(0);
		assertEquals(2, ll.size());
	}
}


















