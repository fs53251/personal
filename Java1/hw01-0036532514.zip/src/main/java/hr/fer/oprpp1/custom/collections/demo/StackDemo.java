package hr.fer.oprpp1.custom.collections.demo;
import hr.fer.oprpp1.custom.collections.ObjectStack;

public class StackDemo {
	public static void main(String[] args) {
		String[] ls=args[0].split(" ");
		ObjectStack stack=new ObjectStack();
		for(int i=0; i<ls.length; i++) {
			String element=ls[i].trim();
			if(element.equals("+") || element.equals("-") || element.equals("/")
		     ||element.equals("*") || element.equals("%")) {
				Integer br1=(Integer)stack.pop();
				Integer br2=(Integer)stack.pop();
				
				if(element.equals("+")) stack.push((Object)(br1+br2));
				if(element.equals("-")) stack.push((Object)(br2-br1));
				
				if(element.equals("/")) {
					if (br2==0) {
						System.out.println("Can't divide by 0.");
						break;
					}
					stack.push((Object)(br2/br1));
				}
				
				if(element.equals("*")) stack.push((Object)(br1*br2));
				if(element.equals("%")) stack.push((Object)(br2%br1));
			}else {
				stack.push((Object)Integer.parseInt(element));
			}
		}
		
		if(stack.size()!=1) {
			System.out.println("Wrong expression");
		}else {
			System.out.println((Integer)stack.pop());
		}
	}
}
