package hr.fer.oprpp1.custom.collections;

/**
 * Razred <code>Proccesor</code>.
 * Ima praznu metodu process koju treba nadjačati u izvedenim klasama.
 * 
 * @author Filip
 *
 */
public class Processor {
	/**
	 * Prazna metoda process
	 * @param value objekt koji prima kao argument
	 */
	public void process(Object value) {
		
	}
}
