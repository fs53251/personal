package hr.fer.oprpp1.custom.collections;

/**
 * Razred <code>Collection</code> korisnicima daje
 * osnovne metode za rad s kolekcijom. Ovdje je većina metoda 
 * prazna, stoga se očekuje da ih druge klase nadjačaju.
 * @author Filip
 *
 */
public class Collection {
	protected Collection() {
		
	}
	
	/**
	 * Metoda provjerava je li kolekcija prazna.
	 * 
	 * @return <code>true</code> ako je kolekcija prazna;
	 * 		   <code>false</code> inače.
	 */
	public boolean isEmpty() {
		return this.size()==0? true: false;
	}
	
	/**
	 * Metoda uvijek vraća veličinu kolekcije 0.
	 * @return 0
	 */
	public int size() {
		return 0;
	}
	
	/**
	 * Prazna metoda za dodavanje objekta u kolekciju.
	 * 
	 * @param value objekt koji treba dodati u kolekciju.
	 */
	public void add(Object value) {
	}
	
	/**
	 * Metoda provjerava sadrži li kolekcija traženi objekt.
	 * Ovdje samo vraća false.
	 * 
	 * @param value objekt za koji prvjeravamo nalazi li se u kolekciji
	 * @return false
	 */
	public boolean contains(Object value) {
		return false;
	}
	
	/**
	 * Metoda vadi objekt, predan kao argument, iz kolekcije.
	 * Ovdje samo vraća false;
	 * 
	 * @param value objekt koji treba izbaciti.
	 * @return false
	 */
	public boolean remove(Object value) {
		return false;
	}
	
	/**
	 * Metoda koja vraća reprezentaciju kolekcije kao polje.
	 * Ovdje baca iznimku.
	 * 
	 * @return
	 * @throws UnsupportedClassVersionError
	 */
	public Object[] toArray() {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Metoda koja prolazi po svim objektima kolekcije i nad njima 
	 * poziva metodu process(). Ovdje je prazna metoda.
	 * 
	 * @param processor referenca na instancu klasse Processor
	 */
	public void forEach(Processor processor) {
		
	}
	
	
	/**
	 * Metoda koja prima referencu na kolekciju i sve njene elemente dodaje u trenutnu kolekciju.
	 * 
	 * @param other referenca na kolekciju čije elemente treba dodati
	 */
	public void addAll(Collection other) {
		/**
		 * * Razred <code>AddToCollectionProcessor</code> nasljeđuje Processor.
		 *
		 * @author Filip
		 *
		 */
		class AddToCollectionProcessor extends Processor{
			/**
			 * Metoda dodaje objekt, predan kao argument, u kolekciju.
			 */
			public void process(Object value) {
				Collection.this.add(value);
			}
		}
		other.forEach(new AddToCollectionProcessor());
	}
	
	/**
	 * Metoda koja briše elemente kolekcije.
	 * Ovjde prazna metoda.
	 */
	public void clear() {
	}
	
	/**
	 * Metoda koja vraća kapacitet kolekcije.
	 * @return 0
	 */
	public int capacity() {
		return 0;
	}
	
}
