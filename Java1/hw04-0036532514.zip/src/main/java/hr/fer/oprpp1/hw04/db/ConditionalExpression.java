package hr.fer.oprpp1.hw04.db;

/**
 * Razred ConditionalExpression predstavlja jedan izraz u naredbi.
 * Izraz se sastoji od neke varijable, operatora i literala.
 * Razred nudi metode dohvata svih članskih varijabli.
 * @author Filip
 *
 */
public class ConditionalExpression {
	/**
	 * Varijabla koja čuva referencu na IFieldValueGetter.
	 * 
	 */
	IFieldValueGetter fvg;
	
	/**
	 * Varijabla koja čuva literal.
	 */
	String literal;
	
	/**
	 * Varijabla koja čuva referencu na IComparisonOperator.
	 */
	IComparisonOperator co;
	
	/**
	 * Konstruktor razreda.
	 * @param fvg referenca na objekt tipa IFieldValueGetter
	 * @param literal string koji čuva literal
	 * @param co referenca na objekt tipa IComparisonOperator
	 */
	public ConditionalExpression(IFieldValueGetter fvg, String literal, IComparisonOperator co) {
		super();
		this.fvg = fvg;
		this.literal = literal;
		this.co = co;
	}

	/**
	 * Getter članske varijable koja čuva referencu na IFieldValueGetter.
	 * @return referenca na IFieldValueGetter
	 */
	public IFieldValueGetter getFieldGetter() {
		return fvg;
	}
	
	/**
	 * Getter članske varijable koja čuva literal.
	 * @return literal
	 */
	public String getStringLiteral() {
		return literal;
	}
	
	/**
	 * Getter članske varijable koja čuva referencu na IComparisonOperator.
	 * @return referenca na IComparisonOperator
	 */
	public IComparisonOperator getComparisonOperator() {
		return co;
	}
	
	
}
