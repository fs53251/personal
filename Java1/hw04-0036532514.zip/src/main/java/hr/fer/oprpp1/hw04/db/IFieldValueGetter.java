package hr.fer.oprpp1.hw04.db;

/**
 * Sučelje koje nudi metodu get.
 * @author Filip
 *
 */
public interface IFieldValueGetter {
	
	/**
	 * Metoda predstavlja dohvat nekih podataka studenata. 
	 * Dohvat podataka ovisi o impelementaciji razreda koji implementira ovo sučelje.
	 * @param record objekt studenta
	 * @return string koji predstavlja neki podatak o studentu.
	 */
	public String get(StudentRecord record);
}
