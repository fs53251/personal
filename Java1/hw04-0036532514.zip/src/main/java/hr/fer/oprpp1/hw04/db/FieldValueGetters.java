package hr.fer.oprpp1.hw04.db;

/**
 * Razred ComparisonOperators nudi javne statičke varijable koje predstavljaju 
 * implementaciju dohvata imena, prezimena i jmbaga za nekog korisnika.
 * Varijable su tipa IFieldValueGetter.
 * @author Filip
 *
 */
public class FieldValueGetters{
	
	/**
	 * Varijabla koja predstavlja implementaciju metode get koja pripada 
	 * sučelju IFieldValueGetter. Prestavlja dohvat <code>imena<code>.
	 */
	public static final IFieldValueGetter FIRST_NAME=(s)->{
		return s.getFirstName();
	};
	
	/**
	 * Varijabla koja predstavlja implementaciju metode get koja pripada 
	 * sučelju IFieldValueGetter. Prestavlja dohvat <code>prezimena<code>.
	 */
	public static final IFieldValueGetter LAST_NAME=(s)->{
		return s.getLastName();
	}; 
	
	/**
	 * Varijabla koja predstavlja implementaciju metode get koja pripada 
	 * sučelju IFieldValueGetter. Prestavlja dohvat <code>jmbaga<code>.
	 */
	public static final IFieldValueGetter JMBAG=(s)->{
		return s.getJmbag();
	};

}
