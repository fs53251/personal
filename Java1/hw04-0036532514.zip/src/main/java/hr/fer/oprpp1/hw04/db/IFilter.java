package hr.fer.oprpp1.hw04.db;

/**
 * Sučelje koje nudi metodu accepts.
 * @author Filip
 *
 */
public interface IFilter {
	/**
	 * Metoda koja će za danog studenta odrediti je li on
	 * prihvaćen ili nije, ovisno o impelmentaciji razreda koji implementira
	 * ovo sučelje.
	 * @param record
	 * @return
	 */
	public boolean accepts(StudentRecord record);
}
