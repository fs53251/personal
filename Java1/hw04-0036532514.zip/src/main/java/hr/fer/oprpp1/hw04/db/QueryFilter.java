package hr.fer.oprpp1.hw04.db;

import java.util.List;

/**
 * Razred implementira sučelje IFilter i nudi filtriranje liste
 * izraza.
 * @author Filip
 *
 */
public class QueryFilter implements IFilter{
	/**
	 * Varijabla koja čuva refencu na polje izraza.
	 */
	List<ConditionalExpression> lista;
	
	/**
	 * Konstruktor
	 * @param lista polje izraza
	 */
	public QueryFilter(List<ConditionalExpression> lista) {
		this.lista=lista;
	}
	
	/**
	 * Nadjačana metoda accepts, za određenog studenta prolazi po 
	 * izrazima i ako ih zadovolji sve, vraća se <code>true<code>
	 *@return boolean <code>true<code> ako student zadovoljava sve izraze
	 *			      <code>false<code> inače.
	 */
	@Override
	public boolean accepts(StudentRecord record) {
		for (ConditionalExpression ce : lista) {
			if(!ce.getComparisonOperator().satisfied(
					ce.getFieldGetter().get(record),
					ce.getStringLiteral())){
				return false;
			}
		}
		return true;
	}

}
