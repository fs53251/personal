package hr.fer.oprpp1.hw04.db;

import java.util.ArrayList;
import java.util.List;

/**
 * Razred QueryParser predstavlja parsiranje i obradu izraza koje unosi korisnik ključnom 
 * riječi query.
 * 
 * @author Filip
 *
 */
public class QueryParser {
	/**
	 * Varijabla koja služi za rastavljanje složenog izraza u manje, jednostavnije.
	 */
	boolean isAllowed=true;
	
	/**
	 * Složeni izraz.
	 */
	String query;
	
	/**
	 * polje jednostavnih izraza dobiveno iz složenog izraza.
	 */
	List<String> queries;
	
	/**
	 * Konstruktor koji poziva metodu za parsiranje, setListOfQueries.
	 * @param query
	 */
	public QueryParser(String query) {
		this.query=query;
		this.queries=new ArrayList<String>();
		setListOfQueries();
	}
	
	/**
	 * Metoda provjerava je li složeni uvjet direktan.
	 * Složeni uvjet je direktan samo ako se sastoji od 
	 * jednog uvjeta koji počinje naredbom <code>jmbag=<code>
	 * @return <code>true<code> ako je složeni izraz direktan
	 * 		   <code>false<code> inače.
	 */
	public boolean isDirectQuery() {
		return queries.size()==1 && queries.get(0).startsWith("jmbag=\"");
	}
	
	/**
	 * Metoda iz direktnog izraza vraća literal koji predstavlja jmbag.
	 * @return String jmbag literal
	 */
	public String getQueriedJMBAG() {
		if(isDirectQuery()) {
			String jmbagLiteral=queries.get(0);
			return jmbagLiteral
					.substring(jmbagLiteral.indexOf("\"")+1,jmbagLiteral.lastIndexOf("\""));
		}
		throw new IllegalStateException();
	}
	
	/**
	 * Metoda prolazi po polju jednostavnih izraza i koristi ih za 
	 * stvaranje objekata tipa ConditionalExpression.
	 * @return polje objekata tipa ConditionalExpression
	 */
	public List<ConditionalExpression> getQuery(){
		List<ConditionalExpression> izrazi=new ArrayList<ConditionalExpression>();
		for (String string : queries) {
			int firstQuoteIndex=string.indexOf("\"");
			int lastQuoteIndex=string.lastIndexOf("\"");
			//rastaviti izraz na atribut+operator i litreal
			String atributLiteral=string.substring(0,firstQuoteIndex);
			String literal=string.substring(firstQuoteIndex+1,lastQuoteIndex);
			
			String varijabla;
			String operacija;
			if(atributLiteral.contains("LIKE")) {
				varijabla = atributLiteral.substring(0, atributLiteral.indexOf("LIKE"));
				operacija = atributLiteral.substring(atributLiteral.indexOf("LIKE"));
			}else {
				int i = 0;
				while(Character.isLetter(atributLiteral.charAt(i))) {
					i++;
				}
				
				varijabla = atributLiteral.substring(0, i);
				operacija = atributLiteral.substring(i);
			}
			
			IFieldValueGetter fieldValue=nadiFieldValueGetter(varijabla);
			IComparisonOperator comparisonOper=nadiComparisonOperator(operacija);
			
			izrazi.add(new ConditionalExpression(fieldValue, literal, comparisonOper));
		}
		return izrazi;
	}
	
	/**
	 * Metoda provjerava koji operator je upotebljen u izrazu.
	 * @param atributLiteral predani operator
	 * @return Pripadajući ComparisonOperator za predani operator
	 */
	private IComparisonOperator nadiComparisonOperator(String atributLiteral) {
		if(atributLiteral.contains("LIKE")) {
			return ComparisonOperators.LIKE;
		}else if(atributLiteral.equals("!=")) {
			return ComparisonOperators.NOT_EQUALS;
		}else if(atributLiteral.equals("<=")) {
			return ComparisonOperators.LESS_OR_EQUALS;
		}else if(atributLiteral.equals(">=")) {
			return ComparisonOperators.GREATER_OR_EQUALS;
		}else if(atributLiteral.equals("=")) {
			return ComparisonOperators.EQUALS;
		}else if(atributLiteral.equals("<")) {
			return ComparisonOperators.LESS;
		}else if(atributLiteral.equals(">")) {
			return ComparisonOperators.GREATER;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * Metoda provjerava koja varijabla je upotebljena u izrazu.
	 * @param atributLiteral predana varijabla
	 * @return Pripadajući FieldValueGetters za predanu varijablu
	 */
	private IFieldValueGetter nadiFieldValueGetter(String atributLiteral) {
		if(atributLiteral.equals("firstName")) {
			return FieldValueGetters.FIRST_NAME;
		}else if(atributLiteral.equals("lastName")) {
			return FieldValueGetters.LAST_NAME;
		}else if(atributLiteral.equals("jmbag")) {
			return FieldValueGetters.JMBAG;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * Metoda razdvaja složeni izraz na manje, jednostavnije
	 */
	private void setListOfQueries() {
		int start=0;
		int end=0;
		
		//razdvoji query na jednostavne izraze
		int i=1;
		while(i<query.length()-2){
			
			if(query.charAt(i)=='"') isAllowed=isAllowed?false:true;
			
			String potencijalni_and=query.substring(i,i+3);
			
			if(potencijalni_and.toLowerCase().equals("and") && isAllowed) {
				end=i;
				queries.add(makniRazmake(query.substring(start,end)));
				i+=2;
				start=i+1;
			}
			i++;
		}
		queries.add(makniRazmake(query.substring(start,query.length())));
	}
	
	/**
	 * Metoda uklanja nepotrebne bjeline i znakove.
	 * @param s string kojemu treba maknuti praznine
	 * @return novi string bez praznina
	 */
	private static String makniRazmake(String s) {
		if(s.contains("\"")){
			int firstQuoteIndex=s.indexOf('\"');
			int lastQuoteIndex=s.lastIndexOf('\"');
			return s.substring(0,firstQuoteIndex).replaceAll(" ", "")+
					s.substring(firstQuoteIndex,lastQuoteIndex+1)+
					s.substring(lastQuoteIndex+1).replaceAll(" ","");
		}
		return s;
	}
}
