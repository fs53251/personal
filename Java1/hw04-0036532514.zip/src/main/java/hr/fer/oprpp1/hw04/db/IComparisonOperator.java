package hr.fer.oprpp1.hw04.db;

/**
 * Sučelje koje nudi metodu satisfied.
 * @author Filip
 *
 */
public interface IComparisonOperator {
	
	/**
	 * Metoda koju je potrebno nadjačati. Vraća boolean ovisno o
	 * implementaciji metode u drugim razredima.
	 * @param value1 prvi string
	 * @param value2 drugi string
	 * @return boolean ovisno zadovoljavaju li predani stringovi
	 * 		   napisanu funkcionalnost
	 */
	public boolean satisfied(String value1, String value2);
}
