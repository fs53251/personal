package hr.fer.oprpp1.hw04.db;

/**
 * Razred ComparisonOperators nudi javne statičke varijable koje predstavljaju 
 * neke od operatora i definiraju njihovo ponašanje.
 * Varijable su tipa IComparisonOperator.
 * @author Filip
 *
 */
public class ComparisonOperators {
	
	/**
	 * Varijabla koja predstavlja implementaciju metode satisfied koja pripada 
	 * sučelju IComparisonOperators. Prestavlja operator <code>manje<code>.
	 */
	public static final IComparisonOperator LESS=(v1,v2)->{
		return v1.compareTo(v2)<0;
	};
	
	/**
	 * Varijabla koja predstavlja implementaciju metode satisfied koja pripada 
	 * sučelju IComparisonOperators. Prestavlja operator <code>manje ili jednako<code>.
	 */
	public static final IComparisonOperator LESS_OR_EQUALS=(v1,v2)->{
		return v1.compareTo(v2)<=0;
	};
	
	/**
	 * Varijabla koja predstavlja implementaciju metode satisfied koja pripada 
	 * sučelju IComparisonOperators. Prestavlja operator <code>veće<code>.
	 */
	public static final IComparisonOperator GREATER=(v1,v2)->{
		return v1.compareTo(v2)>0;
	};
	
	/**
	 * Varijabla koja predstavlja implementaciju metode satisfied koja pripada 
	 * sučelju IComparisonOperators. Prestavlja operator <code>veće ili jednako<code>.
	 */
	public static final IComparisonOperator GREATER_OR_EQUALS=(v1,v2)->{
		return v1.compareTo(v2)>=0;
	};
	
	/**
	 * Varijabla koja predstavlja implementaciju metode satisfied koja pripada 
	 * sučelju IComparisonOperators. Prestavlja operator <code>jednako<code>.
	 */
	public static final IComparisonOperator EQUALS=(v1,v2)->{
		return v1.equals(v2);
	};
	
	/**
	 * Varijabla koja predstavlja implementaciju metode satisfied koja pripada 
	 * sučelju IComparisonOperators. Prestavlja operator <code>različito<code>.
	 */
	public static final IComparisonOperator NOT_EQUALS=(v1,v2)->{
		return !v1.equals(v2);
	};
	
	/**
	 * Varijabla koja predstavlja implementaciju metode satisfied koja pripada 
	 * sučelju IComparisonOperators. Prestavlja operator <code>LIKE<code>.
	 * Provjerava valjanost predanog izraza.
	 */
	public static final IComparisonOperator LIKE=(v1,v2)->{
		if(v2 == "*") return true;
		
		String[] dijelovi=v2.split("\\*");
		
		//unos nema *
		if(!v2.contains("*")) return v1.equals(v2);
		
		//unos ima više *
		if(v2.indexOf("*")!=v2.lastIndexOf("*")) 
			throw new IllegalArgumentException("Smije biti unešena samo jedna *");
		
		//ako je * na kraju
		if(dijelovi.length==1) return v1.startsWith(dijelovi[0]);
		
		//ako je * na početku
		if(dijelovi[0].equals("")) return v1.endsWith(dijelovi[1]);
		
		//ako je * unutar striga
		return v1.startsWith(dijelovi[0]) && v1.substring(dijelovi[0].length()).endsWith(dijelovi[1]);
	};
	
}
