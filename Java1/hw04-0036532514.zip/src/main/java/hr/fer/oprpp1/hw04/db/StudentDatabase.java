package hr.fer.oprpp1.hw04.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Razred StudentDatabase predstavlja bazu podataka studenata.
 * 
 * @author Filip
 *
 */
public class StudentDatabase {
	/**
	 * Lista studenata
	 */
	List<StudentRecord> studenti=new ArrayList<StudentRecord>();
	
	/**
	 * Mapa koja čuva parove jmbag - student. Koristi se za dohvat studenta u 
	 * vremenu O(1). Predstavlja implementaciju indexa.
	 */
	Map<String, StudentRecord> jmbagIndex=new HashMap<String, StudentRecord>();

	/**
	 * Konstruktor koji je zadužen za punjenje baze
	 * @param unos polje zapisa o studentima
	 */
	public StudentDatabase(List<String> unos) {
		super();
		for (String string : unos) {
			//svaki string splitamo prema praznim mjestima
			String[] parametri=string.split("\\s+");
			
			String ime=parametri[parametri.length-2];
			
			String jmbag=parametri[0];
			
			String prezime="";
			for(int i=1; i<parametri.length-2; i++) {
				prezime+=parametri[i]+" ";
			}
			prezime=prezime.substring(0,prezime.length()-1);
			
			int ocjena=Integer.parseInt(parametri[parametri.length-1]);
			
			if(ocjena<1 || ocjena>5) 
				throw new IllegalArgumentException("Unesena kriva ocjena");
			
			StudentRecord student=new StudentRecord(jmbag, prezime, ime, ocjena);
			if(studenti.contains(student))
				throw new IllegalArgumentException("Unesen duplikat");
			
			studenti.add(student);
 		}
		for(StudentRecord sr: studenti) {
			jmbagIndex.put(String.valueOf(sr.getJmbag()),sr);
		}
	}
	
	/**
	 * Metoda za brz dohvat podatka o studentu preko jmbaga.
	 * @param jmbag predani jmbag nekog studenta
	 * @return referenca na objekt tipa StudentRecord
	 */
	public StudentRecord forJMBAG(String jmbag) {
		return jmbagIndex.get(jmbag);
	}
	
	/**
	 * Metoda koja prima implementaciju IFilter-a, prolazi po svim 
	 * studentim i izdvaja ih ako zadovoljavaju metodu accepts.
	 * @param filter implementacije sučelja IFilter
	 * @return
	 */
	public List<StudentRecord> filter(IFilter filter){
		List<StudentRecord> temp=new ArrayList<StudentRecord>();
		for (StudentRecord studentRecord : this.studenti) {
			if(filter.accepts(studentRecord)) temp.add(studentRecord);
		}
		return temp;
	}
}
