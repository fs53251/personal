package hr.fer.oprpp1.hw04.db;

import java.util.Objects;

/**
 * Razred StudentRecord predstavlja jednog studenta.
 * @author Filip
 *
 */
public class StudentRecord {
	/**
	 * Članska varijabla koja predstavlja jmbag studenta.
	 */
	private String jmbag;
	
	/**
	 * Članska varijabla koja predstavlja prezime studenta.
	 */
	private String lastName;
	
	/**
	 * Članska varijabla koja predstavlja ime studenta.
	 */
	private String firstName;
	
	/**
	 * Članska varijabla koja predstavlja konačnu ocjenu studenta.
	 */
	private int finalGrade;
	
	/**
	 * Konstruktor
	 * @param jmbag
	 * @param lastName
	 * @param firstName
	 * @param finalGrade
	 */
	public StudentRecord(String jmbag, String lastName, String firstName, int finalGrade) {
		super();
		this.jmbag = jmbag;
		this.lastName = lastName;
		this.firstName = firstName;
		this.finalGrade = finalGrade;
	}
	
	/**
	 * Getter jmbaga
	 * @return jmbag
	 */
	public String getJmbag() {
		return jmbag;
	}
	
	/**
	 * Getter prezimena
	 * @return prezime
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Getter imena
	 * @return ime
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Getter konačne ocjene
	 * @return konačna ocjena
	 */
	public int getFinalGrade() {
		return finalGrade;
	}

	/**
	 * Nadjačana metoda hashCode()
	 * Računa se hash preko vrijednosti jmbaga
	 */
	@Override
	public int hashCode() {
		return Objects.hash(jmbag);
	}
	
	/**
	 * Nadjačana metoda equals
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentRecord other = (StudentRecord) obj;
		return Objects.equals(jmbag, other.jmbag);
	}
	@Override
	public String toString() {
		return "StudentRecord [jmbag=" + jmbag + ", lastName=" + lastName + ", firstName=" + firstName + ", finalGrade="
				+ finalGrade + "]";
	}
	
	
}
