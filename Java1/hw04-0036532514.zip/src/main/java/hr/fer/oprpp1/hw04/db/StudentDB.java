package hr.fer.oprpp1.hw04.db;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

/**
 * Razred StudentDB je zadužen za unos i obradu izraza koje korinsik unosi.
 * @author Filip
 *
 */
public class StudentDB {
	
	/**
	 * Konstruktor koji dohvaća file sa zapisima studenata i obrađuje ih.
	 * Kotisti index tamo gdje je potreban i moguć.
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase db=new StudentDatabase(unos);
		
		Scanner sc=new Scanner(System.in);
		System.out.printf("%s ", ">");
		String query=sc.nextLine();
		query = ukloniQueryPrefiks(query);
		boolean prvaLinija = true;
		
		while(!query.equals("exit")) {
			try {
				QueryParser parser= new QueryParser(query);
				List<StudentRecord> list=db.filter(new QueryFilter(parser.getQuery()));
				int[] maxes = {0, 0, 0};
				parametri(maxes, list);
				
				int jmbagLength = maxes[0];
				int lastName = maxes[1];
				int firstName = maxes[2];
			
				if(parser.isDirectQuery()) {
					StudentRecord r = db.forJMBAG(parser.getQueriedJMBAG());
					String linija = linijaProizvoljneDuljine(jmbagLength, lastName, firstName);
					System.out.println("Using index for record retrieval.");
					System.out.println(linija);
					generiranjeRedova(jmbagLength, lastName, firstName, r);
					System.out.println(linija);
					System.out.println("Records selected: "+list.size());
				}else {
			
				int brojac = 0;
				String linija = "";
				for(StudentRecord r: db.filter(new QueryFilter(parser.getQuery()))) {
					brojac += 1;
	
					if(prvaLinija) {
						linija = linijaProizvoljneDuljine(jmbagLength, lastName, firstName);
						System.out.println(linija);
						prvaLinija = false;
					}
					generiranjeRedova(jmbagLength, lastName, firstName, r);
				}
				System.out.println(linija);
				System.out.println("Records selected:"+ brojac);
				}
			}catch(IllegalArgumentException e) {
				System.out.println("Query format is wrong. Try again!");
			}catch(NullPointerException e) {
				System.out.println("Records selected: 0");
			}
			prvaLinija = true;
			System.out.printf("%s ", ">");
			query=sc.nextLine();
			query = ukloniQueryPrefiks(query);
		}
		System.out.println("Goodbye!");
		sc.close();
	}	
	
	/**
	 * Metoda ispusuje liniju tablice, prema duljini podataka u njoj
	 * @param duljinaJmbaga duljina najduljeg jmbaga
	 * @param duljinaImena duljina najduljeg imena
	 * @param duljinaPrezimena duljina najduljeg prezimena
	 * @return string koji predstavlja liniju za dane podatke
	 */
	private static String linijaProizvoljneDuljine(int duljinaJmbaga, int duljinaImena, int duljinaPrezimena) {
		StringBuilder sb = new StringBuilder();
		sb.append(ispisiUzorak(duljinaJmbaga+=2));
		sb.append(ispisiUzorak(duljinaImena+=2));
		sb.append(ispisiUzorak(duljinaPrezimena+=2));
		sb.append("+===+");
		
		return sb.toString();
	}
	
	/**
	 * Metoda na temelju duljine uzorka, ispusuje sam uzorak.
	 * @param duljinaUzorka
	 * @return string uzorak
	 */
	private static String ispisiUzorak(int duljinaUzorka) {
		StringBuilder sb = new StringBuilder();
		sb.append("+");
		for(int i=0; i<duljinaUzorka; i++) {
			sb.append("=");
		}
		return sb.toString();
	}
	
	/**
	 * Metoda koja služi punjenju tablice podacima.
	 * @param jmbagLength najdulji jmbag
	 * @param lastNameLength najdulje ime
	 * @param firstNameLengti najdulje prezime
	 * @param r student
	 */
	private static void generiranjeRedova(int jmbagLength, int lastNameLength, int firstNameLengti, StudentRecord r) {
		System.out.printf("%s%s", "| ", r.getJmbag());
		int duljinaJmbaga = jmbagLength - r.getJmbag().length() + 1;
		for(int i=0; i < duljinaJmbaga; i++) {
			System.out.print(" ");
		}
			
		System.out.printf("%s%s", "| ", r.getLastName());
		int duljinaPrezimena = lastNameLength - r.getLastName().length() + 1;
		for(int i=0; i < duljinaPrezimena ;i++) {
			System.out.print(" ");
		}
		
		System.out.printf("%s%s", "| ", r.getFirstName());
		int duljinaImena = firstNameLengti - r.getFirstName().length() + 1;
		for(int i=0; i < duljinaImena; i++)
			System.out.print(" ");
		
		System.out.printf("%s%s%s\n","| ", r.getFinalGrade(), " |");
	}
	
	/**
	 * Metoda određuje najdulje podatke za svaku kolonu tablice
	 * @param maxes polje koje sadrži elemente najdulji jmbag, najdulje ime, najdulje prezime
	 * @param lista studenata
	 */
	private static void parametri(int[] maxes, List<StudentRecord> lista) {
			for(StudentRecord r: lista) {
				if(r.getJmbag().length()>maxes[0]) {
					maxes[0] = r.getJmbag().length();
				}
		
				if(r.getFirstName().length()>maxes[1])
					maxes[1] = r.getFirstName().length();

				if(r.getLastName().length()>maxes[2])
					maxes[2] = r.getLastName().length();
			}
	}
	
	/**
	 * Metoda uklanja query prefiks koju korisnik unosi
	 * @param query
	 * @return string koji nema qurey na početku
	 */
	private static String ukloniQueryPrefiks(String query) {
		if(query.contains("query")) {
			int index = query.indexOf("query") + 5;
			while(query.charAt(index) == ' ') {
				index++;
			}
			return query.substring(index);
		}
		throw new IllegalArgumentException();
	}
}
