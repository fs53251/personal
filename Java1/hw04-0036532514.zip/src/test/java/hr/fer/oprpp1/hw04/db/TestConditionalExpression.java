package hr.fer.oprpp1.hw04.db;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestConditionalExpression {

	@Test
	public void testCondExpression() {
		IFieldValueGetter fieldValueGetter = FieldValueGetters.FIRST_NAME;
		String name = "Jovica";
		IComparisonOperator comparisonOperator = ComparisonOperators.EQUALS;
		
		ConditionalExpression expression = new ConditionalExpression(fieldValueGetter, name, comparisonOperator);
		
		StudentRecord student= new StudentRecord("1111111111", "Jovicic", "Jovica", 1);
	
		assertEquals(true, expression.getComparisonOperator()
				.satisfied(expression.getFieldGetter().get(student), expression.getStringLiteral()));
	}
	
	@Test
	public void testCondExpression2() {
		IFieldValueGetter fieldValueGetter = FieldValueGetters.LAST_NAME;
		String surname = "Jovicic";
		IComparisonOperator comparisonOperator = ComparisonOperators.EQUALS;
		
		ConditionalExpression expression = new ConditionalExpression(fieldValueGetter, surname, comparisonOperator);
		
		StudentRecord student= new StudentRecord("1111111111", "Jovicic", "Jovica", 1);
	
		assertEquals(true, expression.getComparisonOperator()
				.satisfied(expression.getFieldGetter().get(student), expression.getStringLiteral()));
	}
	
	@Test
	public void testCondExpression3() {
		IFieldValueGetter fieldValueGetter = FieldValueGetters.JMBAG;
		String literal = "1111111111";
		IComparisonOperator comparisonOperator = ComparisonOperators.EQUALS;
		
		ConditionalExpression expression = new ConditionalExpression(fieldValueGetter, literal, comparisonOperator);
		
		StudentRecord student= new StudentRecord("1111111111", "Jovicic", "Jovica", 1);
	
		assertEquals(true, expression.getComparisonOperator()
				.satisfied(expression.getFieldGetter().get(student), expression.getStringLiteral()));
	}
	
	@Test
	public void testCondExpression4() {
		IFieldValueGetter fieldValueGetter = FieldValueGetters.JMBAG;
		String literal = "1111111112";
		IComparisonOperator comparisonOperator = ComparisonOperators.NOT_EQUALS;
		
		ConditionalExpression expression = new ConditionalExpression(fieldValueGetter, literal, comparisonOperator);
		
		StudentRecord student= new StudentRecord("1111111111", "Jovicic", "Jovica", 1);
	
		assertEquals(true, expression.getComparisonOperator()
				.satisfied(expression.getFieldGetter().get(student), expression.getStringLiteral()));
	}
	
	@Test
	public void testCondExpression5() {
		IFieldValueGetter fieldValueGetter = FieldValueGetters.FIRST_NAME;
		String name = "Anto";
		IComparisonOperator comparisonOperator = ComparisonOperators.GREATER_OR_EQUALS;
		
		ConditionalExpression expression = new ConditionalExpression(fieldValueGetter, name, comparisonOperator);
		
		StudentRecord student= new StudentRecord("1111111111", "Jovicic", "Jovica", 1);
	
		assertEquals(true, expression.getComparisonOperator()
				.satisfied(expression.getFieldGetter().get(student), expression.getStringLiteral()));
	}
	
	@Test
	public void testCondExpression6() {
		IFieldValueGetter fieldValueGetter = FieldValueGetters.FIRST_NAME;
		String name = "Jo*";
		IComparisonOperator comparisonOperator = ComparisonOperators.LIKE;
		
		ConditionalExpression expression = new ConditionalExpression(fieldValueGetter, name, comparisonOperator);
		
		StudentRecord student= new StudentRecord("1111111111", "Jovicic", "Jovica", 1);
	
		assertEquals(true, expression.getComparisonOperator()
				.satisfied(expression.getFieldGetter().get(student), expression.getStringLiteral()));
	}
	
	@Test
	public void testCondExpression7() {
		IFieldValueGetter fieldValueGetter = FieldValueGetters.FIRST_NAME;
		String name = "Anto";
		IComparisonOperator comparisonOperator = ComparisonOperators.GREATER_OR_EQUALS;
		
		ConditionalExpression expression = new ConditionalExpression(fieldValueGetter, name, comparisonOperator);
		
		StudentRecord student= new StudentRecord("1111111111", "Jovicic", "Jovica", 1);
	
		assertEquals(true, expression.getComparisonOperator()
				.satisfied(expression.getFieldGetter().get(student), expression.getStringLiteral()));
	}
}