package hr.fer.oprpp1.hw04.db;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.junit.jupiter.api.Test;

public class TestQueryFilter {
	
	@Test
	public void testDirect() throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase db=new StudentDatabase(unos);
		String query = "jmbag = \"0000000003\"";
		QueryParser parser= new QueryParser(query);
		StudentRecord student = db.forJMBAG(parser.getQueriedJMBAG());
		
		assertEquals(true, parser.isDirectQuery());
	}
	
	@Test
	public void testDirect1() throws IOException {
		String query = "jmbag = \"0000000003\" AND lastName LIKE \"B*\"";
		QueryParser parser= new QueryParser(query);
		
		assertEquals(false, parser.isDirectQuery());
	}
	
	@Test
	public void testDirect2() throws IOException {
		String query = "jmbag < \"0000000003\"";
		QueryParser parser= new QueryParser(query);
		
		assertEquals(false, parser.isDirectQuery());
	}
	
	@Test
	public void testDirect3() throws IOException {
		String query = "jmbag != \"0000000003\"";
		QueryParser parser= new QueryParser(query);
		
		assertEquals(false, parser.isDirectQuery());
	}
	
	@Test
	public void testDirect4() throws IOException {
		String query = "jmbag LIKE \"00000*\"";
		QueryParser parser= new QueryParser(query);
		
		assertEquals(false, parser.isDirectQuery());	
	}
	
	@Test
	public void testDirect5() throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase db=new StudentDatabase(unos);
		String query = "jmbag = \"0000000003\"";
		QueryParser parser= new QueryParser(query);
		StudentRecord student = db.forJMBAG(parser.getQueriedJMBAG());
		
		assertEquals("0000000003", parser.getQueriedJMBAG());	
	}
	
	@Test
	public void testDirect6() throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase db=new StudentDatabase(unos);
		String query = "jmbag = \"0000000003\"";
		QueryParser parser= new QueryParser(query);
		StudentRecord student = db.forJMBAG(parser.getQueriedJMBAG());
		
		if(parser.isDirectQuery())
			 assertEquals("Bosnić", student.getLastName());	
	}
	
	@Test
	public void testDirect7() throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase db=new StudentDatabase(unos);
		String query = "jmbag = \"0000000003\"";
		QueryParser parser= new QueryParser(query);
		StudentRecord student = db.forJMBAG(parser.getQueriedJMBAG());
		
		if(parser.isDirectQuery())
			 assertEquals("Andrea", student.getFirstName());
	}
	
	@Test
	public void testDirect8() throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase db=new StudentDatabase(unos);
		String query = "jmbag = \"0000000003\"";
		QueryParser parser= new QueryParser(query);
		StudentRecord student = db.forJMBAG(parser.getQueriedJMBAG());
		
		if(parser.isDirectQuery())
			 assertEquals(4, student.getFinalGrade());
	}
	
	@Test
	public void testDirect9() throws IOException {
		String query = "jmbag = \"0000000003\" AND lastName LIKE \"L*\"";
		QueryParser parser= new QueryParser(query);
		
		assertEquals(false, parser.isDirectQuery());
	}
	
	@Test
	public void testDirect10() throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		Integer brojac = 0;
		StudentDatabase db=new StudentDatabase(unos);
		String query = "lastName LIKE \"B*\"";
		QueryParser parser= new QueryParser(query);
		
		for(StudentRecord student: db.filter(new QueryFilter(parser.getQuery()))) {
			brojac += 1;
		}
		
		assertEquals(4, brojac);
	}
	
	@Test
	public void testDirect11() throws IOException {
		String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		Integer brojac = 0;
		StudentDatabase db=new StudentDatabase(unos);
		String query = "jmbag = \"0000000003\" AND lastName LIKE \"B*\"";
		QueryParser parser= new QueryParser(query);
		
		for(StudentRecord student: db.filter(new QueryFilter(parser.getQuery()))) {
			brojac += 1;
		}
		
		assertEquals(1, brojac);
	}
}
