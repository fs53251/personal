package hr.fer.oprpp1.hw04.db;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestQueryParser {
	@Test
	public void testMethodQueriedJMBAG() {
		QueryParser parser= new QueryParser("jmbag=\"0000000003\"");
		assertEquals("0000000003", parser.getQueriedJMBAG());
	}
	
	@Test
	public void testException() {
		QueryParser parser= new QueryParser("jmbag > \"0000000003\"");
		assertThrows(IllegalStateException.class, ()->parser.getQueriedJMBAG());
	}
	
	@Test
	public void testException1() {
		assertThrows(IllegalArgumentException.class, ()->new QueryParser("jmbag==\"0036524183\"      ").getQuery());
	}
	
	@Test
	public void testException2() {
		assertThrows(IllegalArgumentException.class, ()->new QueryParser("jmbadfg=\"0000000003\"").getQuery());
		
	}
	
	@Test
	public void testException3() {
		assertThrows(IllegalArgumentException.class, ()->new QueryParser("jmbag!==\"0000000003\"").getQuery());
	}
	
	@Test
	public void testException4() {
		assertThrows(IllegalArgumentException.class, ()->new QueryParser("jmbag===\"0000000003\" ").getQuery());
	}
	
	@Test
	public void testException5() {
		assertThrows(IllegalArgumentException.class, ()->new QueryParser("jmbag=\"0000000003\" and fsName=\"Andrea\"").getQuery());
	}
}
