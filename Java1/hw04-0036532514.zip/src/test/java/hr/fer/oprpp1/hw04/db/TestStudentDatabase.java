package hr.fer.oprpp1.hw04.db;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.junit.jupiter.api.Test;

public class TestStudentDatabase {
	String file="C:\\Users\\Filip\\eclipse-workspace\\hw04-0036532514\\src\\main\\resources\\database.txt";
	private class FilterTrue implements IFilter{

		public boolean accepts(StudentRecord record) {
			return true;
		}
	}
	
	private class FilterFalse implements IFilter{
		
		public boolean accepts(StudentRecord record) {
			return false;
		}
	}
	
	@Test
	public void testFilterAll() throws IOException {
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase sb=new StudentDatabase(unos);
		assertEquals(sb.filter(new FilterTrue()).size(), unos.size());
	}
	
	@Test
	public void testFilterZero() throws IOException{
		List<String> unos=Files.readAllLines(
				Paths.get(file), 
				StandardCharsets.UTF_8);
		StudentDatabase sb=new StudentDatabase(unos);
		assertEquals(sb.filter(new FilterFalse()).size(), 0);
	}
	
	
}
