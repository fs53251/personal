package hr.fer.oprpp1.hw04.db;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestComparisonOperators {
	
	@Test
	public void testLESS() {
		IComparisonOperator operacija = ComparisonOperators.LESS;
		assertEquals(true, operacija.satisfied("Ante", "Branko"));
	}
	
	@Test
	public void testLESS1() {
		IComparisonOperator operacija = ComparisonOperators.LESS;
		assertEquals(false, operacija.satisfied("Branko", "Ante"));
	}
	
	@Test
	public void testLESS2() {
		IComparisonOperator operacija = ComparisonOperators.LESS;
		assertEquals(false, operacija.satisfied("Jovica", "Jovan"));
	}
	
	@Test
	public void testLessOrEquals() {
		IComparisonOperator operacija = ComparisonOperators.LESS_OR_EQUALS;
		assertEquals(false, operacija.satisfied("Branko", "Ante"));
	}
	
	@Test
	public void testLessOrEquals1() {
		IComparisonOperator operacija = ComparisonOperators.LESS_OR_EQUALS;
		assertEquals(true, operacija.satisfied("Jovica", "Jovica"));
	}
	
	@Test
	public void testLessOrEquals2() {
		IComparisonOperator operacija = ComparisonOperators.LESS_OR_EQUALS;
		assertEquals(true, operacija.satisfied("Ante", "Branka"));
	}
	
	@Test
	public void testGreaterOrEquals() {
		IComparisonOperator operacija = ComparisonOperators.GREATER;
		assertEquals(true, operacija.satisfied("Branko", "Antonijia"));
	}
	
	@Test
	public void testGreaterOrEquals1() {
		IComparisonOperator operacija = ComparisonOperators.GREATER;
		assertEquals(false, operacija.satisfied("Antonija", "Branko"));
	}
	
	@Test
	public void testGreaterOrEquals2() {
		IComparisonOperator operacija = ComparisonOperators.GREATER_OR_EQUALS;
		assertEquals(true, operacija.satisfied("Ana", "Ana"));
	}
	
	@Test
	public void testEQUALS2() {
		IComparisonOperator operacija = ComparisonOperators.EQUALS;
		assertEquals(false, operacija.satisfied("Jusuf", "Jovica"));
	}
	
	@Test
	public void testEQUALS() {
		IComparisonOperator operacija = ComparisonOperators.EQUALS;
		assertEquals(true, operacija.satisfied("Jusuf", "Jusuf"));
	}
	
	@Test
	public void testNotEQUALS() {
		IComparisonOperator operacija = ComparisonOperators.NOT_EQUALS;
		assertEquals(false, operacija.satisfied("Jovica", "Jovica"));
	}
	
	@Test
	public void testNotEQUALS1() {
		IComparisonOperator operacija = ComparisonOperators.NOT_EQUALS;
		assertEquals(true, operacija.satisfied("Jovica", "Marko"));
	}
	
	@Test
	public void testLIKE() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertThrows(IllegalArgumentException.class, ()->operacija.satisfied("PROVJERA", "P**"));
	}
	
	@Test
	public void testLIKE1() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertThrows(IllegalArgumentException.class, () -> operacija.satisfied("PROVJERA", "P***"));
	}
	
	@Test
	public void testLIKE2() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertThrows(IllegalArgumentException.class, () -> operacija.satisfied("Zagreb", "***"));
	}
	
	@Test
	public void testLIKE3() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertEquals(true, operacija.satisfied("Bilokoje", "*"));
	}
	
	@Test
	public void testLIKE4() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertEquals(true, operacija.satisfied("Provjera", "*vjera"));
	}
	
	@Test
	public void testLIKE5() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertTrue(operacija.satisfied("Provjereno", "Provje*"));
	}
	
	@Test
	public void testLIKE6() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertEquals(false, operacija.satisfied("LjubavJeNaSelu", "Darinka"));
	}
	
	@Test
	public void testLIKE7() {
		IComparisonOperator operacija = ComparisonOperators.LIKE;
		assertEquals(true, operacija.satisfied("LjubavJeNaSelu", "Ljubav*elu"));
	}
	
	
}
