package hr.fer.oprpp1.hw04.db;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class TestFieldValueGetters {
	@Test
	public void testGetter1() {
		StudentRecord student= new StudentRecord("1111111111", "Matijevic", "Mato", 1);
		assertEquals("Matijevic", FieldValueGetters.LAST_NAME.get(student));
	}
	
	@Test
	public void testGetter2() {
		StudentRecord student= new StudentRecord("1111111111", "Matijevic", "Mato", 1);
		assertEquals("Mato", FieldValueGetters.FIRST_NAME.get(student));
	}
	@Test
	public void testGetter3() {
		StudentRecord student= new StudentRecord("1111111111", "Matijevic", "Mato", 1);
		assertEquals("1111111111", FieldValueGetters.JMBAG.get(student));
	}
}
