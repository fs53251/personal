package hr.fer.oprpp1.custom.scripting.parser;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

import hr.fer.oprpp1.custom.scripting.nodes.*;
import hr.fer.oprpp1.custom.scripting.parser.SmartScriptParser;
import hr.fer.oprpp1.custom.scripting.parser.SmartScriptingParserException;


public class ParserLexerTest {
	private String readExample(int n) {
		  try(InputStream is = this.getClass().getClassLoader().getResourceAsStream("extra/primjer"+n+".txt")) {
		    if(is==null) throw new RuntimeException("Datoteka extra/primjer"+n+".txt je nedostupna.");
		    byte[] data = is.readAllBytes();
		    String text = new String(data, StandardCharsets.UTF_8);
		    return text;
		  } catch(IOException ex) {
		    throw new RuntimeException("Greška pri čitanju datoteke.", ex);
		  }
		}
	
	@Test
	public void testJedanTextNode() {
		String text=readExample(1);
		SmartScriptParser parser = new SmartScriptParser(text);
		DocumentNode dn=parser.getDocumentNode();
		assertEquals(1,dn.numberOfChildren());
		assertEquals(TextNode.class,dn.getChild(0).getClass());
	}
	
	@Test
	public void testJedanTextNode1() {
		String text=readExample(2);
		SmartScriptParser parser = new SmartScriptParser(text);
		DocumentNode dn=parser.getDocumentNode();
		assertEquals(1,dn.numberOfChildren());
		assertEquals(TextNode.class,dn.getChild(0).getClass());
	}
	
	@Test
	public void testJedanTextNode2() {
		String text=readExample(3);
		SmartScriptParser parser = new SmartScriptParser(text);
		DocumentNode dn=parser.getDocumentNode();
		assertEquals(1,dn.numberOfChildren());
		assertEquals(TextNode.class,dn.getChild(0).getClass());
	}
	
	@Test
	public void testIznimka() {
		String text=readExample(4);
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testIznimka1() {
		String text=readExample(5);
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void test2Elementa() {
		String text=readExample(6);
		SmartScriptParser parser = new SmartScriptParser(text);
		DocumentNode dn=parser.getDocumentNode();
		assertEquals(3,dn.numberOfChildren());
		assertEquals(TextNode.class,dn.getChild(0).getClass());
		assertEquals(EchoNode.class,dn.getChild(1).getClass());
		assertEquals(TextNode.class,dn.getChild(2).getClass());
	}
	
	@Test
	public void test2ElementaVerzija2() {
		String text=readExample(7);
		SmartScriptParser parser = new SmartScriptParser(text);
		DocumentNode dn=parser.getDocumentNode();
		assertEquals(3,dn.numberOfChildren());
		assertEquals(TextNode.class,dn.getChild(0).getClass());
		assertEquals(EchoNode.class,dn.getChild(1).getClass());
		assertEquals(TextNode.class,dn.getChild(2).getClass());
	}
	
	@Test
	public void testIznimka2() {
		String text=readExample(8);
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testIznimka3() {
		String text=readExample(9);
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testWrongFor() {
		String text="{$ FOR 3 1 10 1 $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testWrongFor1() {
		String text="{$ FOR * \"1\" -10 \"1\" $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testWrongFor2() {
		String text="{$ FOR year @sin 10 $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testWrongFor3() {
		String text="{$ FOR year 1 10 \"1\" \"10\" $} ";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testWrongFor4() {
		String text="{$ FOR year $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testWrongFor5() {
		String text="{$ FOR year 1 10 1 3 $} ";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidVariable() {
		String text="{$ FOR _a21 10 1 3 $} ";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidVariable1() {
		String text="{$ FOR 32 10 1 3 $} ";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidVariable2() {
		String text="{$ FOR 3s_ee 10 1 3 $} ";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidFunctionName() {
		String text="{$= @24 $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidFunctionName1() {
		String text="{$= @sf--f $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidOperator() {
		String text="{$= 2 && 3 $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidBackSlashUnutarTaga() {
		String text="{$= \\a $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidBackSlashIzvanTaga() {
		String text="\\a";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testInvalidForStruktura() {
		String text="{$ FOR i 1 10$}"
				+ "{$ END $}"
				+ "{& END &}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testEndBezFora() {
		String text="{$ END $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void KrivoZadanString() {
		String text="{$ \"Ovo je krivo zadan string $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testKrivoZadaneKonstante() {
		String text="{$ = 3.i $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testKrivoZadaneKonstante1() {
		String text="{$ = 3. $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
	
	@Test
	public void testKrivoZadaneKonstante2() {
		String text="{$ = 3._ $}";
		assertThrows(SmartScriptingParserException.class,()->new SmartScriptParser(text));
	}
}
