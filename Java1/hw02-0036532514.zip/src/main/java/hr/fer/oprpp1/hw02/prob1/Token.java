package hr.fer.oprpp1.hw02.prob1;

/**
 * Razred <code>Token</code> predstavlja leksičku jedinku.
 * 
 * @author Filip
 *
 */
public class Token {
	/**
	 * Varijabla koja čuva tip tokena.
	 */
	TokenType type;
	
	/**
	 * Varijabla koja čuva vrijednost tokena.
	 */
	Object value;
	
	/**
	 * Konstruktor
	 * 
	 * @param type tip tokena
	 * @param value vrijednost tokena
	 */
	public Token(TokenType type, Object value) {
		this.type=type;
		this.value=value;
	}
	
	/**
	 * Metoda getter privatne članske varijable value.
	 * 
	 * @return value vrijednost tokena
	 */
	public Object getValue() {
		return this.value;
	}
	
	/**
	 * Metoda getter privatne članske varijable type.
	 * 
	 * @return type tip tokena
	 */
	public TokenType getType() {
		return this.type;
	}
}
