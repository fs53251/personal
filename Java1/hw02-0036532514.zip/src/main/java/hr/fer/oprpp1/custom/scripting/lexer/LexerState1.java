package hr.fer.oprpp1.custom.scripting.lexer;
/**
 * Enumeracija <code>LexerState</code> koja predstavlja stanja lexera.
 * 
 * @author Filip
 *
 */
public enum LexerState1 {
	BASIC,
	EXTENDED
}
