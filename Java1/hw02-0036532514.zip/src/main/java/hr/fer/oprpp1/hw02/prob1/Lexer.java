package hr.fer.oprpp1.hw02.prob1;


/**
 * Razred <code>Lexer</code> predstavlja leksički analizator. Nad primljenim tekstom, radi grupiranje i
 * vraća leksičke jedinke (Tokene). 
 *
 * @author Filip
 *
 */
public class Lexer {
	/**
	 * Polje koje čuva cijeli ulaz leksičkog analizatora.
	 */
	private char[] data;
	
	/**
	 * Varijabla koja čuva leksičku jedinku (Token)
	 */
	private Token token;
	
	/**
	 * Cijeli broj koji prati početak neobrađenog ulaznog niza.
	 */
	private int currentIndex;
	
	/**
	 * Inicijalno stanje leksičkog analizatora.
	 */
	private LexerState l= LexerState.BASIC;
	
	
	/**
	 * Konstruktor
	 * 
	 * @param text ulaz leksičkog analizatora
	 */
	public Lexer(String text) {
		data=text.toCharArray();
	}
	
	/**
	 * Metoda kojom određujemo stanje leksičkog analizatora.
	 * 
	 * @param state stanje na koje postavljamo lexer.
	 * @throws NullPointerException vraća <code>null</code> ako je predano stanje null
	 */
	public void setState(LexerState state) {
		if(state==null) throw new NullPointerException();
		l=state;
	}
	
	/**
	 * Metoda koja vraća trenutni token koji je analiziran. Ne provodi novu analizu!
	 * 
	 * @return Token analizirani token
	 */
	public Token getToken() {
		return this.token;
	}
	
	
	/**
	 * Metoda koja grupira daljnje znakove ulaznog niza i stvara token (leksičku jedinku).
	 * 
	 * @return Token vraća novi token na temelju zakova ulaza
	 * @throws LexerException ako je na ulazu neispravna leksička jedinka
	 */
	public Token nextToken() {
		if(token!=null && token.getType()==TokenType.EOF)
			throw new LexerException("No tokens available.");
		
		skipBlanks();

		if(currentIndex>=data.length) {
			this.token=new Token(TokenType.EOF, null);
			return this.token;
		}
		
		
		if(l==LexerState.EXTENDED) {
			if(data[currentIndex]=='#'){
				this.setState(LexerState.BASIC);
				this.currentIndex++;
				return new Token(TokenType.SYMBOL, '#');
			}
			int startIndex=currentIndex;
			while(currentIndex<data.length && data[currentIndex]!=' ' && data[currentIndex]!='#') {
				currentIndex++;
			}
			int endIndex=currentIndex;
			String s=new String(data,startIndex, endIndex-startIndex);
			this.token=new Token(TokenType.WORD, s);
			return this.token;
			
		}else {
			
			
			boolean falseEscape=(currentIndex+1<data.length &&
					   Character.compare(data[currentIndex],'\\')==0 &&
					   !(Character.isDigit(data[currentIndex+1]) || 
						Character.compare(data[currentIndex+1], '\\')==0));
			if(falseEscape) throw new LexerException();
			
			boolean slovo=(currentIndex+1<data.length &&
						   Character.compare(data[currentIndex],'\\')==0 &&
						   (Character.isDigit(data[currentIndex+1]) || 
							Character.compare(data[currentIndex+1], '\\')==0));
			
			if(!Character.isDigit(data[currentIndex]) && !Character.isLetter(data[currentIndex]) && !slovo){
				Character c=data[currentIndex++];
				if(Character.compare(c, '\\')==0) throw new LexerException();
				this.token=new Token(TokenType.SYMBOL,c);
				
				if(c=='#') this.setState(l.EXTENDED);
				return this.token;
			}
		
			if(Character.isLetter(data[currentIndex]) || slovo) {
				if(slovo) currentIndex++;
				StringBuilder sb=new StringBuilder();
				sb.append(data[currentIndex++]);
				
				while(currentIndex<data.length && (Character.isLetter(data[currentIndex]) || 
												   (currentIndex+1<data.length &&
												   Character.compare(data[currentIndex],'\\')==0 &&
												   (Character.isDigit(data[currentIndex+1]) || 
													Character.compare(data[currentIndex+1], '\\')==0)))){
					
					if(currentIndex+1<data.length && Character.compare(data[currentIndex],'\\')==0){
						if(Character.isDigit(data[currentIndex+1]) || 
						   Character.compare(data[currentIndex+1], '\\')==0){
									currentIndex++;
						}else {
							throw new LexerException();
						}
					}
					sb.append(data[currentIndex++]);
				}
				String value=sb.toString();
				this.token= new Token(TokenType.WORD, value);
				return this.token;
			}
			
			if(Character.isDigit(data[currentIndex])) {
				StringBuilder sb=new StringBuilder();
				sb.append(data[currentIndex++]);
				while(currentIndex<data.length && Character.isDigit(data[currentIndex])) {
					sb.append(data[currentIndex++]);
				}
				String number=sb.toString();
				try {
					this.token= new Token(TokenType.NUMBER,Long.parseLong(number));
				} catch (NumberFormatException e) {
					throw new LexerException("Ulaz ne valja");
				}
			}
			return this.token;
		}
	}
	
	/**
	 * Metoda kojom preskačemo prazna mjesta, tabulatore, prelaske u novi red.
	 */
	private void skipBlanks() {
		while(currentIndex<data.length) {
			char c=data[currentIndex];
			if(c==' '  || c=='\t' || c=='\r' || c=='\n') {
				currentIndex++;
				continue;
			}
			break;
		}
	}
	
}
