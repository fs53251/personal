package hr.fer.oprpp1.hw02.prob1;

/**
 * Enumeracija <code>TokenType</code> pedstavlja sve moguće
 * tipove tokena koji se mogu pojaviti na ulazu.
 * 
 * @author Filip
 *
 */
public enum TokenType {
	EOF,
	WORD,
	NUMBER,
	SYMBOL
}
