package hr.fer.oprpp1.hw02.prob1;

/**
 * Razred <code>LexerException</code> predstavlja iznimku prilikom leksičke analize.
 * 
 * @author Filip
 *
 */
public class LexerException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default konstruktor
	 */
	public LexerException() {
	}
	
	/**
	 * Knstruktor koji prenosi poruku kao string.
	 * 
	 * @param poruka
	 */
	public LexerException(String poruka) {
		super(poruka);
	}
}
