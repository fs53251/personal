package hr.fer.oprpp1.hw02.prob1;

/**
 * Enumeracija <code>LexerState</code> koja predstavlja stanja lexera.
 * 
 * @author Filip
 *
 */
public enum LexerState {
	BASIC,
	EXTENDED
}
