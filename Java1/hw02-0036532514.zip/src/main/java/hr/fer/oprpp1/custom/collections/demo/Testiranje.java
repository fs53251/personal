package hr.fer.oprpp1.custom.collections.demo;
/**
 * Razred <code>Testiranje</code> za provedbu osnovnih testiranja nad
 * napisanim klasama i sučeljima.
 * 
 * @author Filip
 *
 */
public class Testiranje {
	public static void main(String[] args) {

	}
}
