package hr.fer.oprpp1.hw08.jnotepadpp.language;

public interface ILocalizationListener {
	void localizationChanged();
}
