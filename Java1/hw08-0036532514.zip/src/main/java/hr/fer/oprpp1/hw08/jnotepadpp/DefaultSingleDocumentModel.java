package hr.fer.oprpp1.hw08.jnotepadpp;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

public class DefaultSingleDocumentModel implements SingleDocumentModel{
	private Path documentPath; //null for new documents
	private Boolean documentModified = false;
	private JTextArea text;
	private Document doc;
	
	public DefaultSingleDocumentModel(Path filePath, String content) {
		this.documentPath = filePath;
		
		text = new JTextArea(content);
		this.doc = text.getDocument();
	
		registerListenerOnTextAreaDocumentModel();
	}
	
	public DefaultSingleDocumentModel() {
		this(null, "");
	}

	private List<SingleDocumentListener> observerCollection = new ArrayList<>();
	
	@Override
	public JTextArea getTextComponent() {
		return this.text;
	}

	@Override
	public Path getFilePath() {
		return this.documentPath;
	}

	@Override
	public void setFilePath(Path path) {
		notifyObservers(ObserverMethod.PATH);
		this.documentPath = path;
	}

	@Override
	public boolean isModified() {
		return this.documentModified;
	}

	@Override
	public void setModified(boolean modified) {
		notifyObservers(ObserverMethod.STATUS);
		this.documentModified = modified;
	}

	@Override
	public void addSingleDocumentListener(SingleDocumentListener l) {
		this.observerCollection.add(l);
	}

	@Override
	public void removeSingleDocumentListener(SingleDocumentListener l) {
		this.observerCollection.remove(l);
	}
	
	private void registerListenerOnTextAreaDocumentModel() {
		DocumentListener docListener = new DocumentListener() {

			@Override
			public void insertUpdate(DocumentEvent e) {
				DefaultSingleDocumentModel.this.setModified(true);
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				DefaultSingleDocumentModel.this.setModified(true);
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				DefaultSingleDocumentModel.this.setModified(true);
			}
		};
		
		this.doc.addDocumentListener(docListener);
	}
	
	private void notifyObservers(ObserverMethod method) {
		for(SingleDocumentListener listener : this.observerCollection) {
			if(method.equals(ObserverMethod.PATH)) {
				listener.documentFilePathUpdated(this);
			}else if(method.equals(ObserverMethod.STATUS)) {
				listener.documentModifyStatusUpdated(this);
			}
		}
	}
	
	enum ObserverMethod{
		PATH, STATUS
	}

}
