package hr.fer.oprpp1.hw08.jnotepadpp.language;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractLocalizationProvider implements ILocalizationProvider{
	
	private List<ILocalizationListener> observerCollection;
	
	public AbstractLocalizationProvider() {
		observerCollection = new ArrayList<>();
	}

	@Override
	public void addLocalizationListener(ILocalizationListener localizationListener) {
		if(localizationListener == null) {
			return;
		}
		observerCollection.add(localizationListener);
	}

	@Override
	public void removeLocalizationListener(ILocalizationListener localizationListener) {
		if(localizationListener == null) {
			return;
		}
		observerCollection.remove(localizationListener);
	}
	
	//notify all observers
	public void fire() {
		for(ILocalizationListener observer : observerCollection) {
			observer.localizationChanged();
		}
	}
}
