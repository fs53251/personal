package hr.fer.oprpp1.hw08.jnotepadpp;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

public class DefaultMultipleDocumentModel extends JTabbedPane implements MultipleDocumentModel{ 
	private static final long serialVersionUID = 1L;
	
	private List<SingleDocumentModel> singleDocumentList = new ArrayList<>();
	private SingleDocumentModel currentSingleDocument;
	private SingleDocumentModel oldSinglDocument;
	
	private List<MultipleDocumentListener> multipleObserverCollection = new ArrayList<>();
	
	public List<SingleDocumentModel> getSingleDocumentList() {
		return singleDocumentList;
	}

	public void setSingleDocumentList(List<SingleDocumentModel> singleDocumentList) {
		this.singleDocumentList = singleDocumentList;
	}

	@Override
	public Iterator<SingleDocumentModel> iterator() {
		return this.singleDocumentList.iterator();
	}

	@Override
	public JComponent getVisualComponent() {
		return this;
	}

	@Override
	public SingleDocumentModel createNewDocument() {
		
		DefaultSingleDocumentModel singleDocumentModel = new DefaultSingleDocumentModel();
		this.singleDocumentList.add(singleDocumentModel);
		
		this.oldSinglDocument = this.currentSingleDocument;
		this.currentSingleDocument = singleDocumentModel;
		notifyObservers(notify.ADDED);
		notifyObservers(notify.CHANGED);
		
		this.addTab("(unnamed)", new JScrollPane(singleDocumentModel.getTextComponent()));
		singleDocumentModel.setModified(true);
		this.setSelectedIndex(this.getIndexOfDocument(currentSingleDocument));
		
		return singleDocumentModel;
	}

	@Override
	public SingleDocumentModel getCurrentDocument() {
		return this.currentSingleDocument;
	}

	@Override
	public SingleDocumentModel loadDocument(Path path) {
		if(path == null) {
			throw new NullPointerException();
		}
		for(int i = 0; i < singleDocumentList.size(); i++) {
			SingleDocumentModel element = singleDocumentList.get(i);
			if(path.equals(element.getFilePath())) {
				this.setSelectedIndex(i);
				return element;
			}
		}
	
		if(!Files.isReadable(path)) {
			JOptionPane.showMessageDialog(
					this, 
					"Datoteka "+ path + " ne postoji!", 
					"Pogreška", 
					JOptionPane.ERROR_MESSAGE);
			return null;
		}
		byte[] okteti;
		try {
			okteti = Files.readAllBytes(path);
		} catch(Exception ex) {
			JOptionPane.showMessageDialog(
					this, 
					"Pogreška prilikom čitanja datoteke " + path +".", 
					"Pogreška", 
					JOptionPane.ERROR_MESSAGE);
			return null;
		}
		String tekst = new String(okteti, StandardCharsets.UTF_8);
		
		DefaultSingleDocumentModel loadedSingleDocumentModel = new DefaultSingleDocumentModel(path, tekst);
		this.oldSinglDocument = this.currentSingleDocument;
		this.currentSingleDocument = loadedSingleDocumentModel;
		singleDocumentList.add(currentSingleDocument);
		notifyObservers(notify.ADDED);
		notifyObservers(notify.CHANGED);
		
		String name = path.toAbsolutePath().getFileName().toString();
		if(name.contains("/")) {
			name = name.substring(name.lastIndexOf("/") + 1);
		}
	
		this.addTab(name, null ,new JScrollPane(loadedSingleDocumentModel.getTextComponent()), path.toAbsolutePath().toString());
		this.setSelectedIndex(this.getIndexOfDocument(currentSingleDocument));
		
		return loadedSingleDocumentModel;
	}

	@Override
	public void saveDocument(SingleDocumentModel model, Path newPath) {
		if(newPath == null) {
			if(model.getFilePath() != null) {
				newPath = model.getFilePath();
			}else {
				JFileChooser fc = new JFileChooser();
				fc.setDialogTitle("Open file");
				if(fc.showOpenDialog(this)!=JFileChooser.APPROVE_OPTION) {
					return;
				}
				File fileName = fc.getSelectedFile();
				Path filePath = fileName.toPath();
				newPath = filePath;
				model.setFilePath(newPath);
			}
		}else {
			model.setFilePath(newPath);
		}
		
		for(SingleDocumentModel m : singleDocumentList) {
			if(model.getFilePath() != null && m.getFilePath() != null && !m.equals(model) && model.getFilePath().equals(m.getFilePath())) {
				JOptionPane.showMessageDialog(this,
						"Another document with the same path is already open: " + m.getFilePath() + "\nPlease close it before opening the new one.",
						"Document Already Open", JOptionPane.WARNING_MESSAGE);
				model.setFilePath(null);
				return;
			}
		}
		
		byte[] podatci = model.getTextComponent().getText().getBytes();
		try {
			Files.write(newPath, podatci);
		} catch (IOException e1) {
			JOptionPane.showMessageDialog(
					this, 
					"Pogreška prilikom zapisivanja datoteke "+newPath.toFile().getAbsolutePath()+".\nPažnja: nije jasno u kojem je stanju datoteka na disku!", 
					"Pogreška", 
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		JOptionPane.showMessageDialog(
				this, 
				"Datoteka je snimljena.", 
				"Informacija", 
				JOptionPane.INFORMATION_MESSAGE);
		
		String name = newPath.toAbsolutePath().getFileName().toString();
		if(name.contains("/")) {
			name = name.substring(name.lastIndexOf("/") + 1);
		}
		this.setTitleAt(this.getSelectedIndex(), name);
		this.setToolTipTextAt(this.getIndexOfDocument(model), newPath.toString());
		
		model.setModified(false);
	}

	@Override
	public void closeDocument(SingleDocumentModel model) {
		this.singleDocumentList.remove(model);
		if(this.singleDocumentList.size() == 0) {
			this.currentSingleDocument = null;
			notifyObservers(notify.REMOVED);
		}else {
			this.oldSinglDocument = this.currentSingleDocument;
			this.currentSingleDocument = singleDocumentList.get(singleDocumentList.size() - 1);
			notifyObservers(notify.REMOVED);
			notifyObservers(notify.CHANGED);
		}
	}

	@Override
	public void addMultipleDocumentListener(MultipleDocumentListener l) {
		this.multipleObserverCollection.add(l);
	}

	@Override
	public void removeMultipleDocumentListener(MultipleDocumentListener l) {
		this.multipleObserverCollection.remove(l);
	}

	@Override
	public int getNumberOfDocuments() {
		return this.singleDocumentList.size();
	}

	@Override
	public SingleDocumentModel getDocument(int index) {
		if(singleDocumentList.size() == 0 || index < 0) {
			return null;
		}
		return this.singleDocumentList.get(index);
	}

	@Override
	public SingleDocumentModel findForPath(Path path) {
		for(SingleDocumentModel singleDocumentModel : this.singleDocumentList) {
			if(singleDocumentModel.getFilePath().equals(path)) {
				return singleDocumentModel;
			}
		}
		return null;
	}

	@Override
	public int getIndexOfDocument(SingleDocumentModel doc) {
		for(int i = 0; i < this.singleDocumentList.size(); i++) {
			if(this.singleDocumentList.get(i).equals(doc)) {
				return i;
			}
		}
		return -1;
	}
	
	public void changeCurrentModel(int index) {
		if(index == -1) {
			return;
		}

		SingleDocumentModel loadedSingleDocumentModel = this.singleDocumentList.get(index);
		
		this.oldSinglDocument = this.currentSingleDocument;
		this.currentSingleDocument = loadedSingleDocumentModel;
		notifyObservers(notify.CHANGED);
	}

	private void notifyObservers(notify n) {
		for(MultipleDocumentListener observer : this.multipleObserverCollection) {
			if(n.equals(notify.ADDED)) {
				observer.documentAdded(currentSingleDocument);
			}else if(n.equals(notify.CHANGED)) {
				observer.currentDocumentChanged(oldSinglDocument, currentSingleDocument);
			}else if(n.equals(notify.REMOVED)) {
				observer.documentRemoved(currentSingleDocument);
			}
		
		}
		
	}

}

enum notify {
	ADDED, CHANGED, REMOVED
}
