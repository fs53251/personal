package hr.fer.oprpp1.hw08.jnotepadpp.language;

public interface ILocalizationProvider {
	String getString(String key);
	String getLanguage();
	void addLocalizationListener(ILocalizationListener localizationListener);
	void removeLocalizationListener(ILocalizationListener localizationListener);
}
