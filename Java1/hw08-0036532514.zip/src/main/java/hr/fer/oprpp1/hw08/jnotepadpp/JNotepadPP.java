package hr.fer.oprpp1.hw08.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.nio.file.Path;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Caret;

import hr.fer.oprpp1.hw08.jnotepadpp.language.FormLocalizationProvider;
import hr.fer.oprpp1.hw08.jnotepadpp.language.ILocalizationListener;
import hr.fer.oprpp1.hw08.jnotepadpp.language.LocalizableAction;
import hr.fer.oprpp1.hw08.jnotepadpp.language.LocalizationProvider;

public class JNotepadPP extends JFrame{
	DefaultMultipleDocumentModel multipleModelDocument;
	private SingleDocumentModel currentDocumentModel;
	private JTextArea editor;
	private FormLocalizationProvider flp = new FormLocalizationProvider(LocalizationProvider.getInstance(), this);
	
	private JLabel lengthLabel;
	private JLabel textStats;
	
	private Locale locale = new Locale("en");
	private Collator collator = Collator.getInstance(locale);
	
	private int length;
	private int ln;
	private int col;
	private int sel;

	private static final long serialVersionUID = 1L;
	
	public JNotepadPP() {
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setLocation(0, 0);
		setTitle("JNotepad++");
		setSize(500, 500);
		initGUI();
	}
	
	private void initGUI() {
		this.getContentPane().setLayout(new BorderLayout());
		
		createActions();
		createMenus();
		createToolbars();
		
		JPanel contentStats = new JPanel(new BorderLayout());
		
		multipleModelDocument = new DefaultMultipleDocumentModel();
		contentStats.add(multipleModelDocument, BorderLayout.CENTER);
		
		JPanel stats = new JPanel(new GridLayout(0, 3));
		stats.setBorder(BorderFactory.createMatteBorder(2,0,0,0, Color.GRAY));
		stats.setPreferredSize(new Dimension(stats.getPreferredSize().width, 20));

		lengthLabel = new JLabel("length: 0");
		textStats = new JLabel("Ln:1   Col:1   Sel:0");
		textStats.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 1, Color.GRAY));
		ClockLabel clockLabel =new ClockLabel();
		new Thread(clockLabel).start();
		
		stats.add(lengthLabel);
		stats.add(textStats);
		stats.add(clockLabel);
		
		contentStats.add(stats, BorderLayout.PAGE_END);
		
		this.getContentPane().add(contentStats, BorderLayout.CENTER);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				JNotepadPP.this.exitApp();
			}
		});

		
		multipleModelDocument.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				int index = multipleModelDocument.getSelectedIndex();
				if(index == -1) {
					return;
				}
				multipleModelDocument.changeCurrentModel(index);
				SingleDocumentModel model = multipleModelDocument.getDocument(index);
				if(model == null || model.getFilePath() == null) {
					JNotepadPP.this.setTitle("(unnamed) - JNotepad++");
				}else {
					JNotepadPP.this.setTitle(multipleModelDocument.getDocument(index).getFilePath().toAbsolutePath().toString() + " - JNotepad++");
				}
				
			}
		});
		
		multipleModelDocument.addMultipleDocumentListener(new MultipleDocumentListener() {

			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				editor = currentModel.getTextComponent();
				Caret e = editor.getCaret();
				caretUpdate(e);
			}

			@Override
			public void documentAdded(SingleDocumentModel model) {
				currentDocumentModel = model;
				editor = currentDocumentModel.getTextComponent();
				
				editor.addCaretListener(new CaretListener() {

					@Override
					public void caretUpdate(CaretEvent e) {
						caretEventUpdate(e);
					}
					
				});
			}

			@Override
			public void documentRemoved(SingleDocumentModel model) {
				if(multipleModelDocument.getSingleDocumentList().size() == 0) {
					lengthLabel.setText("length: 0");
					textStats.setText("Ln:1   Col:1   Sel:0");
				}
				if(model != null) {
					editor = model.getTextComponent();
					Caret e = editor.getCaret();
					caretUpdate(e);
				}
			}
			
		});
		
		flp.addLocalizationListener(new ILocalizationListener() {

			@Override
			public void localizationChanged() {
				String language = LocalizationProvider.getInstance().getLanguage();
				locale = new Locale(language);
				collator = Collator.getInstance(locale);
			}
			
		});
	}
	
	private void caretEventUpdate(CaretEvent e) {
		editor = (JTextArea)e.getSource();
		
		int dot = e.getDot();
        int mark = e.getMark();
       
        ln = 1;
        col = 1;
        sel = Math.abs(dot - mark);
        length = editor.getText().length();
        try {
            ln = editor.getLineOfOffset(dot) + 1;
            col = dot - editor.getLineStartOffset(ln - 1) + 1;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        lengthLabel.setText(String.format("length: %d", length));
        textStats.setText(String.format("Ln:%d   Col:%d   Sel:%d", ln, col, sel));
	}
	
	private void caretUpdate(Caret e) {
		int dot = e.getDot();
        int mark = e.getMark();
       
        ln = 1;
        col = 1;
        sel = Math.abs(dot - mark);
        length = editor.getText().length();
        try {
            ln = editor.getLineOfOffset(dot) + 1;
            col = dot - editor.getLineStartOffset(ln - 1) + 1;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        lengthLabel.setText(String.format("length: %d", length));
        textStats.setText(String.format("Ln:%d   Col:%d   Sel:%d", ln, col, sel));
	}
	
	private void createMenus() {
		JMenuBar menuBar = new JMenuBar();
		
		JMenu fileMenu = new JMenu(file);
		menuBar.add(fileMenu);
		
		fileMenu.add(new JMenuItem(newBlankDocument));
		fileMenu.add(new JMenuItem(openExistingDocument));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(saveDocument));
		fileMenu.add(new JMenuItem(saveAsDocument));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(closeDocumentInTab));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(info));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(exitApplication));
		
		JMenu editText = new JMenu(edit);
		menuBar.add(editText);
		
		editText.add(new JMenuItem(cutText));
		editText.add(new JMenuItem(copyText));
		editText.add(new JMenuItem(pasteText));
		
		JMenu languageMenu = new JMenu(languages);
		menuBar.add(languageMenu);
		
		languageMenu.add(new JMenuItem(enLanguage));
		languageMenu.add(new JMenuItem(hrLanguage));
		languageMenu.add(new JMenuItem(deLanguage));
		
		JMenu caseCha = new JMenu(changeCase);
		menuBar.add(caseCha);
		
		caseCha.add(new JMenuItem(uppercase));
		caseCha.add(new JMenuItem(lowercase));
		caseCha.add(new JMenuItem(invert));
		
		JMenu sortMenu = new JMenu(sort);
		menuBar.add(sortMenu);
		
		sortMenu.add(new JMenuItem(asc));
		sortMenu.add(new JMenuItem(desc));
		sortMenu.add(new JMenuItem(unique));
		
		this.setJMenuBar(menuBar);
	}
	
	private void createToolbars() {
		JToolBar toolBar = new JToolBar("Alati");
		toolBar.setFloatable(true);
		
		toolBar.add(new JButton(newBlankDocument));
		toolBar.add(new JButton(openExistingDocument));
		toolBar.addSeparator();
		toolBar.add(new JButton(saveDocument));
		toolBar.add(new JButton(saveAsDocument));
		toolBar.addSeparator();
		toolBar.add(new JButton(closeDocumentInTab));
		toolBar.addSeparator();
		toolBar.add(new JButton(cutText));
		toolBar.add(new JButton(copyText));
		toolBar.add(new JButton(pasteText));
		toolBar.addSeparator();
		toolBar.add(new JButton(info));
		toolBar.add(new JButton(exitApplication));
		
		this.getContentPane().add(toolBar, BorderLayout.PAGE_START);
	}
	
	private void createActions() {
		newBlankDocument.putValue(Action.NAME, "New Blank Document");
		newBlankDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control n"));
		newBlankDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_N);;
		newBlankDocument.putValue(Action.SHORT_DESCRIPTION, "Open new blank document");
		
		openExistingDocument.putValue(Action.NAME, "Open");
		openExistingDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control o"));
		openExistingDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_O);
		openExistingDocument.putValue(Action.SHORT_DESCRIPTION, "Open existing document");
		
		saveDocument.putValue(Action.NAME, "Save");
		saveDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control s"));
		saveDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_S);
		saveDocument.putValue(Action.SHORT_DESCRIPTION, "Save document");
		
		saveAsDocument.putValue(Action.NAME, "Save As");
		saveAsDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control a"));
		saveAsDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_A);
		saveAsDocument.putValue(Action.SHORT_DESCRIPTION, "Save document for the first time");
		
		closeDocumentInTab.putValue(Action.NAME, "Close");
		closeDocumentInTab.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control l"));
		closeDocumentInTab.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_L);
		closeDocumentInTab.putValue(Action.SHORT_DESCRIPTION, "Close current document");
		
		cutText.putValue(Action.NAME, "Cut");
		cutText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control t"));
		cutText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_T);
		cutText.putValue(Action.SHORT_DESCRIPTION, "Cut selected text");
		
		copyText.putValue(Action.NAME, "Copy");
		copyText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control c"));
		copyText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		copyText.putValue(Action.SHORT_DESCRIPTION, "Copy selected text");
		
		pasteText.putValue(Action.NAME, "Paste");
		pasteText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control p"));
		pasteText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_P);
		pasteText.putValue(Action.SHORT_DESCRIPTION, "Paste from clipboard");
		
		info.putValue(Action.NAME, "Info");
		info.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control i"));
		info.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_I);
		info.putValue(Action.SHORT_DESCRIPTION, "Informations");
		
		
		exitApplication.putValue(Action.NAME, "Exit");
		exitApplication.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control e"));
		exitApplication.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_E);
		exitApplication.putValue(Action.SHORT_DESCRIPTION, "Exit Application");
		
		hrLanguage.putValue(Action.NAME, "Croatian");
		hrLanguage.putValue(Action.SHORT_DESCRIPTION, "Translate to Croatian");
		
		enLanguage.putValue(Action.NAME, "Croatian");
		enLanguage.putValue(Action.SHORT_DESCRIPTION, "Translate to Croatian");
		
		deLanguage.putValue(Action.NAME, "Croatian");
		deLanguage.putValue(Action.SHORT_DESCRIPTION, "Translate to Croatian");
		
		languages.putValue(Action.NAME, "Languages");
		
		edit.putValue(Action.NAME, "Edit");
		
		file.putValue(Action.NAME, "File");
		
		
		changeCase.putValue(Action.NAME, "Change Case");
		
		uppercase.putValue(Action.NAME, "Uppercase");
		uppercase.putValue(Action.SHORT_DESCRIPTION, "Convert selected text to uppercase");

		lowercase.putValue(Action.NAME, "Lowercase");
		lowercase.putValue(Action.SHORT_DESCRIPTION, "Convert selected text to lowercase");
		
		invert.putValue(Action.NAME, "Invert");
		invert.putValue(Action.SHORT_DESCRIPTION, "Invert selected text");

		sort.putValue(Action.NAME, "Sort");
		sort.putValue(Action.SHORT_DESCRIPTION, "Sort selected rows");
		
		asc.putValue(Action.NAME, "Ascending");
		asc.putValue(Action.SHORT_DESCRIPTION, "Sort ascending");
		
		desc.putValue(Action.NAME, "Descending");
		desc.putValue(Action.SHORT_DESCRIPTION, "Sort descending");
		
		unique.putValue(Action.NAME, "Unique");
		unique.putValue(Action.SHORT_DESCRIPTION, "Remove duplicate rows");

	}
	
	private Action newBlankDocument = new LocalizableAction("newBlank", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			JNotepadPP.this.multipleModelDocument.createNewDocument();
		}
	};
	
	private Action openExistingDocument = new LocalizableAction("open", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Open file");
			if(fc.showOpenDialog(JNotepadPP.this)!=JFileChooser.APPROVE_OPTION) {
				return;
			}
			File fileName = fc.getSelectedFile();
			Path filePath = fileName.toPath();
			
			JNotepadPP.this.multipleModelDocument.loadDocument(filePath);
			JNotepadPP.this.setTitle(filePath.toAbsolutePath() + " - JNotepad++");
		}
	};
	
	private Action saveDocument = new LocalizableAction("save", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null) return;
			Path newPath = model.getFilePath();
			
			JNotepadPP.this.multipleModelDocument.saveDocument(model, newPath);
		
			Path path = JNotepadPP.this.multipleModelDocument.getCurrentDocument().getFilePath();
			if(path != null) {
				JNotepadPP.this.setTitle(path.toString() + " - JNotepad++");
			}
			
		}
	};
	
	private Action saveAsDocument = new LocalizableAction("saveAs", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null) return;

			JNotepadPP.this.multipleModelDocument.saveDocument(model, null);
			String path = JNotepadPP.this.multipleModelDocument.getCurrentDocument().getFilePath().toString();
			JNotepadPP.this.setTitle(path + " - JNotepad++");
		}
	};
	
	private Action closeDocumentInTab = new LocalizableAction("close", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null) return;
			int index = JNotepadPP.this.multipleModelDocument.getIndexOfDocument(model);
			
			if(model.isModified()) {
				
				int choice = JOptionPane.showConfirmDialog(JNotepadPP.this, "Do you want to save changes before closing?", "Save Changes", JOptionPane.YES_NO_CANCEL_OPTION);
			        if (choice == JOptionPane.YES_OPTION) {
			        	Path newPath = model.getFilePath();
						JNotepadPP.this.multipleModelDocument.saveDocument(model, newPath);
						String path = JNotepadPP.this.multipleModelDocument.getCurrentDocument().getFilePath().toString();
						JNotepadPP.this.setTitle(path + " - JNotepad++");
			        } else if (choice == JOptionPane.NO_OPTION) {
			        	JNotepadPP.this.multipleModelDocument.closeDocument(model);
						if(JNotepadPP.this.multipleModelDocument.getSingleDocumentList().size() == 0) {
							JNotepadPP.this.setTitle("JNotepad++");
						}
						JNotepadPP.this.multipleModelDocument.removeTabAt(index);
			        } else if (choice == JOptionPane.CANCEL_OPTION) {
			           return;
			        }
				
			}else {
				JNotepadPP.this.multipleModelDocument.closeDocument(model);
				JNotepadPP.this.multipleModelDocument.removeTabAt(index);
			}
			
		}
	};
	
	private Action info = new LocalizableAction("info", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null) return;
			editor = model.getTextComponent();
			String content = editor.getText();
			
			StringBuilder sb = new StringBuilder();
			sb.append("Your document has ");
			sb.append(content.length());
			sb.append(" characters, ");
			sb.append(content.replaceAll("\\s+","").length());
			sb.append(" non-blank characters and ");
			sb.append(content.split("\n").length);
			sb.append(" lines");
			
			JOptionPane.showMessageDialog(null, sb.toString());
		}
	};
	
	private Action exitApplication = new LocalizableAction("exit", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			exitApp();
		}
	};
	
	private Action cutText = new LocalizableAction("cut", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null) return;
			
			model.getTextComponent().cut();
		}
	};
	
	private Action copyText = new LocalizableAction("copy", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null) return;

			model.getTextComponent().copy();
		
		}
	};
	
	private Action pasteText = new LocalizableAction("paste", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null) return;

			model.getTextComponent().paste();
		}
	};
	
	private Action hrLanguage = new LocalizableAction("hr", flp) {
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			LocalizationProvider.getInstance().setLanguage("hr");
		}
	};
	
	private Action enLanguage = new LocalizableAction("en", flp) {
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			LocalizationProvider.getInstance().setLanguage("en");
		}
	};
		
	private Action deLanguage = new LocalizableAction("de", flp) {
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			LocalizationProvider.getInstance().setLanguage("de");
		}	
	};
	
	private Action file = new LocalizableAction("file", flp) {
		private static final long serialVersionUID = 1L;
	};
	
	private Action languages = new LocalizableAction("languages", flp) {
		private static final long serialVersionUID = 1L;
	};
	
	private Action edit = new LocalizableAction("edit", flp) {
		private static final long serialVersionUID = 1L;
	};
	
	private Action changeCase = new LocalizableAction("changeCase", flp) {
		private static final long serialVersionUID = 1L;
	};
	
	private Action uppercase = new LocalizableAction("uppercase", flp) {
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null || model.getTextComponent() == null || editor.getSelectedText().equals("")) {
				return;
			}
			editor = model.getTextComponent();
			String result = editor.getText().replace(editor.getSelectedText(), editor.getSelectedText().toUpperCase());
			editor.setText(result);
		}	
	};
	
	private Action lowercase = new LocalizableAction("lowercase", flp) {
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null || model.getTextComponent() == null || editor.getSelectedText().equals("")) {
				return;
			}
			editor = model.getTextComponent();
			String result = editor.getText().replace(editor.getSelectedText(), editor.getSelectedText().toLowerCase());
			editor.setText(result);
		}
	};
	
	private Action invert = new LocalizableAction("invert", flp) {
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
			if(model == null || model.getTextComponent() == null || editor.getSelectedText().equals("")) {
				return;
			}
			editor = model.getTextComponent();
			String text = editor.getSelectedText();
			
			
			char[] chars = text.toCharArray();
			for(int i = 0; i < chars.length; i++) {
				char ch = chars[i];
				if(Character.isUpperCase(ch)) {
					chars[i] = Character.toLowerCase(ch);
				}else if(Character.isLowerCase(ch)){
					chars[i] = Character.toUpperCase(ch);
				}
			}
			
			editor.setText(editor.getText().replace(text, new String(chars)));
		}
	};
	
	private Action sort = new LocalizableAction("sort", flp) {
		private static final long serialVersionUID = 1L;
	};
	
	private Action asc = new LocalizableAction("asc", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			sort("asc");
		}
	};
	
	private Action desc = new LocalizableAction("desc", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			sort("desc");
		}
	};
	
	private Action unique = new LocalizableAction("unique", flp) {
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			sort("unique");
		}
	};
	
	private void exitApp() {
		Iterator<SingleDocumentModel> it = JNotepadPP.this.multipleModelDocument.iterator();
		while(it.hasNext()) {
			SingleDocumentModel model = it.next();
			JNotepadPP.this.multipleModelDocument.setSelectedIndex(JNotepadPP.this.multipleModelDocument.getIndexOfDocument(model));
			if(model.isModified()) {
				Object[] buttons = {"Save", "Discard", "Abort"};
				int n = JOptionPane.showOptionDialog(null,
					    "Do you want to save current document?",
					    "Save/Discard or abort",
					    JOptionPane.DEFAULT_OPTION,
					    JOptionPane.QUESTION_MESSAGE,
					    null,
					    buttons,
					    buttons[0]);
				if(n == 0) {
					JNotepadPP.this.multipleModelDocument.saveDocument(model, model.getFilePath());
				}else if(n == 2) {
					break;
				}
			}
			
		}
		JNotepadPP.this.dispose();
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new JNotepadPP().setVisible(true);
			}
			
		});
	}
	
	private class ClockLabel extends JLabel implements Runnable {
	    private static final long serialVersionUID = 1L;

		public ClockLabel() {
	        setHorizontalAlignment(JLabel.CENTER);
	    }

	    public void run() {
	        while (true) {
	            try {
	                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	                setText(dateFormat.format(new Date()));
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}
	
	private void sort(String sortType) {
		SingleDocumentModel model = JNotepadPP.this.multipleModelDocument.getCurrentDocument();
		if(model == null || model.getTextComponent() == null || editor.getSelectedText().equals("")) {
			return;
		}
		editor = model.getTextComponent();
		String allLines = editor.getText();
		
		if(editor.getSelectedText().equals("")) {
			return;
		}
		int selectionStart = editor.getSelectionStart();
		int selectionEnd = editor.getSelectionEnd();
		int endRow = 1;
		int startRow = 1;
		try {
			endRow = editor.getLineOfOffset(selectionEnd);
			startRow = editor.getLineOfOffset(selectionStart);
		} catch (BadLocationException e1) {
			e1.printStackTrace();
		}
		List<Integer> duplikati = new ArrayList<>();
		String[] editorContent = allLines.split("\n");
		for(int i = startRow; i < endRow; i++) {
			for(int j = i + 1; j <= endRow; j++) {
				if(sortType.equals("asc")) {
					if(collator.compare(editorContent[i], editorContent[j]) > 0) {
						String store = editorContent[i];
						editorContent[i] = editorContent[j];
						editorContent[j] = store;
					}
				}else if(sortType.equals("desc")) {
					if(collator.compare(editorContent[i], editorContent[j]) < 0) {
						String store = editorContent[i];
						editorContent[i] = editorContent[j];
						editorContent[j] = store;
					}
				}else if(sortType.equals("unique")) {
					if(editorContent[i].equals(editorContent[j])) {
						if(!duplikati.contains(Integer.valueOf(j))) {
							duplikati.add(Integer.valueOf(j));
						}
					}
				}
				
			}
		}
		
		if(sortType.equals("unique")) {
			StringBuilder sb = new StringBuilder();
			for(int i = 0; i < editorContent.length; i++) {
				if(!duplikati.contains(Integer.valueOf(i))) {
					sb.append(editorContent[i] + "\n");
				}
			}
			editor.setText(sb.toString());
		}else {

			StringBuilder sb = new StringBuilder();
			for(String l : editorContent) {
				sb.append(l + "\n");
			}
			editor.setText(sb.toString());
		}
		
	}
}
