package hr.fer.oprpp1.hw08.jnotepadpp.language;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class LocalizableAction extends AbstractAction{

	private static final long serialVersionUID = 1L;
	private ILocalizationListener listener;
	private ILocalizationProvider provider;
	
	private String translate;
	
	public LocalizableAction(String key, ILocalizationProvider lp) {
		this.provider = lp;
		translate = lp.getString(key);
		
		this.putValue(NAME, translate);
		
		this.putValue(SHORT_DESCRIPTION, lp.getString(key + "Desc"));
		
		this.listener = new ILocalizationListener() {
			
			@Override
			public void localizationChanged() {
				translate = lp.getString(key);
				LocalizableAction.this.putValue(NAME, translate);
				LocalizableAction.this.putValue(SHORT_DESCRIPTION, lp.getString(key + "Desc"));
			}
		};
		
		provider.addLocalizationListener(listener);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
	}

}
