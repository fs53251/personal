package hr.fer.oprpp1.hw08.jnotepadpp.language;

public class LocalizationProviderBridge extends AbstractLocalizationProvider{
	
	private ILocalizationProvider parent;
	private boolean connected;
	private String currentLanguage;
	private ILocalizationListener listener;
	
	public LocalizationProviderBridge(ILocalizationProvider localizationProvider) {
		this.parent = localizationProvider;
		this.listener = new ILocalizationListener() {

			@Override
			public void localizationChanged() {
				LocalizationProviderBridge.this.currentLanguage = parent.getLanguage();
				LocalizationProviderBridge.this.fire();
			}
			
		};
	}
	
	@Override
	public String getString(String key) {
		return parent.getString(key);
	}

	@Override
	public String getLanguage() {
		return currentLanguage;
	}
	
	public void connect() {
		if(connected) {
			return;
		}
		parent.addLocalizationListener(this.listener);
		
		if(!parent.getLanguage().equals(this.currentLanguage)) {
			this.currentLanguage = parent.getLanguage();
			this.fire();
		}
	}
	
	public void disconnect() {
		if(!connected) {
			return;
		}
		
		parent.removeLocalizationListener(listener);
	}
}
