package hr.fer.oprpp1.hw05.crypto;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

public class TestUtil {
	
	@Test
	public void testHexToByte() {
		assertEquals(true, Arrays.equals(Util.hextobyte("01aE22"),new byte[] {1, -82, 34}));
	}
	
	@Test
	public void testHexToByte1() {
		assertEquals(0, Util.hextobyte("").length);
	}
	
	//ne radi mi import assertThrows
//	@Test
//	public void testHexToByte2() {
//		assertThrows(IllegalStateException.class, Util.hextobyte(null));
//	}
	
	//ne radi mi import assertThrows
//		@Test
//	public void testHexToByte3() {
//		assertThrows(IllegalStateException.class, Util.hextobyte("%&$fd"));
//	}
	
	@Test
	public void testByteToHex() {
		assertEquals(true, Util.bytetohex(new byte[] {1, -82, 34}).equals("01ae22"));
	}
	
	//ne radi mi import assertThrows
//	@Test
//	public void testByteToHex1() {
//		assertThrows(IllegalStateException.class,Util.bytetohex(null));
//	}
	
	@Test
	public void testByteToHex2() {
		assertEquals("", Util.bytetohex(new byte[0]));
	}
}
