package hr.fer.oprpp1.hw05.shell;

import java.util.SortedMap;

/**
 * Ugovor koji daje formu preko koje komuniciramo s korisnikom.
 * Razred koji implementira ovo sučelje zna "razgovarati" s korisnikom
 * preko shell-a.
 * @author Filip
 *
 */
public interface Environment {
	/**
	 * Metoda koja čita liniju korisnikovog unosa.
	 * @return korisnikov unos
	 * @throws ShellIOException ako nije uspjelo čitanje
	 */
	String readLine() throws ShellIOException;
	
	/**
	 * Metoda piše dani tekst u shell. Ne stvara prelazak u novi red.
	 * @param text text koji se prikaže u shellu
	 * @throws ShellIOException ako nije uspjelo pisanje u shell
	 */
	void write(String text) throws ShellIOException;
	
	/**
	 * Metoda piše dani tekst u shell. Stvara prelazak u novi red.
	 * @param text text koji se prikaže u shellu
	 * @throws ShellIOException ako nije uspjelo pisanje u shell
	 */
	void writeln(String text) throws ShellIOException;
	
	/**
	 * Metoda vraća mapu implementiranih komandi u shell-u.
	 * @return
	 */
	SortedMap<String, ShellCommand> commands();
	
	/**
	 * Getter za simbol na početku više redova
	 * @return
	 */
	Character GetMultilineSymbol();
	
	/**
	 * Setter za simbol na početku više redova
	 * @param symbol
	 */
	void setMultilineSymbol(Character symbol);
	
	/**
	 * Getter za promt simbol
	 * @return
	 */
	Character getPromptSymbol();
	
	/**
	 * Setter za prompt simbol
	 * @param symbol
	 */
	void setPromptSymbol(Character symbol);
	
	/**
	 * Getter za pisanje više redova naredbe
	 * @return
	 */
	Character getMorelinesSymbol();
	
	/**
	 * Setter za pisanje više redova naredbe
	 * @param symbol
	 */
	void setMorelinesSymbol(Character symbol);
}
