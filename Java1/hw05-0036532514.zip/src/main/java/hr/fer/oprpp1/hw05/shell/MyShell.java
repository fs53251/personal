package hr.fer.oprpp1.hw05.shell;

import java.util.SortedMap;
import java.util.stream.IntStream;
/**
 * Razred pokreće i stvara implementaciju shell-a.
 * @author Filip
 *
 */
public class MyShell {
	/**
	 * Objekt koji zna razgovarati s korisnikom(instanca razreda koji implementira Environment).
	 */
	private static EnvironmentImpl env = new EnvironmentImpl();
	
	/**
	 * Mapa komandi koje su implementirane za rad u shell-u.
	 */
	private static SortedMap<String, ShellCommand> komande = env.commands();
	
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		env.writeln("Welcome to MyShell v 1.0");
		
		try {
			do {
				env.write(env.getPromptSymbol() + " ");
				
				String dohvatiPrompt = env.readLine().trim();
				if(!dohvatiPrompt.endsWith(env.getMorelinesSymbol().toString())){
					jednaLinija(dohvatiPrompt);
				}
				else {
					int indexOfLastMorelineSymbol = dohvatiPrompt.lastIndexOf(env.getMorelinesSymbol());
					StringBuilder sb = new StringBuilder();
					sb.append(dohvatiPrompt.substring(0, indexOfLastMorelineSymbol - 1));
					
					env.write(env.GetMultilineSymbol() +" ");
					
					
					do {
						dohvatiPrompt = env.readLine();
						if(dohvatiPrompt != null) {
							if(dohvatiPrompt.endsWith(env.getMorelinesSymbol().toString())){
								indexOfLastMorelineSymbol = dohvatiPrompt.lastIndexOf(env.getMorelinesSymbol());
								sb.append(" " + dohvatiPrompt.substring(0, indexOfLastMorelineSymbol - 1));
								
								env.write(env.GetMultilineSymbol() + " ");
								dohvatiPrompt = env.readLine();
							}
							else {
								sb.append(" "+ dohvatiPrompt);
								dohvatiPrompt = null;
								break;
							}
						}
					} while(dohvatiPrompt.endsWith(env.getMorelinesSymbol().toString()));
					if(dohvatiPrompt != null) {
						sb.append(" " + dohvatiPrompt);
					}
					
					jednaLinija(sb.toString());
				}
				
			} while(!env.getCurrentShellStatus().equals(ShellStatus.TERMINATE));
		}catch(Exception msg) {
			
		}
	}

	/**
	 * Metoda prima liniju korisnikovog unosa kao string.
	 * Prepoznaje komandu i poziva njezino izvršavanje.
	 * @param dohvatiPrompt
	 */
	private static void jednaLinija(String dohvatiPrompt) {
		String[] linija = dohvatiPrompt.split(" ");
		
		StringBuilder sb = new StringBuilder();
		
		IntStream.range(1, linija.length)
		.mapToObj(i -> linija[i])
		.forEach((elem) -> {
			sb.append(" " + elem);
		});
		
		ShellCommand komanda = komande.get(linija[0].trim());
		if(komanda == null) {
			env.writeln("Nije prepoznata komanda!");
			return;
		}
		
		env.setCurrentShellStatus(komanda.executeCommand(env, sb.toString().trim()));
	}
}