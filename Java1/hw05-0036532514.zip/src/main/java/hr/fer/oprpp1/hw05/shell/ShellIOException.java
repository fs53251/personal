package hr.fer.oprpp1.hw05.shell;


/**
 * Iznimka za rad u shell-u.

 * @author Filip
 *
 */
public class ShellIOException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public ShellIOException(String message) {
		super(message);
	}
	
	public ShellIOException() {
		super();
	}
}
