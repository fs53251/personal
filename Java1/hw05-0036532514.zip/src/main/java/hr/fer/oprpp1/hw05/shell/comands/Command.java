package hr.fer.oprpp1.hw05.shell.comands;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.SortedMap;

import hr.fer.oprpp1.hw05.crypto.Util;
import hr.fer.oprpp1.hw05.shell.Environment;
import hr.fer.oprpp1.hw05.shell.ShellCommand;
import hr.fer.oprpp1.hw05.shell.ShellIOException;
import hr.fer.oprpp1.hw05.shell.ShellStatus;

/**
 * Razred čuva javne statičke varijable koje predstavljaju komande.
 * Svaka komanda je nova implementacija razreda ShellCommand
 * @author Filip
 *
 */
public class Command {
	/**
	 * Statička varijabla koja predstavlja komandu charsets
	 */
	public static ShellCommand charsets = new ShellCommand() {

		public ShellStatus executeCommand(Environment env, String arguments) {
			if(arguments.equals("")) {
				SortedMap<String, Charset> mapa = Charset.availableCharsets();
				mapa.forEach((key, value) -> {
					env.writeln(key);
				});
				return ShellStatus.CONTINUE;
			}
			return ShellStatus.TERMINATE;
		}

		public String getCommandName() {
			return "charsets";
		}

		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda charsets ne prima argumente.");
			upute.add("Ispisuje podržane kodne stranice.");
			return upute;
		}
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu cat
	 */
	public static ShellCommand cat = new ShellCommand() {

		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			String[] argumenti = null;
			if(!arguments.trim().startsWith("\"")) {
				if(arguments.contains(" ")) {
					env.writeln("Krivi unos!");
					env.writeln("Koristi navodnike za putanje s razmakom.");
					return ShellStatus.CONTINUE;
				}
				argumenti = arguments.split(" ");
			}else {
				try {
					argumenti = Command.parsirajUlaz(arguments);
				}catch(ShellIOException msg) {
					env.writeln(msg.getMessage());
				}
			}
			
			Path path = Path.of(argumenti[0]);
			
			Charset charset = null;
			if(argumenti.length == 1) {
				charset = Charset.defaultCharset();
			}else if(argumenti.length == 2) {
				try {
					charset = Charset.forName(argumenti[1]);
				}catch(Exception msg) {
					env.writeln("Unesena kriva kodna stranica, koristim defaultnu!");
					charset = Charset.defaultCharset();
				}
				
			}
			
			try (BufferedReader br = new BufferedReader(new FileReader(path.toFile(), charset))) {
				String ulazniRed;
				while ((ulazniRed = br.readLine()) != null) {
					env.writeln(ulazniRed);
				}
			} catch (IOException e) {
				return ShellStatus.CONTINUE;
			}
			return ShellStatus.CONTINUE;
		}

		@Override
		public String getCommandName() {
			return "cat";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda cat prima jedan ili dva argumenta.");
			upute.add("Prvi argument je putanja do datoteke i ona je obavezna.");
			upute.add("Drugi argument je kodna stranica i ona je opcionalna, ako se ne navede");
			upute.add("koristi se defaultna kodna stranica.");
			return upute;
		}
	
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu ls
	 */
	public static ShellCommand ls = new ShellCommand() {

		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			String[] argumenti = null;
			if(!arguments.trim().startsWith("\"")) {
				if(arguments.contains(" ")) {
					env.writeln("Krivi unos!");
					env.writeln("Koristi navodnike za putanje s razmakom.");
					return ShellStatus.CONTINUE;
				}
				argumenti = arguments.split(" ");
			}else {
				try {
					argumenti = Command.parsirajUlaz(arguments);
				}catch(ShellIOException msg) {
					env.writeln(msg.getMessage());
				}
			}
			
			File direktorij = new File(argumenti[0]);
			
			if(direktorij.isDirectory()) {
				for(File dijete: direktorij.listFiles()) {
					String fileName = dijete.getName();
					
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Path path = Paths.get(arguments);
					BasicFileAttributeView faView = Files.getFileAttributeView(
					path, BasicFileAttributeView.class, LinkOption.NOFOLLOW_LINKS
					);
					BasicFileAttributes attributes = null;
					try {
						attributes = faView.readAttributes();
					} catch (IOException e) {
						e.printStackTrace();
					}
					FileTime fileTime = attributes.creationTime();
					String formattedDateTime = sdf.format(new Date(fileTime.toMillis()));
					
					odrediPrefiks(dijete, env);
					
					long velicina = attributes.size();
					String ispisVelicine = " ".repeat(10-String.valueOf(velicina).length()) + String.valueOf(velicina) + " ";
					env.write(ispisVelicine);
					env.write(formattedDateTime+ " ");
					env.write(ispisVelicine + " ");
					env.write(fileName);
					env.writeln("");
				}
			}else {
				env.writeln("Nije unesen direktorij!");
			}
			return ShellStatus.CONTINUE;
		}

		private void odrediPrefiks(File dijete, Environment env) {
			String prefiks = "";
			prefiks += dijete.isDirectory() ? "d" : "-";
			prefiks += dijete.canRead() ? "r" : "-";
			prefiks += dijete.canWrite() ? "w" : "-";
			prefiks += dijete.canExecute() ? "e" : "-";
			env.write(prefiks+ " ");
		}

		@Override
		public String getCommandName() {
			return "ls";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda ls prima jedan argument.");
			upute.add("Ispisuje datoteke i direktorije unutar navedenog direktorija. Nije rekurzivno.");
			return upute;
		}
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu tree
	 */
	public static ShellCommand tree = new ShellCommand() {

		@Override
		public ShellStatus executeCommand(Environment env, String arguments){
			String[] argumenti = null;
			if(!arguments.trim().startsWith("\"")) {
				if(arguments.contains(" ")) {
					env.writeln("Krivi unos!");
					env.writeln("Koristi navodnike za putanje s razmakom.");
					return ShellStatus.CONTINUE;
				}
				argumenti = arguments.split(" ");
			}else {
				try {
					argumenti = Command.parsirajUlaz(arguments);
				}catch(ShellIOException msg) {
					env.writeln(msg.getMessage());
				}
			}
			Path path = Paths.get(argumenti[0]);
			
			try {
				Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
					public int distanca = 0;
					public FileVisitResult preVisitDirectory(Path dir,BasicFileAttributes attrs) {
						env.writeln(" ".repeat(distanca) + dir.getFileName());
						distanca += 2;
						return FileVisitResult.CONTINUE;
						
					}
                        
					public FileVisitResult postVisitDirectory(Path dir, IOException exc) {
						distanca -= 2;
						return FileVisitResult.CONTINUE;
						
					}
					
				});
			} catch (IOException e) {
				env.writeln("Greška kod obilaska stabla!");
			}
			return ShellStatus.CONTINUE;
		}

		@Override
		public String getCommandName() {
			return "tree";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda tree prima jedan argument.");
			upute.add("Ispisuje datoteke i direktorije rekurzivno u obliku stabla.");
			return upute;
		}
		
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu copy
	 */
	public static ShellCommand copy = new ShellCommand() {
		String[] argumenti = null;
		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			try {
				argumenti = parsirajDvaFile(arguments);
			}catch(ShellIOException msg) {
				env.writeln(msg.getMessage());
			}
		
			File izvorFile = new File(argumenti[0]);
			File ponorFile = new File(argumenti[1]); 
			
			if(ponorFile.exists()) {
				if(ponorFile.isDirectory()) {
					int indexPocetkaImena = izvorFile.toString().lastIndexOf("\\");
					String izvorFileName = izvorFile.toString().substring(indexPocetkaImena+1);
					ponorFile = new File(ponorFile.toString()+ '\\' +izvorFileName);
				}
				
				if(ponorFile.isFile()) {
					env.writeln("Smijem li prepisati postojeci file?");
					env.write("da/ne: ");
					if(env.readLine().toLowerCase().equals("ne")) {
						env.writeln("Necu prepisati postojeci file.");
						return ShellStatus.CONTINUE;
					}
				}
				
				try (InputStream inputStream = new BufferedInputStream(new FileInputStream(izvorFile));
						OutputStream outputStream = new BufferedOutputStream(new FileOutputStream(ponorFile))) {

					byte[] buff = new byte[1024];
					int brojProcitanihBajtova;
					while ((brojProcitanihBajtova = inputStream.read(buff)) > 0) {
						outputStream.write(buff, 0, brojProcitanihBajtova);
						outputStream.flush();
					}
				}catch (Exception e) {
					return ShellStatus.CONTINUE;
				}
				return ShellStatus.CONTINUE;
			}
			return ShellStatus.CONTINUE;
		}

		@Override
		public String getCommandName() {
			return "copy";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda copy prima dva argumenta.");
			upute.add("Izvorno i odredišno ime datoteke, za odredišto ime može biti predan i direktorij.");
			upute.add("Kopira se sadržaj iz izvorne datoteke u odredišnu.");
			return upute;
		}
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu mkdir
	 */
	public static ShellCommand mkdir = new ShellCommand() {

		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			File direktorij = new File(arguments);
			
			if(!direktorij.mkdir()) {
				env.writeln("Nije uspjelo stvaranje direktorija");
				return ShellStatus.CONTINUE;
			}
			return ShellStatus.CONTINUE;
		}

		@Override
		public String getCommandName() {
			return "mkdir";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda mkdir prima jedan argument.");
			upute.add("Stvara direktorij s navedenom putanjom.");
			return upute;
		}
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu hexdump
	 */
	public static ShellCommand hexdump = new ShellCommand() {

		@SuppressWarnings("resource")
		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			String[] argumenti = null;
			if(!arguments.trim().startsWith("\"")) {
				if(arguments.contains(" ")) {
					env.writeln("Krivi unos!");
					env.writeln("Koristi navodnike za putanje s razmakom.");
					return ShellStatus.CONTINUE;
				}
				argumenti = arguments.split(" ");
			}else {
				try {
					argumenti = Command.parsirajUlaz(arguments);
				}catch(ShellIOException msg) {
					env.writeln(msg.getMessage());
				}
			}

			File newFile = new File(argumenti[0]);
			if (newFile.isDirectory()) {
				env.writeln("Kao argument treba predati file!");
				return ShellStatus.CONTINUE;
			}
			String ulaz = "";
			
			try {
				ulaz = ucitajUlaz(newFile);
				ulaz = ulaz.replaceAll("\n", " ");
			} catch (FileNotFoundException e1) {
				env.writeln("Neuspjelo čitanje datoteke");
				return ShellStatus.CONTINUE;
			}
			
			byte[] polje;
			try {
				polje = Files.readAllBytes(Paths.get(argumenti[0]));
			} catch (IOException e) {
				env.writeln("Neuspjelo citanje datoteke!");
				return ShellStatus.CONTINUE;
			}
			int brojac = 0;
			System.out.println(polje.length);
			for (int i = 0; i <= polje.length/16; i++) {
				int mnozitelj = 10;
				while(brojac / mnozitelj != 0) {
					mnozitelj *= 10;
				}
				int pozicijaBroja = 7 - (Integer.toString(mnozitelj).length() - 1);
				int current = 0;
				StringBuilder sb = new StringBuilder();
				while(current <= 7) {
					if(current == pozicijaBroja) {
						sb.append(brojac);
						current += Integer.toString(brojac).length();
					}else {
						sb.append("0");
						current++;
					}	
				}
				env.write(sb.toString() + ": ");
				
				env.write(ispisiRedak(i, polje, brojac, ulaz));
				ulaz = ulaz.substring(15);
				brojac++;
			}
			return ShellStatus.CONTINUE;
		}

		private String ispisiRedak(int i, byte[] polje, int brojac, String ulaz) {
			StringBuilder sb = new StringBuilder();
			for (int j = 0; j < 16; j++) {
				int ogranicenje = i*16 + j;
				if (ogranicenje >= polje.length) {
					sb.append("  ");
				} else {
					sb.append((Util.bytetohex(new byte[]{polje[ogranicenje]})).toUpperCase());
				}
				if (j == 7) {
					sb.append("|");
				} else if (j == 15) {
					sb.append(" | ");
					
					String u = ulaz.substring(0, 16);
					
					StringBuilder stb = new StringBuilder();
				    for (int k = 0; k < u.length(); k++) {
				        int value = (int) u.charAt(k);
				        if (value < 32 || value > 127) {
				            stb.append('.');
				        } else {
				            stb.append(u.charAt(k));
				        }
				    }
				    u = stb.toString();
				    
					sb.append(u + "\n");
					
				} else {
					sb.append(" ");
				}
			}
			return sb.toString();
		}

		@SuppressWarnings("resource")
		private String ucitajUlaz(File newFile) throws FileNotFoundException {
			Path path = newFile.toPath();
			try {
				return Files.readString(path);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		@Override
		public String getCommandName() {
			return "hexdump";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda hexdump prima jedan argument.");
			upute.add("Ispisuje hex-izlaz na temelju sadržaja datoteke koja je predana");
			return upute;
		}
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu symbol
	 */
	public static ShellCommand symbol = new ShellCommand() {

		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			String[] argumenti = arguments.split(" ");
			if(argumenti.length == 1) {
				switch (argumenti[0]) {
				case "PROMPT":
					env.writeln(String.format("Symbol for PROMPT is \'%s\'", env.getPromptSymbol()));
					break;
				case "MORELINES":
					env.writeln(String.format("Symbol for MORELINES is \'%s\'", env.getMorelinesSymbol()));
					break;
				case "MULTILINE":
					env.writeln(String.format("Symbol for PROMPT is \'%s\'", env.GetMultilineSymbol()));
					break;
				}
			} else if(argumenti.length == 2) {
				switch (argumenti[0]) {
				case "PROMPT":
					env.writeln(String.format("Symbol for PROMPT changed from \'%s\' to \'%s\'", env.getPromptSymbol(), argumenti[1]));
					env.setPromptSymbol(argumenti[1].charAt(0));
					break;
				case "MORELINES":
					env.writeln(String.format("Symbol for MORELINES changed from \'%s\' to \'%s\'", env.getMorelinesSymbol(), argumenti[1]));
					env.setMorelinesSymbol(argumenti[1].charAt(0));
					break;
				case "MULTILINE":
					env.writeln(String.format("Symbol for MULTILINE changed from \'%s\' to \'%s\'", env.GetMultilineSymbol(), argumenti[1]));
					env.setMultilineSymbol(argumenti[1].charAt(0));
					break;
				default:
					return ShellStatus.CONTINUE;
				}
			}
			return ShellStatus.CONTINUE;
		}

		@Override
		public String getCommandName() {
			return "symbol";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda symbol prima jedan ili dva argumenta.");
			upute.add("Ako prima jedan argument, vraća podatak shell specifikacije.");
			upute.add("Ako prima dva argumenta, postavlja podatke shell specifikacije.");
			return upute;
		}
	};
	
	/**
	 * Statička varijabla koja predstavlja komandu help
	 */
	public static ShellCommand help = new ShellCommand() {

		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			if(arguments.equals("") || arguments == null) {
				env.commands().entrySet().forEach((entry) -> {
					for(String s: entry.getValue().getCommandDescription()) {
						env.writeln("   "+ s);
					}
					env.writeln("");
				});
				return ShellStatus.CONTINUE;
			}
			
			ShellCommand dohvacenaKomanda = env.commands().get(arguments);
			if(dohvacenaKomanda==null) {
				env.writeln("No such command exits");
				return ShellStatus.CONTINUE;
			}

			for(String s: dohvacenaKomanda.getCommandDescription()) {
				env.writeln("     " + s);
			}
			return ShellStatus.CONTINUE;
		}

		@Override
		public String getCommandName() {
			return "help";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda help ne prima argumente ili prima jedan argument.");
			upute.add("Ispisuje opise svih komandi ako ne primi argument.");
			upute.add("Ispisuje opise komandi koja je predana kao argument.");
			return upute;
		}
		
	};

	/**
	 * Statička varijabla koja predstavlja komandu exit
	 */
	public static ShellCommand exit = new ShellCommand() {

		@Override
		public ShellStatus executeCommand(Environment env, String arguments) {
			return ShellStatus.TERMINATE;
		}

		@Override
		public String getCommandName() {
			return "exit";
		}

		@Override
		public List<String> getCommandDescription() {
			List<String> upute = new ArrayList<>();
			upute.add("Komanda exit terminira rad shell-a");
			return upute;
		}
		
	};
	
	/**
	 * Metoda prima string kao popis datoteka i dodatnih parametara.
	 * Parsira string i izdvaja navedene nazive datoteka i parametara u polje stringova
	 * @param arguments
	 * @return polje koje predstavlja parsirani ulaz
	 */
	private static String[] parsirajUlaz(String arguments) {
		int pocetakFile = arguments.indexOf("\"");
		int krajFile = arguments.lastIndexOf("\"");
		char[] fileName;
		StringBuilder sb = new StringBuilder();
		
		if(pocetakFile != krajFile) {
			fileName = arguments.substring(pocetakFile + 1, krajFile).toCharArray();
			int i = pocetakFile;
			while(i < fileName.length) {
				if(fileName[i] == '\\') {
					if((i+1 < fileName.length) && fileName[i+1] == '\"') {
						sb.append("\"");
						i++;
					}else if((i+1 < fileName.length) && fileName[i+1] == '\\') {
						sb.append("\\");
						i++;
					}else {
						sb.append(fileName[i]);
					}
				}else {
					sb.append(fileName[i]);
				}
				i++;
			}
		}else {
			throw new ShellIOException();
		}
		
		if(krajFile == arguments.length()-1) {
			String[] argumenti = {sb.toString()};
			return argumenti;
		}else {
			if(krajFile < arguments.length()-1 && arguments.charAt(krajFile + 1) != ' ') {
				throw new ShellIOException("Nakon navodnika koji zatvaraju se ne nalazi kraj ili razmak!");
			}
			String[] argumenti = {sb.toString(), arguments.substring(krajFile+1).trim()};
			return argumenti;
		}
	}
	
	/**
	 * Metoda koja prima 2 naziva datoteke u bilokojem obliku i parsira ih.
	 * Vraća polje stringova, svaki element je naziv datoteke.
	 * @param arguments
	 * @return polje imena datoteka koji su parsirani iz ulaznog stringa
	 */
	private static String[] parsirajDvaFile(String arguments) {
		boolean prvi = true;
		int current = 0;
		int pocetak;
		int kraj;
		String[] izlaz = {"", ""};
		
		char[] ulaz = arguments.toCharArray();
		while(current < arguments.length()) {
			if(prvi) {
				if(ulaz[current] == '\"') {
					pocetak = current;
					kraj = arguments.substring(pocetak + 1).indexOf('\"');
					izlaz[0] = Command.parsirajUlaz(arguments.substring(pocetak, kraj + 2))[0];
					prvi = false;
					current = kraj + 2;
					if(ulaz[current] != ' ') {
						throw new ShellIOException("Krivi unos, nema razmaka izmedu imenima fajlova!");
					}
					while(ulaz[current] == ' ') {
						current++;
					}
				}else { //nije pod stringom
					pocetak = current;
					while(ulaz[current] != ' ') {
						current++;
					}
					kraj = current;
					if(ulaz[kraj] != ' ') {
						throw new ShellIOException("Krivi unos, nema razmaka izmedu imenima fajlova!");
					}
					izlaz[0] = arguments.substring(pocetak, kraj);
					current++;
					prvi = false;
				}
			}else //drugi
				if(ulaz[current] == '\"') {
					pocetak = current;
					kraj = arguments.substring(pocetak + 1).indexOf('\"');
					izlaz[1] = Command.parsirajUlaz(arguments.substring(pocetak))[0];
					break;
				}else {
					pocetak = current;
					while(current < arguments.length() && ulaz[current] != ' ') {
						current++;
					}
					kraj = current;
					izlaz[1] = arguments.substring(pocetak, kraj);
					break;
			}
		}
		return izlaz;
	}
}
