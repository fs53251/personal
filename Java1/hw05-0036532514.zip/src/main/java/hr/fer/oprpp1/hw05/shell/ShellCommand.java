package hr.fer.oprpp1.hw05.shell;

import java.util.List;

/**
 * Ugovor za stvaranje komandi.
 * Svaka komanda se mora moći izvesti, dohvatiti se njeno ime i opis.
 * @author Filip
 *
 */
public interface ShellCommand {
	/**
	 * Metoda koja ivršava komandu.
	 * @param env referenca na objekt koji zna komunicirati s korisnikom
	 * @param arguments argumenti koje korisnik unosi
	 * @return status nakon izvedene komande
	 */
	ShellStatus executeCommand(Environment env, String arguments);
	
	/**
	 * Getter za ime komande.
	 * @return
	 */
	String getCommandName();
	
	/**
	 * Getter za linije opisa komande.
	 * @return
	 */
	List<String> getCommandDescription();
}
