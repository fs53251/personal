package hr.fer.oprpp1.hw05.crypto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Scanner;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
/**
 * Razred Crypto omogućuje korisniku kriptiranje i dekriptiranje datoteke te
 * omogućuje provjeru SHA-256 digest-a za neki file.
 * Koristi se AES kripto algoritam sa 128-bitnim ključem.
 * Za čitanje i pisanje fileova koristi se stream okteta.
 * 
 * @author Filip
 *
 */
public class Crypto {
	/**
	 * Metoda koju izvrsavamo, npr. checksha, encrypt, decrypt.
	 */
	String postupak;
	
	/**
	 * Naziv datoteke koja predstavlja izvor podataka.
	 */
	String izvorDatoteka;
	
	/**
	 * Naziv datoteke koja predstavlja odredišnu datoteku. 
	 */
	String ponorDatoteka;
	
	/**
	 * Digest koji unosi korisnik.
	 */
	String korisnikDigest;
	
	/**
	 * Password koji unosi korisnik.
	 */
	String keyText;
	
	/**
	 * Inicijalizacijski vektor koji unosi korisnik.
	 */
	String ivText;
	
	/**
	 * Konstruktor klase Crypto.
	 * @param postupak metoda koja se provodi
	 * @param izvorDatoteka 
	 * @param ponorDatoteka
	 */
	public Crypto(String postupak, String izvorDatoteka, String ponorDatoteka) {
		this.postupak = postupak;
		this.izvorDatoteka = izvorDatoteka;
		this.ponorDatoteka = ponorDatoteka;
		
		/**
		 * Metoda kojoa provodi danu operaciju koju je unio korisnik.
		 */
		provediOperaciju();
	}
	
	/**
	 * Konstruktor koji prima samo postupak i ime izvorne datoteke.
	 * Svoju zadaću delegira glavnom kosntruktoru.
	 * @param postupak
	 * @param izvorDatoteka
	 */
	public Crypto(String postupak, String izvorDatoteka) {
		this(postupak, izvorDatoteka, null);
	}
	
	/**
	 * Metoda koja provodi prepoznavanja postupka.
	 * Za svaki postupak provodi neku od operacija checksha, encrypt, decrypt.
	 */
	private void provediOperaciju() {
		if(postupak.equals("checksha")) {
			Scanner sc = new Scanner(System.in);
			System.out.printf("Please provide expected sha-256 digest for %s:\n>", izvorDatoteka);
			try {
				korisnikDigest = sc.nextLine();
				sc.close();
				provjeriDigest();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}else if(postupak.equals("encrypt")) {
			odradiUnos();
			
			try {
				odradiKriptiranjeDekriptiranje(true);
			} catch (InvalidKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidAlgorithmParameterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if(postupak.equals("decrypt")) {
			odradiUnos();
			
			try {
				odradiKriptiranjeDekriptiranje(false);
			} catch (InvalidKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidAlgorithmParameterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * Metoda koja na temelju parametra encrypt određuje hoće li kriptirati ili 
	 * dekriptirati. Stvaraju se izvor i ponor podataka te se obavlja kriptiranje/dekriptiranje.
	 * @param encrypt boolean ako je true radi se kriptiranje,
	 * 						  ako je false radi dektiptiranje.
	 * @throws NoSuchAlgorithmException iznimka povezana s klasom Cipher
	 * @throws NoSuchPaddingException iznimka povezana s klasom Cipher
	 * @throws InvalidKeyException iznimka povezana s klasom Cipher
	 * @throws InvalidAlgorithmParameterException iznimka povezana s klasom Cipher
	 * @throws IOException može nastati kod rada s tokovima podataka
	 */
	public void odradiKriptiranjeDekriptiranje(Boolean encrypt) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IOException{
		SecretKeySpec keySpec = new SecretKeySpec(Util.hextobyte(keyText), "AES");
		AlgorithmParameterSpec paramSpec = new IvParameterSpec(Util.hextobyte(ivText));
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, keySpec, paramSpec);
		
		InputStream inputStream = Files.newInputStream(Paths.get(izvorDatoteka));
		OutputStream outputStream = Files.newOutputStream(Paths.get(ponorDatoteka));
		
		byte[] ciphertext;
		byte[] izvorniTekst = new byte[4*1024];
		int procitaniBajtovi;
		
		while((procitaniBajtovi = inputStream.read(izvorniTekst)) != -1) {
			outputStream.write(cipher.update(izvorniTekst, 0, procitaniBajtovi));
		}
		
		try {
			ciphertext = cipher.doFinal();
			outputStream.write(ciphertext);
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		
		if(encrypt) {
			System.out.printf("Encryption completed. Generated file %s based on file %s", izvorDatoteka, ponorDatoteka);			
		}else {
			System.out.printf("Decryption completed. Generated file %s based on file %s", izvorDatoteka, ponorDatoteka);	
		}

	}


	/**
	 * Metoda koja dohvaća korisnikov unos lozinke i inicijalizacijskog vektora.
	 */
	private void odradiUnos() {
		Scanner sc = new Scanner(System.in);
	
		System.out.printf("Please provide password as hex-encoded text (16 bytes, i.e. 32 hex-digits):\n>");
		keyText =  sc.nextLine();
		
		System.out.printf("Please provide initialization vector as hex-encoded text (32 hex-digits):\n>");
		ivText =  sc.nextLine();
		
		sc.close();
	}

	/**
	 * Metoda računa digest iz izvornog filea i uspoređuje ga s korisnikovim unosom.
	 * @throws IOException nastaje zbog rada s tokovima podataka.
	 */
	private void provjeriDigest() throws IOException {
		File datotekaIzvora = new File(izvorDatoteka);
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			
			//tocan digest filea
			try {
				FileInputStream fileInputStream = new FileInputStream(datotekaIzvora);
				String fileName = fileInputStream.toString();
				//buffer 4k
				byte[] buffer = new byte[4*1024];
				int procitaniBajtovi;
				while((procitaniBajtovi = fileInputStream.read(buffer)) != -1) {
					messageDigest.update(buffer, 0, procitaniBajtovi);
				}
				
				String tocanDigest = Util.bytetohex(messageDigest.digest());
				if(korisnikDigest.equals(tocanDigest)){
					System.out.printf("Digesting completed. Digest of %s matches expected digest", fileName);
				}else {
					System.out.printf("Digesting completed. Digest of %s does not match the expected digest. \nDigest was: {}",
							fileName, tocanDigest);
				}
				
				fileInputStream.close();
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		if(args.length == 2) {
			new Crypto(args[0], args[1]);
		}else if(args.length == 3) {
			new Crypto(args[0], args[1], args[2]);
		}
	}
}
