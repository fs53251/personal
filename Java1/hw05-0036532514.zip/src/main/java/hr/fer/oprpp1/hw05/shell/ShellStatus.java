package hr.fer.oprpp1.hw05.shell;

/**
 * Enumeracija koja ima 2 "stanja".
 * Stanje TERMINATE prekida rad shell-a.
 * @author Filip
 *
 */
public enum ShellStatus {
	CONTINUE,
	TERMINATE
}
