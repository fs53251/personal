package hr.fer.oprpp1.hw05.crypto;

/**
 * Klasa koja sadrži statičke metode za pretvorbu stringa u hex zapisu u polje
 * bajtove, te pretvorbu polja bajtova u hex zapis
 * @author Filip
 *
 */
public class Util {
	/**
	 * Metoda prima string zapis heksadecimalni i svaka dva znaka
	 * gleda kao jedan bajt i redom puni polje bajtova.
	 * @param unos 
	 * @return polje bajtova
	 */
	public static byte[] hextobyte(String unos) {
		unos = unos.toUpperCase();
		if(unos == "") {
			return new byte[0];
		}
		
		if(unos == null) {
			throw new IllegalStateException();
		}
		
		//provjera za hexadecimalni unos
		if(!unos.matches("[0-9A-F]+")) {
			throw new IllegalStateException();
		}
		unos = unos.toUpperCase();
		if(!(unos.length()%2==0)) {
			throw new IllegalStateException();
		}
		byte[] polje = new byte[unos.length()/2];
		int brojac = 0;
		int elPolja = 0;
		char[] poljeUlaz = unos.toCharArray();
		while(brojac < unos.length()) {
			polje[elPolja++] = (byte)Integer.parseInt(Character.toString(poljeUlaz[brojac])+ Character.toString(poljeUlaz[brojac+1]), 16); 
			brojac +=2;
		}
		
		return polje;
	}

	/**
	 * Metoda koja prima polje bajtova i svaki bajt pretvori u 
	 * heksadecimalni zapis pomoću statičke metode format, klase String.
	 * @param poljeBajtova
	 * @return String koji predstavlja hex zapis polja bajtova.
	 */
	public static String bytetohex(byte[] poljeBajtova) {
		if(poljeBajtova == null) {
			throw new IllegalStateException();
		}
		if(poljeBajtova.length == 0) {
			return "";
		}
		StringBuilder sb= new StringBuilder();
		
		for(int i = 0; i < poljeBajtova.length; i++) {
			sb.append(String.format("%02x", poljeBajtova[i]));
		}
		
		return sb.toString();
	}
}
