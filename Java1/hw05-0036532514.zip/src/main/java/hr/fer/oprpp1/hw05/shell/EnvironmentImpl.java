package hr.fer.oprpp1.hw05.shell;

import java.util.Collections;

import java.util.Scanner;
import java.util.SortedMap;
import java.util.TreeMap;

import hr.fer.oprpp1.hw05.shell.comands.Command;

/**
 * Razred koji je implementacija sučelja Environment.
 * @author Filip
 *
 */
public class EnvironmentImpl implements Environment{
	/**
	 * Varijabla koja čuva prompt character.
	 */
	private Character PROMPTSYMBOL;
	
	/**
	 * Varijabla koja čuva simbol za pisanje naredbi u više redova.
	 */
	private Character MORELINESSYMBOL;
	
	/**
	 * Varijabla koja čuva simbol koji se piše na početku naredbi s više redova.
	 */
	private Character MULTILINESYMBOL;
	
	/**
	 * Trenutni status shell-a.
	 */
	private ShellStatus currentShellStatus;
	
	/**
	 * Komande koje su implementirane u shell-u.
	 */
	private static SortedMap<String, ShellCommand> komande= new TreeMap<>();
	
	/**
	 * Konstruktor, postavlja defaultne vrijedonsti varijabli.
	 * Poziva metodu postavljanja komandi.
	 */
	public EnvironmentImpl() {
		PROMPTSYMBOL = '>';
		MORELINESSYMBOL = '\\';
		MULTILINESYMBOL = '|';
		
		currentShellStatus = ShellStatus.CONTINUE;
		postaviKomande();
	}
	
	/**
	 * Getter za trenutni status shell-a.
	 * @return status
	 */
	public ShellStatus getCurrentShellStatus() {
		return currentShellStatus;
	}

	/**
	 * Setter za trenutni status shell-a.
	 * @param currentShellStatus
	 */
	public void setCurrentShellStatus(ShellStatus currentShellStatus) {
		this.currentShellStatus = currentShellStatus;
	}

	/**
	 * Getter za simbol na početku više redova
	 * @return
	 */
	@Override
	public Character GetMultilineSymbol() {
		return this.MULTILINESYMBOL;
	}
	
	/**
	 * Setter za simbol na početku više redova
	 * @param symbol
	 */
	@Override
	public void setMultilineSymbol(Character Multilinesymbol) {
		this.MULTILINESYMBOL = Multilinesymbol;
	}

	/**
	 * Getter za promt simbol
	 * @return
	 */
	@Override
	public Character getPromptSymbol() {
		return this.PROMPTSYMBOL;
	}

	/**
	 * Setter za prompt simbol
	 * @param symbol
	 */
	@Override
	public void setPromptSymbol(Character Promptsymbol) {
		this.PROMPTSYMBOL = Promptsymbol;
		
	}

	/**
	 * Getter za pisanje više redova naredbe
	 * @return
	 */
	@Override
	public Character getMorelinesSymbol() {
		return this.MORELINESSYMBOL;
	}

	/**
	 * Setter za pisanje više redova naredbe
	 * @param symbol
	 */
	@Override
	public void setMorelinesSymbol(Character Morelinesymbol) {
		this.MORELINESSYMBOL = Morelinesymbol;
		
	}
	
	/**
	 * Metoda za čitanje linije korisnikovog unosa.
	 */
	@SuppressWarnings("resource")
	@Override
	public String readLine(){
		Scanner sc = new Scanner(System.in);
		String readLine;
		try {
			readLine = sc.nextLine();
		}catch(Exception msg) {
			throw new ShellIOException();
		}
		
		return readLine;
	}

	/**
	 * Metoda piše dani tekst u shell. Ne stvara prelazak u novi red.
	 * @param text text koji se prikaže u shellu
	 * @throws ShellIOException ako nije uspjelo pisanje u shell
	 */
	@Override
	public void write(String unos){
		try {
			System.out.printf("%s", unos);
		}catch (Exception msg) {
			throw new ShellIOException();
		}
	}

	/**
	 * Metoda piše dani tekst u shell. Stvara prelazak u novi red.
	 * @param text text koji se prikaže u shellu
	 * @throws ShellIOException ako nije uspjelo pisanje u shell
	 */
	@Override
	public void writeln(String unos){
		try {
			System.out.printf("%s\n", unos);
		}catch (Exception msg) {
			throw new ShellIOException();
		}
	}

	/**
	 * Metoda vraća mapu implementiranih komandi u shell-u.
	 * Mapa se ne može mijenjati jer se koristi statička metoda
	 * unmodifiableSortedMap klase Collections
	 * @return
	 */
	@Override
	public SortedMap<String, ShellCommand> commands() {
		return Collections.unmodifiableSortedMap(komande);
	}


	/**
	 * Metoda postavlja komande tako što puni mapu komande.
	 * @throws ShellIOException ako se neke komande ne spreme u mapu.
	 */
	public void postaviKomande() {
		 komande.put("symbol", Command.symbol);
		 
		 komande.put("charsets", Command.charsets);
		 komande.put("cat", Command.cat);
		 komande.put("ls", Command.ls);
		 komande.put("tree", Command.tree);
		 komande.put("copy", Command.copy);
		 komande.put("mkdir", Command.mkdir);
		 komande.put("hexdump", Command.hexdump);
		 
		 komande.put("exit", Command.exit);
		 komande.put("help", Command.help);
		 
		 if(komande.size() < 10) {
			 throw new ShellIOException();
		 }
	}
}
