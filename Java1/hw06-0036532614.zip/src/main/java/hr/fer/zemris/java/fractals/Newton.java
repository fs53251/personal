package hr.fer.zemris.java.fractals;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;

import hr.fer.zemris.java.fractals.viewer.FractalViewer;
import hr.fer.zemris.java.fractals.viewer.IFractalProducer;
import hr.fer.zemris.java.fractals.viewer.IFractalResultObserver;
import hr.fer.zemris.math.Complex;
import hr.fer.zemris.math.ComplexPolynomial;
import hr.fer.zemris.math.ComplexRootedPolynomial;

/**
 *  Razred Newton koristi samo jednu dretvu za iscrtavanje.
 * 	Iscrtava oblik.
 * @author filip
 *
 */
public class Newton {

	static int brojRoot = 1;
	static ComplexPolynomial polynomial;
	static ComplexPolynomial derived;
	static ComplexRootedPolynomial crp;
	public static void main(String[] args) {
		System.out.printf("Welcome to Newton-Raphson iteration-based fractal viewer.\n"
				+ "Please enter at least two roots, one root per line. Enter 'done' when done.\n");
		Scanner sc = new Scanner(System.in);
		System.out.printf("Root %d> ", brojRoot);
		String red = null;
		List<Complex> korijeni = new ArrayList<>();
		while(!(red = sc.nextLine()).equals("done")) {
			Complex rez = obradiUnos(red);
			if(rez != null) {
				korijeni.add(rez);
			}
			
			System.out.printf("Root %d> ", brojRoot);
		}
		sc.close();
		Complex constant = new Complex(1, 0);
		Complex[] root = new Complex[korijeni.size()];
		for(int i = 0; i < root.length; i++) {
			root[i] = korijeni.get(i);
		}
		crp = new ComplexRootedPolynomial(constant,root);
		polynomial = crp.toComplexPolynom();
		derived = polynomial.derive();
		FractalViewer.show(new MojProducer());
	}

	/**
	 * Metoda koja prima unos i parsira kompleksni broj.
	 * @param red string koji se parsira
	 * @return kompleksni broj
	 */
	private static Complex obradiUnos(String red) {
		if(red.equals("")) {
			System.out.println("Nije unesen legalan kompleksni broj, unesi ponovo:");
			return null;
		}
		String[] unos = red.split(" ");
		int real = 0;
		int imaginary = 0;
		
		// a + ib ... a - ib
		if(unos.length == 3) {
			int predznak = 1;
			if(unos[1].equals("-")) {
				predznak = -1;
			}else if(!unos[1].equals("+")) {
				System.out.println("krivi unos operacije, unesi ponovo:");
				return null;
			}
			if(unos[2].equals("i")) {
				imaginary = 1 * predznak;
			}else if(unos[2].startsWith("i")){
				try {
					imaginary = Integer.parseInt(unos[2].substring(1)) * predznak;
				}catch(Exception e) {
					System.out.println("krivi unos imaginarne jedinice, unesi ponovo:");
					return null;
				}
			}else {
				System.out.println("krivi unos imaginarne jedinice, unesi ponovo:");
				return null;
			}
			
			try {
				real = Integer.parseInt(unos[0]) * predznak;
			}catch(Exception e) {
				System.out.println("krivi unos realnog dijela, unesi ponovo:");
				return null;
			}
			brojRoot++;
			return new Complex(real, imaginary);
			
		}else if(unos.length == 1) { //i, i2, 24
			int predznak = 1;
			if(unos[0].startsWith("-")) {
				predznak = -1;
				unos[0] = unos[0].substring(1);
			}
			
			if(unos[0].equals("i")) {
				imaginary = 1 * predznak;
				real = 0;
			}else if(unos[0].startsWith("i")){
				try {
					imaginary = Integer.parseInt(unos[2].substring(1)) * predznak;
					real = 0;
				}catch(Exception e) {
					System.out.println("krivi unos imaginarne jedinice, unesi ponovo:");
					return null;
				}
			}else if(!unos[0].contains("i")){
				try {
					real = Integer.parseInt(unos[0]) * predznak;
					imaginary = 0;
				}catch(Exception e) {
					System.out.println("krivi unos realnog dijela, unesi ponovo:");
					return null;
				}
			}else {
				System.out.println("krivi unos, unesi ponovo:");
				return null;
			}
			brojRoot++;
			return new Complex(real, imaginary);
		}else {
			System.out.println("krivi unos, unesi ponovo:");
			return null;
		}
	}
	
	/**
	 * Statička klasa MojProducer m puta izvodi iterativni postupak.
	 * Može se desiti da se iterativni postupak prekine ranije i na temelju toga se određuje boja.
	 * @author filip
	 *
	 */
	public static class MojProducer implements IFractalProducer{
		@Override
		public void produce(double reMin, double reMax, double imMin, double imMax, int width, int height, long requestNo,
				IFractalResultObserver observer, AtomicBoolean cancel) {
			System.out.println("Zapocinjem izracun...");
			int m = 16 * 16 * 16;
			int offset = 0;
			short[] data = new short[width * height];
			for(int y = 0; y < height; y++) {
				if(cancel.get()) break;
				for(int x = 0; x < width; x++) {
					double cre = x / (width - 1.0) * (reMax - reMin) + reMin;
					double cim = (height - 1.0 - y) / (height - 1) * (imMax - imMin) + imMin;
					
					Complex zn = new Complex(cre, cim);
					double module = 0;
					int iters = 0;
					double treshold = 0.002;
					do {
						Complex numerator = polynomial.apply(zn);
						Complex denominator = derived.apply(zn);
						Complex znold = zn;
						Complex fraction = numerator.divide(denominator);
						zn = zn.sub(fraction);
						module = znold.sub(zn).module();
						iters++;
					}while(module > treshold && iters < m);
					data[offset] = (short) ((iters >= m ? iters : crp.indexOfClosestRootFor(zn, treshold)) + 1);
					offset++;
				}
			}
			System.out.println("Racunanje gotovo. Idem obavijestiti promatraca tj. GUI!");
			observer.acceptResult(data, (short)(polynomial.order() + 1), requestNo);
		}
	}
}
