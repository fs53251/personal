package hr.fer.oprpp1.custom.collections;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.ConcurrentModificationException;
import hr.fer.oprpp1.custom.collections.SimpleHashtable.TableEntry;
import org.junit.jupiter.api.Test;

public class TestSimpleHashTable {
	
	@Test
	public void testIteratorIllegalArgumentExceptionn() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5); // overwrites old grade for Ivana
		
		Iterator<SimpleHashtable.TableEntry<String, Integer>> iter = examMarks.iterator();
		SimpleHashtable.TableEntry<String, Integer> pair = iter.next();
		iter.remove();
		assertThrows(IllegalStateException.class, ()->iter.remove());
	}

	@Test
	public void testIteriranje2() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5);
		Iterator<SimpleHashtable.TableEntry<String, Integer>> iterator = examMarks.iterator();
		TableEntry<String, Integer> tabl;
		assertTrue(iterator.hasNext());
		tabl = iterator.next();
		assertTrue(iterator.hasNext());
		tabl = iterator.next();
		assertTrue(iterator.hasNext());
		tabl = iterator.next();
		assertTrue(iterator.hasNext());
		tabl = iterator.next();
		assertFalse(iterator.hasNext());
	}
	
	@Test
	public void testIteriranjeNoSuchElementException() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5);
		Iterator<SimpleHashtable.TableEntry<String, Integer>> iterator = examMarks.iterator();
		TableEntry<String, Integer> tabl;
		iterator.next();
		iterator.next();
		iterator.next();
		iterator.next();
		assertThrows(NoSuchElementException.class, ()->iterator.next());
	}
	
	@Test
	public void testIteratorRemove() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5); // overwrites old grade for Ivana

		Iterator<SimpleHashtable.TableEntry<String, Integer>> iter = examMarks.iterator();
		while (iter.hasNext()) {
			SimpleHashtable.TableEntry<String, Integer> pair = iter.next();
			if (pair.getKey().equals("Ivana")) {
				iter.remove(); // sam iterator kontrolirano uklanja trenutni element
			}
		}
		assertEquals(false,examMarks.containsKey("Ivana"));
	}
	
	@Test
	public void testIteriranjeConcurrentModificationException() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5); // overwrites old grade for Ivana

		Iterator<SimpleHashtable.TableEntry<String, Integer>> iterator = examMarks.iterator();
		examMarks.remove("Ivana");
		assertThrows(ConcurrentModificationException.class, ()->iterator.next());
	}
	
	@Test
	public void testKonstrukrorKapacitet() {
		assertThrows(IllegalArgumentException.class, () -> new SimpleHashtable<>(0));
	}
	
	@Test
	public void testKonstrukror1() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		assertEquals(16, mapa.tablica.length);
	}
	
	@Test
	public void testKonstrukror2() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>(8);
		assertEquals(8, mapa.tablica.length);
	}
	
	@Test
	public void testKonstrukror3() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>(15);
		assertEquals(16, mapa.tablica.length);
	}

	@Test
	public void testKonstruktor4() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		assertEquals(0, mapa.size());
	}
	
	@Test
	public void testClearMapa() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>(8);
		mapa.put("Filip", 12);
		mapa.clear();
		assertEquals(0, mapa.size());
	}

	@Test
	public void testPutMetoda() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>(8);
		assertThrows(NullPointerException.class, () -> mapa.put(null,21));
	}
	
	@Test
	public void testPutMetoda2() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>(8);
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(4, mapa.size());
	}
	
	@Test
	public void testPutMetoda3() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>(8);
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		mapa.put("Filip", 22);
		assertEquals(4, mapa.size());
	}
	
	@Test
	public void testPutPovecaKapacitet() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>(4);
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(8, mapa.tablica.length);
	}

	@Test
	public void testGet() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(21,mapa.get("Filip"));
		assertEquals(22, mapa.get("Maja"));
		assertEquals(33, mapa.get("Luka"));
		assertEquals(11, mapa.get("Josip"));
	}
	
	@Test
	public void testGet1() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		assertEquals(null,mapa.get(null));
	}
	
	@Test
	public void testGet2() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		assertEquals(null,mapa.get("Ante"));
	}

	@Test
	public void testSizeMetoda() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(4, mapa.size());
	}
	
	@Test
	public void testContainsKeyNULL() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		assertFalse(mapa.containsKey(null));
	}

	@Test
	public void testContainsKey() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertTrue(mapa.containsKey("Filip"));
	}

	
	@Test
	public void testContainsValue() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertTrue(mapa.containsValue(33));
	}
	
	@Test
	public void testRemove1() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		assertEquals(null, mapa.remove(null));
	}
	
	@Test
	public void testRemove2() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		assertEquals(null, mapa.remove("Filip"));
	}
	
	@Test
	public void testRemove3() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(22, mapa.remove("Maja"));
	}
	
	@Test
	public void testRemove4() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		mapa.remove("Maja");
		assertEquals(3, mapa.size);
	}

	@Test
	public void testIsEmptyTrue() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		assertEquals(true,mapa.isEmpty());
	}

	@Test
	public void testIsEmptyFalse() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		assertEquals(false,mapa.isEmpty());
	}

	@Test
	public void testStringIspis1() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		assertEquals("[]", mapa.toString());
	}
	
	@Test
	public void testStringIspis2() {
		SimpleHashtable<String, Integer> mapa = new SimpleHashtable<>();
		mapa.put("Filip", 11);
		assertEquals("[Filip=11]", mapa.toString());
	}

}
