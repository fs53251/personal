package hr.fer.oprpp1.custom.collections;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestDictionary {
	@Test
	public void testPraznaMapa() {
		Dictionary<String, Integer> mapa= new Dictionary<>();
		assertTrue(mapa.isEmpty());
	}

	@Test
	public void testPunaMapa() {
		Dictionary<String, Integer> mapa= new Dictionary<>();
		mapa.put("Filip",21);
		assertFalse(mapa.isEmpty());
	}
	
	@Test
	public void testSize() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(4, mapa.size());
	}
	
	@Test
	public void testSize2() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		mapa.put("Filip", 22);
		assertEquals(4, mapa.size());
	}
	
	@Test
	public void testClear() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		mapa.clear();
		assertEquals(0,mapa.size());
	}

	@Test
	public void testFunctionPutKeyIsNull() {
		Dictionary<Integer, String> dictionary= new Dictionary<>();
		assertThrows(NullPointerException.class, ()-> dictionary.put(null, "zmaj"));
	}
	@Test
	public void testGetMetodaNullPointerEx() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertThrows(NullPointerException.class, ()->mapa.get(null));
	}
	
	@Test
	public void testGetMetoda() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(21, mapa.get("Filip"));
	}
	
	@Test
	public void testGetMetodaVratiNULL() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(null, mapa.get("Ante"));
	}
	
	
	@Test
	public void testRemove() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		mapa.remove("Filip");
		assertEquals(null, mapa.get("Filip"));
		assertEquals(3,mapa.size());
	}
	
	@Test
	public void testRemoveNepostojeciElement() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		mapa.put("Filip", 21);
		mapa.put("Maja", 22);
		mapa.put("Luka", 33);
		mapa.put("Josip", 11);
		assertEquals(null,mapa.remove("Ante"));
		assertEquals(4,mapa.size());
	}
	
	@Test
	public void testRemovePredanNULL() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		assertThrows(NullPointerException.class, ()->mapa.remove(null));
	}
	
	@Test
	public void testStringIspis() {
		Dictionary<String, Integer> mapa = new Dictionary<>();
		assertEquals("", mapa.toString());
	}
}
