package hr.fer.oprpp1.custom.collections;
/**
 * Sučelje <code>ElementsGetter</code> korisnicima daje osnovni paket apstraktnih 
 * metoda koje neki razred treba nadjačati.
 * 
 * @author Filip
 *
 */
public interface ElementsGetter<E> {
	/**
	 * Apstraktna metoda.
	 * Ispituje ima li kolekcija sljedeći član.
	 * 
 	 * @return boolean <code>true</code> ako kolekcija ima sljedeći član.
 	 * 				   <code>false</code> inače.
	 */
	boolean hasNextElement();
	
	/**
	 * Apstraktna metoda.
	 * Vraća sljedeći element kolekcije.
	 * 
	 * @return E sljedeći element kolekcije.
	 */
	E getNextElement();
	
	
	/**
	 * Default metoda koja prima kao argument referencu na Processor i koristi njezinu
	 * metodu process nad svim elementima kolekcije.
	 * 
 	 * @param p referenca na instancu klase Processor
 	 * @return void
	 */
	default void processRemaining(Processor<E> p) {
		while(this.hasNextElement()) {
			p.process(this.getNextElement());
		}
	}
}
