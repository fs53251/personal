package hr.fer.oprpp1.custom.collections;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Razred <code>SimpleHashtable</code> je implementacija razreda parametriziranog 
 * parametrima K i V. Razred predstavlja tablicu raspršenog adresiranja 
 * koja omogućava pohranu uređenih parova (ključ, vrijednost). Parametar K je tip ključa, 
 * parametar V je tip vrijednosti.
 * @author Filip
 *
 * @param <K> parametar Ključa
 * @param <V> parametar Vrijednosti
 */
public class SimpleHashtable<K,V> implements Iterable<SimpleHashtable.TableEntry<K, V>>{
	/**
	 * Polje parova koji su implementirani klasom TableEntry. Predstavlja polje "slotova", polje referenci
	 * na početni par u slotu.
	 */
	TableEntry<K,V>[] tablica;
	
	/**
	 * Broj dodanih parova u mapi.
	 */
	int size=0;
	
	/**
	 * Varijabla koja broji modifikacije nad strukturom mape.
	 */
	private int modificationCount=0;
	
	/**
	 * Razred <code>TableEntry</code> predstavlja par ključa i vrijednosti te pokazivača 
	 * na sljedeći par u slotu. Primjerci ovog razreda imaju člansku varijablu key u kojoj 
	 * pamte predani ključ, člansku varijablu value u kojoj pamte pridruženu vrijednost te člansku varijablu next
	 * koja pokazuje na sljedeći primjerak razreda TableEntry<K,V> koji se nalazi u istom slotu tablice 
	 * @author Filip
	 *
	 * @param <K> parametar Ključa
	 * @param <V> parametar Vrijednosti
	 */
	public static class TableEntry<K,V>{
		/**
		 * Varijabla čuva ključ
		 */
		private K key;
		
		/**
		 * Varijabla čuva vrijednost
		 */
		private V value;
		
		/**
		 * Referenca na sljedeći par u slotu, <code>null</code> ako ne postoji.
		 */
		private TableEntry<K,V> next;
		
		/**
		 * Konstruktor.
		 * 
		 * @param key ključ mape
		 * @param value vrijednost zapisana pod ključem
		 * @param next pokazivač na sljedeći par u slotu
		 */
		public TableEntry(K key, V value, TableEntry<K, V> next) {
			super();
			this.key = key;
			this.value = value;
			this.next = next;
		}
		/**
		 * getter članske varijable value.
		 * @return
		 */
		public V getValue() {
			return value;
		}
		
		/**
		 * setter članske varijable value.
		 * @return
		 */
		public void setValue(V value) {
			this.value = value;
		}
		
		/**
		 * getter članske varijable key.
		 * @return
		 */
		public K getKey() {
			return key;
		}
	}
	
	/**
	 * Konstruktor koji prima inicijalni kapacitet tablice raspršenog adresiranja.
	 * @param capacity kapacitet polja tablica.
	 * @throws IllegalArgumentException ako je predan kapacitet manji od 1
	 */
	@SuppressWarnings("unchecked")
	public SimpleHashtable(int capacity) {
		if(capacity<1) throw new IllegalArgumentException();
		capacity=(int)Math.pow(2,Math.ceil(Math.log(capacity)/Math.log(2)));
		this.tablica=(TableEntry<K,V>[])new TableEntry[capacity];
	}
	
	/**
	 * Defaultni konstruktor koji delegira postavljanje inicijalnog kapaciteta na drugi 
	 * konstruktor.
	 */
	public SimpleHashtable() {
		this(16);
	}
	
	/**
	 * Metoda postavlja svaki slot na null, u tablici ukljanja 
	 * pokazivače na prve parove slotova.
	 */
	public void clear() {
		modificationCount++;
		for(int i=0; i<tablica.length; i++) {
			tablica[i]=null;
		}
		this.size=0;
	}
	
	/**
	 * Metoda predani ključ postavlja na predanu vrijednost. Na temelju ključa računa 
	 * slot i postavlja ključ. Ako je popunjenost veća od 75%, kapacitet tablice raspršenog 
	 * adresiranja se udvostruči.
	 * @param key predani ključ
	 * @param value vrijednost za zadani ključ
	 * @return V stara vrijednost pod ključem key, ili null ako nije postojao
	 * 			zapis o ključu u mapi
	 * @throws NullPointerException ako je kao ključ predan null
	 */
	public V put(K key, V value) {
		if(key==null) throw new NullPointerException();
		double popunjenost=(double)this.size/this.tablica.length;
		
		if(popunjenost >= 0.75) {
			//kapacitet tablice x2
			modificationCount++;
			udvostruciKapacitet();
		}
		
		int brojSlota=Math.abs(key.hashCode())%tablica.length;
		
		if(tablica[brojSlota]==null) {
			this.size++;
			tablica[brojSlota]=new TableEntry<K,V>(key,value, null);
			modificationCount++;
			return null;
		}
		
		TableEntry<K,V> dohvatiSlot=tablica[brojSlota];
		TableEntry<K,V> prev;
		do {
			if(dohvatiSlot.key.equals(key)) {
				V dohvacenaVrijednost=dohvatiSlot.value;
				dohvatiSlot.setValue(value);
				return dohvacenaVrijednost;
			}
			prev=dohvatiSlot;
			dohvatiSlot=dohvatiSlot.next;
		}while(dohvatiSlot!=null);
		prev.next=new TableEntry<K,V>(key,value,null);
		modificationCount++;
		this.size++;
		return null;
	}
	
	/**
	 * Metoda udvostručuje kapacitet tablice raspršenog adresiranja.
	 * Trenutnu mapu čisti i stvara novo polje tablica.
	 */
	@SuppressWarnings("unchecked")
	private void udvostruciKapacitet() {
		TableEntry<K,V>[] polje=this.toArray();
		this.clear();
		this.size=0;
		this.tablica=(TableEntry<K,V>[])new TableEntry[this.tablica.length*2];
		for(int i=0; i<polje.length; i++) {
			TableEntry<K,V> el=polje[i];
			if(el==null) continue;
			this.put(el.getKey(), el.getValue());
		}
	}
	
	/**
	 * Dovaća vrrijednost za zadani ključ. Računa slot na temelju ključa i
	 * u tom slotu traži predani kjuč.
	 * 
	 * @param key ključ za koji traži vrijednost
	 * @return V vrijednost pod zadanim ključem u mapi,
	 * 		<code>null</code> ako zapis ne postoji u mapi za predani ključ
	 */
	public V get(Object key) {
		if(key==null) return null;
		int brojSlota=Math.abs(key.hashCode())%tablica.length;
		TableEntry<K,V> dohvatiSlot=tablica[brojSlota];
		if(dohvatiSlot==null) return null;
		do {
			if(dohvatiSlot.key.equals(key)) {
				return dohvatiSlot.getValue();
			}
			dohvatiSlot=dohvatiSlot.next;
		}while(dohvatiSlot!=null);
		return null;
	}
	
	/**
	 * Vraća broj dodanih parova u mapi.
	 * @return int 
	 */
	public int size() {
		return this.size;
	}
	
	/**
	 * Metoda provjerava je li zadani ključ u mapi.
	 * @param key predani ključ
	 * @return boolean <code>true</code> ako ključ ima zapis u mapi
	 * 				   <code>false</code> inače.
	 */
	public boolean containsKey(Object key) {
		if(key==null) return false;
		int brojSlota=Math.abs(key.hashCode())%tablica.length;
		TableEntry<K,V> dohvatiSlot=tablica[brojSlota];
		if(dohvatiSlot==null) return false;
		do {
			if(dohvatiSlot.key.equals(key)) {
				return true;
			}
			dohvatiSlot=dohvatiSlot.next;
		}while(dohvatiSlot!=null);
		return false;
	}
	
	/**
	 * Metoda provjerava je li zadana vrijednost u mapi.
	 * @param value predana vrijednost 
	 * @return boolean <code>true</code> ako vrijednost ima zapis u mapi
	 * 				   <code>false</code> inače.
	 */
	public boolean containsValue(Object value) {
		for(int i=0;i<tablica.length; i++) {

			TableEntry<K,V> dohvatiSlot=tablica[i];
			if(dohvatiSlot==null) continue;
			do {
				if((value==null && dohvatiSlot.getValue()==null) || dohvatiSlot.getValue().equals(value)) {
					return true;
				}
				dohvatiSlot=dohvatiSlot.next;
			}while(dohvatiSlot!=null);

		}
		return false;
	}
	
	/**
	 * /**
	 * Metoda uklanja par iz mape pod ključem predanim u argumentu.
	 * Ako je kao ključ predan null, vraća null.
	 * 
	 * @param key predani ključ koji želimo ukloniti iz mape
	 * @return V vrijednost koja piše pod zadanim ključem
	 * 			<code>null</code> ako zapis o ključu ne postoji u mapi.
	 */
	public V remove(Object key) {
		if(key==null) return null;
		int brojSlota=Math.abs(key.hashCode())%tablica.length;
		TableEntry<K,V> dohvatiSlot=tablica[brojSlota];
		if(dohvatiSlot==null) return null;
		
		TableEntry<K,V> prev=dohvatiSlot;
		int brojac=0;
		do {
			brojac++;
			if(dohvatiSlot.key.equals(key)) {
				V dohvatiVrijednost=dohvatiSlot.getValue();
				if(brojac==1) {
					tablica[brojSlota]=dohvatiSlot.next;
					dohvatiSlot.next=null;
					dohvatiSlot=null;
					this.size--;
					modificationCount++;
					return dohvatiVrijednost;
				}else {
					prev.next=dohvatiSlot.next;
					dohvatiSlot.next=null;
					dohvatiSlot=null;
				}
				this.size--;
				modificationCount++;
				return dohvatiVrijednost;
			}
			prev=dohvatiSlot;
			dohvatiSlot=dohvatiSlot.next;
		}while(dohvatiSlot!=null);
		return null;
	}
	
	/**
	 * Metoda provjerava je li mapa prazna.
	 * @return boolean <code>true</code> ako je prazna mapa
	 * 			       <code>false</inače>.
	 */
	public boolean isEmpty() {
		return this.size==0;
	}
	
	/**
	 * Metoda koja omogućuje ispis mape. Prolazi po slotovima i
	 * svaki element ispisuje kao par ključa i vrijednosti.
	 * 
	 * @return String konačni ispis cijele mape
	 */
	@Override
	public String toString() {
		StringBuilder sb=new StringBuilder();
		sb.append("[");
		for(int i=0;i<tablica.length; i++) {
			
			TableEntry<K,V> dohvatiSlot=tablica[i];
			if(dohvatiSlot==null) continue;
			do {
				sb.append(String.format("%s=%s, ", dohvatiSlot.getKey(), dohvatiSlot.getValue()));
				dohvatiSlot=dohvatiSlot.next;
			}while(dohvatiSlot!=null);
		}
		String ispis=sb.toString();
		try{
			ispis=ispis.substring(0,ispis.length()-2)+"]";
			return ispis;
		}catch(StringIndexOutOfBoundsException e) {
			return "[]";
		}
	}
	
	/**
	 * Metoda vraća polje parova, prolazi po slotovima i parove
	 * dodaje u polje.
	 * 
	 * @return polje parova
	 */
	public TableEntry<K,V>[] toArray(){
		@SuppressWarnings("unchecked")
		TableEntry<K,V>[] polje=(TableEntry<K,V>[])new TableEntry[this.size];
		int brojac=0;
		for(int i=0;i<tablica.length; i++) {
			TableEntry<K,V> dohvatiSlot=tablica[i];
			if(dohvatiSlot==null) continue;
			do {
				polje[brojac++]=dohvatiSlot;
				dohvatiSlot=dohvatiSlot.next;
			}while(dohvatiSlot!=null);
		}
		return polje;
	}

	/**
	 * Metoda vraća referencu na iterator koji prolazi elemntima mape.
	 */
	@Override
	public Iterator<TableEntry<K, V>> iterator() {
		return new IteratorImpl();
	}
	
	/**
	 * Razred <code>Iterator</code> predstavlja klasu koja implementira sučelje 
	 * iterator. Omogućuje obilazak kroz parove mape u tablici raspršenog 
	 * adresiranja.
	 * @author Filip
	 *
	 */
	private class IteratorImpl implements Iterator<SimpleHashtable.TableEntry<K, V>>{
		/**
		 * Varijabla čuva broj dohvaćenih parova mape.
		 */
		private int current=0;
		
		/**
		 * Varijabla čuva broj slota iz kojeg trenutno dohvaćamo elemente.
		 */
		private int currentSlotNumber=0;
		/**
		 * Referenca na par u slotu kojeg smo trenutno dohvatili.
		 */
		private TableEntry<K,V> currentTableEntry;

		/**
		 * Varijabla koja pamti je li pozvana metoda next od instanciranja
		 * iteratora.
		 */
		private boolean pozvanNext=false;
		
		/**
		 * Varijabla koja pamti smije li se pozvati metoda remove() nad mapom
		 */
		private boolean smijemPozvati=true;
		
		/**
		 * Varijabla dohvaća broj modifikacija nad mapom u trenutku instanciranja
		 * ovog iteratora.
		 */
		private int pamtiModifikaciju=SimpleHashtable.this.modificationCount;
		
		/**
		 * Varijabla dohvaća broj elemenata u mapi tijekom instanciranja ovog
		 * iteratora.
		 */
		private int velicinaPolja= SimpleHashtable.this.size;
		
		/**
		 * Metoda provjerava postoji li nedohvaćeni par u mapi.
		 * @return <code>true</code> ako postoji jos parova za dohvatiti,
		 * 		   <code>false</code> inače.
		 * @throws ConcurrentModificationException ako je došlo do
		 * modifikacije mape tijekom rada iteratora.
		 */
		@Override
		public boolean hasNext() {
			if(dosloJeDoModifikacije()) throw new ConcurrentModificationException();
			return current<velicinaPolja;
		}

		/**
		 * Metoda dohvaća sljedeći par u mapi. Prolazi kroz slotove i traži koji
		 * je trenutni par dohvaćen te uzima njegovog susjeda. Ako susjed ne postoji
		 * ide se na sljedeće slotove.
		 * @return par koji je dohvaćen
		 * @throws ConcurrentModificationException ako je došlo do
		 * modifikacije mape tijekom rada iteratora.
		 * 
		 */
		@Override
		public TableEntry<K, V> next() {
			if(dosloJeDoModifikacije()) throw new ConcurrentModificationException();
			pozvanNext=true;
			smijemPozvati=true;
			if(!hasNext()) throw new NoSuchElementException();
			TableEntry<K,V> element=SimpleHashtable.this.tablica[currentSlotNumber];
			while(element==null) {
				element=SimpleHashtable.this.tablica[++currentSlotNumber];
			}
			
			if(currentTableEntry==null) {
				currentTableEntry=element;
				current++;
				return element;
			}else {
				TableEntry<K,V> dohvatiEntry=element;
				do {
					if(dohvatiEntry.equals(currentTableEntry)) {
						if(dohvatiEntry.next==null) {
							++currentSlotNumber;
							return next();
						}else {
							currentTableEntry=dohvatiEntry.next;
							current++;
							return currentTableEntry;
						}
					}
					dohvatiEntry=dohvatiEntry.next;
				}while(dohvatiEntry!=null);
				currentTableEntry=element;
				current++;
				return element;
			}
			
		}
		
		/**
		 * Metoda uklanja trenutno dohvaćeni element iz mape.
		 * Smije se pozvati samo jednom nakon poziva metode next.
		 * @throws ConcurrentModificationException ako je došlo do
		 * modifikacije mape tijekom rada iteratora.
		 */
		@Override
		public void remove() {
			if(dosloJeDoModifikacije()) throw new ConcurrentModificationException();
			this.pamtiModifikaciju++;
			if(pozvanNext && smijemPozvati) {
				smijemPozvati=false;
				SimpleHashtable.this.remove(currentTableEntry.getKey());
			}else {
				throw new IllegalStateException();
			}

		}
		
		/**
		 * Metoda provjerava je li došlo do modifikacije u mapi tijekom 
		 * rada iteratora.
		 * @return boolean <code>true</code> ako postoje modifikacije
		 * 				   <code>false</code> inače.
		 */
		public boolean dosloJeDoModifikacije() {
			return this.pamtiModifikaciju!=SimpleHashtable.this.modificationCount;
		}
	}
}
