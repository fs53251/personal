package hr.fer.oprpp1.custom.collections;

import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;

/**
 * Razred <code>LinkedListIndexedCollection</code> korisnicima daje
 * dvostruko povezanu kolekciju objekata.
 * 
 * <p>Kolekcija čuva reference na početni i završni čvor. Smanjena je složenost dodavanja
 * elemenata na početak i kraj liste na O(1).</p>
 * 
 * @author Filip
 *
 */
public class LinkedListIndexedCollection<E> implements List<E>{
	
	/**
	 * Razred <code>ListNode</code> predstavlja čvor u dvostruko povezanoj listi.
	 * Sadrži pokazivače na prethodni i sljedeći čvor te čuva vrijednost nekog objekta.
	 * 
	 * @author Filip
	 *
	 */
	private static class ListNode<E>{
		ListNode<E> previous=null;
		ListNode<E> next=null;
		E value;
		public ListNode(E value) {
			this.value=value;
		}
	}
	
	private int size;
	ListNode<E> first;
	ListNode<E> last;
	private long modificationCount=0L;
	
	/**
	 * Metoda konstruktor, kao argument prima Kolekciju i njene elemente 
	 * dodaje u dvostruko povezanu listu.
	 * 
	 * @param other Kolekcija čije elemente treba dodati u listu
	 */
	public LinkedListIndexedCollection(Collection<? extends E> other) {
		this.addAll(other);
	}
	
	/**
	 * Metoda defaultni konstruktor, inicijalizira reference prvog i zadnjeg 
	 * čvora dvostruko povezane liste.
	 */
	public LinkedListIndexedCollection() {
		this.first=this.last=null;
		this.size=0;
	}
	
	
	/**
	 * Metoda vraća broj dodanih elemenata u dvostruko povezanu listu.
	 * 
	 * @return <code>int</code> broj elemenata
	 */
	@Override
	public int size() {
		return this.size;
	}
	
	
	/**
	 * Metoda dodaje Objekt, predan kao argument, na kraj liste.
	 * Složenost dodavanja elementa je O(1). 
	 * Argument ne smije biti <code>null</code>.
	 * 
	 * Posebna provjera ako se dodaje element u praznu listu.
	 * @param value objekt koji je potrebno dodati
	 * @return <code>void</code>
	 * @throws NullPointerException ako se kao argument preda 
	 * 		   vrijednost <code>null</code>
	 */
	@Override
	public void add(E value) {
		if(value==null) throw new NullPointerException();
		ListNode<E> end=new ListNode<E>(value);
		if(first==null) {
			first=end;
			last=end;
		}else {
			last.next=end;
			end.previous=last;
			last=end;
		}
		this.size++;
		this.modificationCount++;
	}
	
	
	/**
	 * Metoda traži Objekt, predan kao arguemnt, u dvostruko povezanoj listi.
	 * Složenost traženja elementa je O(n).
	 * 
	 * @param value objekt koji tražimo u listi
	 * @return <code>true</code> ako je predani argument u listi;
	 * 		   <code>false</code> ako se element ne nalazi u listi ili 
	 * 		   je predan <code>null</code>. 
	 */
	@Override
	public boolean contains(Object value) {
		if(value==null) return false;
		boolean con=false;
		ListNode<E> tmp=first;
		for(int i=0; i<this.size; i++) {
			if(tmp.value.equals(value)) {
				con=true;
				break;
			}
			tmp=tmp.next;
		}
		return con;
	}
	
	
	/**
	 * Metoda vadi Objekt, predan kao argument, iz dvostuko povezane liste. Za ispitivanje 
	 * jednakosti objekata se oslanja na metodu equals.
	 * Složenost micanja objekta van liste je O(n). Argument ne smije 
	 * biti <code>null</code>
	 * 
	 * @param value objekt koji treba izbaciti iz liste
	 * @return <code>true</code> ako je predani argument izbačen iz liste;
	 * 		   <code>false</code> inače.
	 * @throws NullPointerException ako se kao argument preda 
	 * 		   vrijednost <code>null</code>.
	 */
	@Override
	public boolean remove(Object value) {
		if(value==null) throw new NullPointerException();

		boolean removed=false;
		ListNode<E> tmp=first;
		for(int i=0; i<this.size; i++) {
			if(tmp.value.equals(value)) {
				removed=true;
				if(i==0) {
					first=first.next;
					first.previous=null;
				}else if(i==this.size-1) {
					last=last.previous;
					last.next=null;
				}else {
					tmp.previous.next=tmp.next;
					tmp.next.previous=tmp.previous;
					tmp.next=tmp.previous=null;
				}	
				
			}
			tmp=tmp.next;
		}
		this.size--;
		this.modificationCount++;
		return removed;
	}
	
	
	/**
	 * Metoda alocira polje veličine kolekcije te puni polje njenim elementima.
	 * Složenost ove metode je O(n).
	 * 
	 * @return Object[] polje objekata
	 */
	@Override
	public Object[] toArray() {
		Object[] list=new Object[this.size];
		ListNode<E> tmp=first;
		
		for(int i=0; i<this.size; i++) {
			list[i]=tmp.value;
			tmp=tmp.next;
		}
		return list;
	}
	
	/**
	 * Metoda briše sve elemente dvostruko povezane liste.
	 * Složenost metode je O(1).
	 * 
	 */
	@Override
	public void clear() {
		this.first=this.last=null;
		this.size=0;
		this.modificationCount++;
	}
	
	/**
	 * Metoda dohvaća objekt liste na poziciji index.
	 * Argument može biti bilo koji cijeli broj koji 
	 * odgovara poziciji nekog	objekta u listi, inače 
	 * javlja iznimku.
	 * Složenost metode je O(n/2+1) ~ O(n).
	 * 
	 * @param index broj pozicije elementa u listi
	 * @return Object traženi objekt na poziciji index
	 * @throws IndexOutOfBoundsException ako predani index nije između 
	 * 			0 i indexa zadnjeg elementa liste.
	 */
	public E get(int index) {
		if(index<0 || index>=this.size) throw new IndexOutOfBoundsException();
		
		int middle=this.size/2;
		if(index<middle) {
			ListNode<E> tmp=first;
			for(int i=0; i<index; i++) {
				tmp=tmp.next;
			}
			return tmp.value;
		}else {
			ListNode<E> tmp=last;
			for(int i=this.size-1; i>index; i--) {
				tmp=tmp.previous;
			}
			return (E)tmp.value;
		}
	}
	
	/**
	 * Metoda ubacuje objekt u dvostuko povezanu listu,	na poziciju predanu kao argument.
	 * Pozicija ne smije biti van granica 0 i broja elemenata u listi.
	 * Objekt koji predajemo kao argument ne smije biti <code>null</code>.
	 * Složenost dodavanja objekta na početak ili kraj liste je O(1),
	 * inače O(n).
	 * 
	 * @param value predani objekt koji treba dodati u listu
	 * @param position pozicija na koju želimo ubaciti objekt,
	 * 		  objekt koji se nalazio do sada na toj poziciji, 
	 * 		  poprima index position+1.
	 * @throws NullPointerException ako je predan <code>null</code> kao objekt.
	 * @throws IndexOutOfBoundsException ako nije predana pozicija unutar granica elemenata liste.
	 */
	public void insert(E value, int position) {
		if(value==null) throw new NullPointerException();
		if(position<0 || position>this.size) throw new IndexOutOfBoundsException();
		if(this.size==0) {
			this.add(value);
		}
		
		ListNode<E> newNode=new ListNode<E>(value);
		
		if(position==0) {
			first.previous=newNode;
			newNode.next=first;
			first=newNode;
		}else if(position==this.size) {
			last.next=newNode;
			newNode.previous=last;
			last=newNode;
		}else {
			//insert in O(n/2+1)
			int middle=this.size/2;
			ListNode<E> tmp;
			if(position<middle) {
				tmp=first;
				for(int i=0; i<position; i++) {
					tmp=tmp.next;
				}
			}else {
				tmp=last;
				for(int i=this.size-1; i>position; i--) {
					tmp=tmp.previous;
				}
			}
			ListNode<E> neighbourLeft=tmp.previous;
			neighbourLeft.next=newNode;
			newNode.previous=neighbourLeft;
			tmp.previous=newNode;
			newNode.next=tmp;
			this.size++;
			this.modificationCount++;
		}
	}
	
	
	/**
	 * Metoda vraća poziciju objekta, predanog kao argument, u dvostruko povezanoj listi.
	 * Složenost metode je O(n). Argument može biti bilo koji objekt.
	 * 
	 * @param value objekt za koji metoda traži poziciju u listi
	 * @return pozicija predanog objekta u listi
	 */
	public int indexOf(Object value) {
		if(value==null) return -1;
		int index=-1;
		ListNode<E> tmp=first;
		for(int i=0; i<this.size; i++) {
			if(tmp.value.equals(value)) {
				index=i;
				break;
			}
			tmp=tmp.next;
		}
		return index;
	}
	
	/**
	 * Metoda vadi element dvostruko povezane liste, na poziciji koja je predana kao argument.
	 * Argument je bilo koji cijeli broj koji predstavlja poziciju elementa u listi kojeg 
	 * treba ukloniti.
	 * 
	 * @param index predana pozicija
	 * @throws IndexOutOfBoundsException ako predana pozicija nije unutar 
	 * 		   granica 0 i pozicije zadnjeg elementa liste.
	 */
	public void remove(int index) {
		if(index<0 || index>=this.size) throw new IndexOutOfBoundsException();
		
		if(index==0) {
			first=first.next;
			first.previous=null;
		}else if(index==this.size-1) {
			last=last.previous;
			last.next=null;
		}else {
			ListNode<E> tmp=first;
			for(int i=0; i<index; i++) {
				tmp=tmp.next;
			}
			tmp.previous.next=tmp.next;
			tmp.next.previous=tmp.previous;
			tmp.next=tmp.previous=null;
		}
		this.size--;
		this.modificationCount++;
	}
	
	/**
	 * Metoda koja vraća kapacitet dvostruko povezane liste.
	 * Predstavlja getter članske varijable size.
	 * 
	 * @return size broj elemenata liste.
	 */
	public int capacity() {
		return this.size;
	}

	/**
	 * Metoda vraća referencu na instancu razreda koji implementira sučelje ElementsGetter.
	 * 
	 * @return ElementsGetter
	 */
	@Override
	public ElementsGetter<E> createElementsGetter() {
		return new EG<E>(this);
	}
	
	/**
	 * Privatni statički razred <code>EG</code> predstavlja implementaciju 
	 * ElementsGettera koji zna dohvaćati i vraćati elemente.
	 * 
	 * @author Filip
	 *
	 */
	private static class EG<E> implements ElementsGetter<E>{
		private LinkedListIndexedCollection<E> ll;
		
		/**
		 * Varijabla koja čuva referencu na čvor liste na kojem smo trenutno.
		 */
		private ListNode<E> next;
		
		/**
		 * Varijabla koja pamti broj modifikacija kako bi znali je li kolekcija strukturno mijenjana
		 */
		private long savedModificationCount;
		
		/**
		 * Konstruktor
		 * 
		 * @param ar referenca na polje elemenata čije elemente želi dohvaćati.
		 */
		public EG(LinkedListIndexedCollection<E> ll) {
			this.ll=ll;
			next=ll.first;
			savedModificationCount=ll.modificationCount;
		}
		
		/**
		 * Metoda koja ispituje, postoji li sljedeći element u kolekciji.
		 * 
		 * @return boolean <code>true</code> ako postoji sljedeći element.
		 * 				   <code>false</code> inače.
		 */
		@Override
		public boolean hasNextElement() {
			return next!=null;
		}
	
		
		/**
		 * Metoda vraća element kolekcije na koji pokazuje varijabla nextIndex.
		 * Provjerava se je li se dogodila modifikacija nakon stvaranja instance razreda. 
		 * 
		 * @return Object element kolekcije.
		 * @throws ConcurrentModificationException ako je modificirana lista, nakon stvaranja instance 
		 * 											razreda EG.
		 */
		@Override
		public E getNextElement() {
			if(this.savedModificationCount!=ll.modificationCount)
				throw new ConcurrentModificationException();
			
			if(next==null) {
				throw new NoSuchElementException();
			}
			
			ListNode<E> tmp=next;
			next=next.next;
			return (E)tmp.value;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T[] toArray(T[] a) {
		if(a.length <this.size)
			a=(T[])java.lang.reflect.Array.newInstance(a.getClass().getComponentType(),
					this.size);
		int i=0;
		Object[] result=a;
		for(ListNode<E> x=first;x!=null; x=x.next)
			result[i++]=x.value;
		if(a.length>this.size) {
			a[size]=null;
		}
		return a;
	} 
}




















