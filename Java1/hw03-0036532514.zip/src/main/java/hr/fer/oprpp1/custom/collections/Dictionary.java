package hr.fer.oprpp1.custom.collections;

/**
 * Razred <code>Dictionary</code> je parametrizirani razred. Parametriziran je po 
 * tipovima K i V. Razred predstavlja kolekciju mape/rječnika. Tip K predstavlja ključ, 
 * a V predstavlja vrijednost. Kao internu kolekciju koristi ArrayIndexedList i u njoj čuva
 * instance objekata tipa Pair.
 * 
 * @author Filip
 *
 * @param <K> tip Ključ
 * @param <V> tip Vrijednost
 */
public class Dictionary<K,V>{
	/**
	 * Interna kolekcija kojom ostvarujemo mapu. U njoj čuvamo parove ključa i vrijednosti.
	 */
	private ArrayIndexedCollection<Pair<K,V>> polje=new ArrayIndexedCollection<>();
	
	/**
	 * Razred <code>Pair</code> je privatni statički unutarnji razred. Predstavlja 
	 * par vrijednosti (K ključ, V vrijednost)
	 * @author Filip
	 *
	 * @param <K> tip Ključ
	 * @param <V> tip Vrijednost
	 */
	private static class Pair<K,V>{
		K key;
		V value;
		
		/**
		 * Konstruktor. Postavlja članske varijable key i value na vrijedsnoti
		 * predane u argumentom.
		 * 
		 * @param key ključ koji ne smije biti null
		 * @param value vrijednost koju pamtimo pod ključem
		 * @throws NullPointerException ako kao ključ predamo null 
		 */
		public Pair(K key, V value) {
			super();
			if(key==null) throw new NullPointerException();
			this.key = key;
			this.value = value;
		}
		
		/**
		 * getter članske varijable key
		 * @return key
		 */
		public K getKey() {
			return key;
		}
		
		/**
		 * setter članske varijable key
		 * @return void
		 */
		public void setKey(K key) {
			this.key = key;
		}
		
		/**
		 * getter članske varijable value
		 * @return value
		 */
		public V getValue() {
			return value;
		}
		
		/**
		 * setter članske varijable value
		 * @return void
		 */
		public void setValue(V value) {
			this.value = value;
		}
	}
	
	
	/**
	 * Metoda provjerava je li mapa prazna. Oslanja se na poziv metode size nad
	 * internom kolekcijom ArrayIndexedList.
	 * 
	 * @return boolean <code>true</code> ako je mapa prazna,
	 * 				   <code>false</code> inače.
	 */
	public boolean isEmpty() {
		return polje.size()==0;
	}
	
	/**
	 * Metoda vraća broj dodanih parova u mapi.
	 * 
	 * @return int broj elemenata u mapi
	 */
	public int size() {
		return polje.size();
	}
	
	/**
	 * Metoda čisti cijelu mapu. Oslanja se na poziv metode clear nad 
	 * unutarnjom kolekcijom.
	 */
	public void clear() {
		polje.clear();
	}
	
	/**
	 * Metoda vraća vrijednost za zadani ključ u mapi. Ključ ne smije biti null.
	 * Polje se obilazi stvaranjem iteratora nad kolekicjom.
	 * 
	 * @param key ključ za kojeg tražimo je li u mapi i želimo njegovu vrijednost
	 * @return V vrijednost pod ključem key,
	 * 			ako ne postoji zapis pod tim ključem, vraća <code>null<code>
	 * @throws NullPointerException ako je kao key predana vrijednost null.
	 */
	public V get(Object key) {
		if(key==null) throw new NullPointerException();
		ElementsGetter<Pair<K,V>> iterator=polje.createElementsGetter();
		while(iterator.hasNextElement()) {
			Pair<K,V> par=iterator.getNextElement();
			if(par.getKey().equals(key)) return par.getValue();
		}
		return null;
	}
	
	/**
	 * Metoda za dani ključ postavlja vrijednost u mapi te vraća null. Ako 
	 * već postoji ključ u mapi, vrijednost se pregazi i vrati, a na trenutnu 
	 * vrijednost se postavi ona iz argumenta.
	 * 
	 * @param key ključ čiju vrijednost želimo mijenjati/postaviti
	 * @param value vrijednost za ključ key
	 * @return V vrijednost koja je do sad bila zapisana pod ključem key,
	 * 		<code>null</code> ako nije bilo zapisa pod tim ključem
	 * @throws NullPointerException ako je kao ključ predan <code>null</code>
	 */
	public V put(K key, V value) {
		if(key==null) throw new NullPointerException();
		ElementsGetter<Pair<K,V>> iterator=polje.createElementsGetter();
		while(iterator.hasNextElement()) {
			Pair<K,V> par=iterator.getNextElement();
			if(par.getKey().equals(key)) {
				V temp=par.getValue();
				par.setValue(value);
				return temp;
			}
		}
		polje.add(new Pair<K,V>(key,value));
		return null;
	}
	
	/**
	 * Metoda uklanja par iz mape pod ključem predanim u argumentu.
	 * Ne smije biti predan null kao ključ.
	 * 
	 * @param key predani ključ koji želimo ukloniti iz mape
	 * @return V vrijednost koja piše pod zadanim ključem
	 * 			<code>null</code> ako zapis o ključu ne postoji u mapi.
	 * @throws NullPointerException ako je kao ključ predano <code>null</code>
	 */
	public V remove(K key) {
		if(key==null) throw new NullPointerException();
		ElementsGetter<Pair<K,V>> iterator=polje.createElementsGetter();
		while(iterator.hasNextElement()) {
			Pair<K,V> par=iterator.getNextElement();
			if(par.getKey().equals(key)) {
				V temp=par.getValue();
				polje.remove(par);
				return temp;
			}
		}
		return null;
	}
	
	/**
	 * Metoda koja omogućuje ispis mape. Prolazi po internoj
	 * kolekciji i svaki element ispisuje kao par ključa i vrijednosti.
	 * 
	 * @return String konačni ispis cijele mape
	 */
	@Override
	public String toString() {
		StringBuilder sb=new StringBuilder();
		ElementsGetter<Pair<K,V>> iterator=polje.createElementsGetter();
		while(iterator.hasNextElement()) {
			Pair<K,V> par=iterator.getNextElement();
			sb.append(String.format("Key: %s -> Value: %s\n",par.getKey(), par.getValue()));
		}
		return sb.toString();
	}
}
