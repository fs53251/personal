package hr.fer.zemris.java.gui.calc.model;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.layouts.RCPosition;

/**
 * Razred predstavlja gumbe
 * @author Filip
 *
 */
public class MyButton extends JButton{
	private static final long serialVersionUID = 1L;

	/**
	 * Vrijednost koja pise "na" buttonu
	 */
	private String naziv;
	
	/**
	 * Varijabla pozicije buttona
	 */
	private RCPosition pozicija;
	
	/**
	 * Pozadinska boja buttona
	 */
	private static Color pozadina = new Color(221, 221, 255);
	
	/**
	 * Font kojim se prikazuju brojevi
	 */
	private static Font fontBrojevi = new Font("Sans Serif", Font.BOLD, 30);
	
	/**
	 * Font kojim se prikazuju operacije
	 */
	private static Font fontOperacije = new Font("Sans Serif", Font.PLAIN, 25);
	
	/**
	 * Polje koje cuva brojeve kao buttone
	 */
	private static List<MyButton> brojevi = new ArrayList<>();
	
	/**
	 * Konstruktror
	 * @param naziv
	 * @param pozicija
	 */
	public MyButton(String naziv, RCPosition pozicija) {
		super(naziv);
		this.naziv = naziv;
		this.pozicija = pozicija;
	}
	
	/**
	 * Metoda nad buttonom registrira actionListenera, doda naziv i ostale postavke za button
	 * Doda button u containter
	 * @param al
	 * @param cp
	 */
	public void inicijalizirajButtonOperacije(ActionListener al, Container cp) {
		this.addActionListener(al);
		this.setName(this.naziv);
		this.setBackground(pozadina);
		this.setFont(fontOperacije);
		cp.add(this, this.pozicija);
	}
	
	/**
	 * Metoda dohvati broj koji se skriva iza buttona
	 * @return
	 */
	public int getBroj() {
		try {
			return Integer.parseInt(naziv);
		}catch(Exception e) {
			return -1;
		}
	}

	/**
	 * Statička metoda tvornica buttona koji su brojevi od 0 do 9
	 * @param n
	 * @param al
	 * @param cp
	 */
	public static void stvori(int n, ActionListener al, Container cp) {
			popuniListuBrojevi();
			
			for(int i = 0; i < n; i++) {
				MyButton button = brojevi.get(i);
				button.addActionListener(al);
				button.setName(button.naziv);
				button.setBackground(pozadina);
				button.setFont(fontBrojevi);
				cp.add(button, button.pozicija);
			}
	}

	private static void popuniListuBrojevi() {
		MyButton button = null;
		button = new MyButton("0", new RCPosition(5, 3));
		button.setName("0");
		brojevi.add(button);
		
		button = new MyButton("1", new RCPosition(4, 3));
		button.setName("1");
		brojevi.add(button);
		
		button = new MyButton("2", new RCPosition(4, 4));
		button.setName("2");
		brojevi.add(button);
		
		button = new MyButton("3", new RCPosition(4, 5));
		button.setName("3");
		brojevi.add(button);
		
		button = new MyButton("4", new RCPosition(3, 3));
		button.setName("4");
		brojevi.add(button);
		
		button = new MyButton("5", new RCPosition(3, 4));
		button.setName("5");
		brojevi.add(button);
		
		button = new MyButton("6", new RCPosition(3, 5));
		button.setName("6");
		brojevi.add(button);
		
		button = new MyButton("7", new RCPosition(2, 3));
		button.setName("7");
		brojevi.add(button);
		
		button = new MyButton("8", new RCPosition(2, 4));
		button.setName("8");
		brojevi.add(button);
		
		button = new MyButton("9", new RCPosition(2, 5));
		button.setName("9");
		brojevi.add(button);
	}
}
