package hr.fer.zemris.java.gui.calc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleBinaryOperator;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalcValueListener;
import hr.fer.zemris.java.gui.calc.model.CalculatorInputException;

/**
 * Razred implementacija modela kalkulatora.
 * Sve metode nadjačavaju CalcModel u kojem je detaljniji opis svake.
 * @author Filip
 *
 */
public class CalcModelImpl implements CalcModel{
	/**
	 * Varijabla pamti je li model editabilan ili nije
	 */
	private boolean editabilan = true;
	
	/**
	 * Varijabla pamti je li broj pozitivan
	 */
	private boolean pozitivan = true;
	
	/**
	 * String koji pamti trenutni unos
	 */
	private String varijabla = "";
	
	/**
	 * Numericka reprezentacija varijable
	 */
	private Double numerickaVarijabla = 0.;
	
	/**
	 * String u kojem pamtimo zamrznutu vrijednost
	 */
	private String zamrznuta = null;
	
	/**
	 * Referenca na aktivni operand, ako ne postoji onda je null
	 */
	private Double activeOperand;
	
	/**
	 * Referenca na trenutnu operaciju koja se treba izvesti
	 */
	private DoubleBinaryOperator pendingOperation;

	/**
	 * Polje promatraca
	 */
	private List<CalcValueListener> observers = new ArrayList<>();

	@Override
	public void addCalcValueListener(CalcValueListener l) {
		if(l == null) {
			throw new NullPointerException();
		}
		observers.add(l);
	}

	@Override
	public void removeCalcValueListener(CalcValueListener l) {
		if(l == null) {
			throw new NullPointerException();
		}
		observers.remove(l);
	}
	
	/**
	 * Metoda kojom javljam svim promatracima da je doslo do promjene
	 */
	public void notifyObservers() {
		for(CalcValueListener listener : observers) {
			listener.valueChanged(this);
		}
	}

	/**
	 * Metoda kojom dohvacam trenutnu varijablu
	 * @return
	 */
	public String getVarijabla() {
		return pozitivan ? varijabla : "-" + varijabla;
	}
	@Override
	public double getValue() {
		return pozitivan ? numerickaVarijabla : (-1) * numerickaVarijabla;
	}

	@Override
	public void setValue(double value) {
		pozitivan = value < 0 ? false : true;
		numerickaVarijabla = Math.abs(value);
		varijabla = String.valueOf(numerickaVarijabla);
		editabilan = false;
		notifyObservers();
	}

	@Override
	public boolean isEditable() {
		return editabilan;
	}

	@Override
	public void clear() {
		varijabla = "";
		numerickaVarijabla = 0.;
		pozitivan = true;
		editabilan = true;
		notifyObservers();
	}

	@Override
	public void clearAll() {
		varijabla = "";
		numerickaVarijabla = 0.;
		editabilan = true;
		pozitivan = true;
		freezeValue(null);
		activeOperand = null;
		pendingOperation = null;
		notifyObservers();
	}

	@Override
	public void swapSign() throws CalculatorInputException {
		if(!editabilan) {
			throw new CalculatorInputException();
		}
		pozitivan = !pozitivan;
		freezeValue(null);
		notifyObservers();
	}

	@Override
	public void insertDecimalPoint() throws CalculatorInputException {
		if(!editabilan) {
			throw new CalculatorInputException();
		}
		if(varijabla.contains(".")) {
			throw new CalculatorInputException();
		}
		
		if(varijabla.equals("") && numerickaVarijabla == 0.) {
			throw new CalculatorInputException();
		}
		String novaVarijabla = varijabla + ".";
		try {
			numerickaVarijabla = Double.parseDouble(novaVarijabla);
			varijabla = novaVarijabla;
		} catch (Exception e) {
			throw new CalculatorInputException();
		}
		freezeValue(null);
		notifyObservers();
	}

	@Override
	public void insertDigit(int digit) throws CalculatorInputException, IllegalArgumentException {
		if (!editabilan) {
			throw new CalculatorInputException();
		}
		
		if(digit < 0 || digit > 9) {
			throw new IllegalArgumentException();
		}
		
		if(varijabla.equals("0") && digit == 0) {
			return;
		}

		String novaVarijabla = varijabla + digit;
		if (novaVarijabla.length() > 308) {
			throw new CalculatorInputException();
		}

		try {
			numerickaVarijabla = Double.parseDouble(novaVarijabla);
			varijabla = novaVarijabla;
		} catch (Exception e) {
			throw new CalculatorInputException();
		}
		freezeValue(null);
		notifyObservers();
	}

	@Override
	public boolean isActiveOperandSet() {
		return activeOperand != null;
	}

	@Override
	public double getActiveOperand() throws IllegalStateException {
		if(activeOperand == null) {
			throw new IllegalStateException();
		}
		return activeOperand;
	}

	@Override
	public void setActiveOperand(double activeOperand) {
		this.activeOperand = activeOperand;
	}

	@Override
	public void clearActiveOperand() {
		this.activeOperand = null;
	}

	@Override
	public DoubleBinaryOperator getPendingBinaryOperation() {
		return pendingOperation;
	}

	@Override
	public void setPendingBinaryOperation(DoubleBinaryOperator op) {
		this.pendingOperation = op;
	}

	@Override
	public void freezeValue(String value) {
		this.zamrznuta = value;
		notifyObservers();
	}

	@Override
	public boolean hasFrozenValue() {
		return zamrznuta != null;
	}

	@Override
	public String toString() {
		if (zamrznuta != null) {
			return pozitivan ? zamrznuta : "-" + zamrznuta;
		}
		
		if (numerickaVarijabla == Double.POSITIVE_INFINITY) {
			return pozitivan ? "Infinity" : "-Infinity";
		} else if (Double.isNaN(numerickaVarijabla)) {
			return "NaN";
		}

		if (varijabla.equals("")) {
			return pozitivan ? "0" : "-0";
		} else {
			if(!varijabla.contains(".") && !varijabla.equals("0")) {
				while(varijabla.startsWith("0")) {
					varijabla = varijabla.substring(1);
				}
			}
			return pozitivan ? varijabla : "-" + varijabla;
		}

	}

}
