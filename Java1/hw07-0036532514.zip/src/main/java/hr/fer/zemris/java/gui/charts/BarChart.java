package hr.fer.zemris.java.gui.charts;

import java.util.List;
import java.util.Objects;

/**
 * Razred koji prestavlja pozadinu za crtanje dijagrama.
 * Prima polje objekata tipa XYValue i na temelju njega racuna
 * najvisi i najnizi stupac te razmak izmedu 2 susjedna stupca koji 
 * se prikazuju na osi.
 * @author Filip
 *
 */
public class BarChart {
	/**
	 * Polje objekata tipa XYValue
	 */
	List<XYValue> polje;
	
	/**
	 * Varijabla cuva opis na osi x
	 */
	String opisX;
	
	/**
	 * Varijabla cuva opis na osi y
	 */
	String opisY;
	
	/**
	 * Varijabla cuva najmanji y
	 */
	int minY;
	
	/**
	 * Varijabla cuva najvisi y
	 */
	int maxY;
	
	/**
	 * Varijabla koja cuva razmak izmedu susjednih stupaca
	 */
	int razmak;
	
	/**
	 * Konstruktor
	 * @param polje
	 * @param opisX
	 * @param opisY
	 * @param minY
	 * @param maxY
	 * @param razmak
	 */
	public BarChart(List<XYValue> polje, String opisX, String opisY, int minY, int maxY, int razmak) {
		if(!(maxY > minY)) {
			throw new IllegalArgumentException();
		}
		polje.stream().forEach((el) -> {
			if(el.getY() < minY) {
				throw new IllegalArgumentException();
			}
		});
		this.polje = polje;
		this.opisX = opisX;
		this.opisY = opisY;
		if(minY < 0) {
			throw new IllegalArgumentException();
		}else {
			int razlika = maxY - minY;
			if(razlika % razmak != 0) {
				this.minY = maxY % razmak;
			}
			this.minY = minY;
		}
		this.maxY = maxY;
		this.razmak = razmak;
	}

	/**
	 * Getter za polje
	 * @return
	 */
	public List<XYValue> getPolje() {
		return polje;
	}

	/**
	 * Setter polja
	 * @param polje
	 */
	public void setPolje(List<XYValue> polje) {
		this.polje = polje;
	}

	/**
	 * Getter
	 * @return
	 */
	public String getOpisX() {
		return opisX;
	}

	/**
	 * Setter
	 * @param opisX
	 */
	public void setOpisX(String opisX) {
		this.opisX = opisX;
	}

	/**
	 * Getter
	 * @return
	 */
	public String getOpisY() {
		return opisY;
	}

	/**
	 * Setter
	 * @param opisX
	 */
	public void setOpisY(String opisY) {
		this.opisY = opisY;
	}

	/**
	 * Getter
	 * @return
	 */
	public int getMinY() {
		return minY;
	}

	/**
	 * Setter
	 * @param opisX
	 */
	public void setMinY(int minY) {
		this.minY = minY;
	}

	/**
	 * Getter
	 * @return
	 */
	public int getMaxY() {
		return maxY;
	}

	/**
	 * Setter
	 * @param opisX
	 */
	public void setMaxY(int maxY) {
		this.maxY = maxY;
	}

	/**
	 * Getter
	 * @return
	 */
	public int getRazmak() {
		return razmak;
	}

	/**
	 * Setter
	 * @param opisX
	 */
	public void setRazmak(int razmak) {
		this.razmak = razmak;
	}

	@Override
	public String toString() {
		return "BarChart [polje=" + polje + ", opisX=" + opisX + ", opisY=" + opisY + ", minY=" + minY + ", maxY="
				+ maxY + ", razmak=" + razmak + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(maxY, minY, opisX, opisY, polje, razmak);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BarChart other = (BarChart) obj;
		return maxY == other.maxY && minY == other.minY && Objects.equals(opisX, other.opisX)
				&& Objects.equals(opisY, other.opisY) && Objects.equals(polje, other.polje) && razmak == other.razmak;
	}
	
	
}
