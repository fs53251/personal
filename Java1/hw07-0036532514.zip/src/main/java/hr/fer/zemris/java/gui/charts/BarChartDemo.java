package hr.fer.zemris.java.gui.charts;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/**
 * Razred frame, koji stvara komponentu koja iscrtava dijagram na svoju povrsinu.
 * @author Filip
 *
 */
public class BarChartDemo extends JFrame {

	private static final long serialVersionUID = 1L;
	static BarChart barChart;
	static String path;

	/**
	 * Konstruktor metoda
	 */
	public BarChartDemo() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		initGUI();
		setSize(700,550);
	}
	
	/**
	 * Metoda koja postavlja elemente prozora
	 */
	private void initGUI() {
		this.setLayout(new BorderLayout());
		BarChartComponent barChartComponent= new BarChartComponent(barChart);
		
		JLabel labela= new JLabel(path,SwingConstants.CENTER);
		this.add(labela, BorderLayout.NORTH);
		
		this.add(barChartComponent, BorderLayout.CENTER);
	}

	/**
	 * Main metoda
	 * @param args
	 */
	public static void main(String[] args) {
		String opisX;
		String opisY;
		int minY;
		int maxY;
		int razmak;
		List<XYValue> polje = new ArrayList<>();

		try (BufferedReader reader = new BufferedReader(new FileReader(args[0]))) {
			opisX = reader.readLine();
			opisY = reader.readLine();
			String[] polja = reader.readLine().split(" ");

			for (String el : polja) {
				String[] podjela = el.split(",");
				Integer element1 = Integer.parseInt(podjela[0]);
				Integer element2 = Integer.parseInt(podjela[1]);
				XYValue xy = new XYValue(element1, element2);
				polje.add(xy);
			}
			minY = Integer.parseInt(reader.readLine());
			maxY = Integer.parseInt(reader.readLine());
			razmak = Integer.parseInt(reader.readLine());
			
			barChart= new BarChart(polje, opisX, opisY, minY, maxY, razmak);
			
			
		} catch (IOException e) {
			System.out.println("greska unosa");
		}
		
		SwingUtilities.invokeLater(() -> {
			JFrame frame = new BarChartDemo();
			frame.setVisible(true);
		});

	}
}