package hr.fer.zemris.java.gui.layouts;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.util.HashMap;
import java.util.Map;

/**
 * Razred predstavlja vlastiti upravljac razmjestaja.
 * Fiksirano ima broj redaka i stupaca i implementira LayoutManager2.
 * @author Filip
 *
 */
public class CalcLayout implements LayoutManager2{
	/**
	 * Varijabla koja čuva razmak između komponenata kontejnera
	 */
	private int razmak;
	
	/**
	 * Varijabla broja redaka
	 */
	private final int redci = 5;
	
	/**
	 * Varijabla broja stupaca
	 */
	private final int stupci = 7;
	
	/**
	 * Mapa komponenata, kljucevi su pozicije a vrijednost komponente
	 * na tim pozicijama.
	 */
	Map<RCPosition, Component> komponente = new HashMap<>();
	
	/**
	 * Konstrutkor koji postavlja razmak.
	 * @param razmak
	 */
	public CalcLayout(int razmak) {
		this.razmak = razmak;
	}
	
	/**
	 * Default konstruktor.
	 */
	public CalcLayout() {
		this(0);
	}
	
	/**
	 * Ne zelimo da se ova metoda poziva, stoga
	 * ona baca iznimku.
	 * @throws UnsupportedOperationException
	 */
	@Override
	public void addLayoutComponent(String name, Component comp) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Metoda uklanja sve informacije koje je imala o predanoj komponenti.
	 * Uklanja iz mape komponenti.
	 */
	@Override
	public void removeLayoutComponent(Component comp) {
		komponente.entrySet().removeIf((entrySet) -> comp.equals(entrySet.getValue()));
	}

	/**
	 * Metoda odreduje preferirane dimenzije kontejnera.
	 * Svoju zadacu delegira metodi odrediDimenzije() zbog 
	 * smanjenja redundancije.
	 */
	@Override
	public Dimension preferredLayoutSize(Container parent) {
		return odrediDimenzije(parent, TipFunkcije.PREFERRED);
	}

	/**
	 * Metoda odreduje minimalne dimenzije kontejnera.
	 * Svoju zadacu delegira metodi odrediDimenzije() zbog 
	 * smanjenja redundancije.
	 */
	@Override
	public Dimension minimumLayoutSize(Container parent) {
		return odrediDimenzije(parent, TipFunkcije.MINIMUM);
	}

	/**
	 * Metoda odreduje maksimalne dimenzije kontejnera.
	 * Svoju zadacu delegira metodi odrediDimenzije() zbog 
	 * smanjenja redundancije.
	 */
	@Override
	public Dimension maximumLayoutSize(Container target) {
		return odrediDimenzije(target, TipFunkcije.MAXIMUM);
	}
	
	/**
	 * Metoda koja radi razmještaj, nad svakom komponentom poziva
	 * setBounds(x, y, w, h)
	 */
	@Override
	public void layoutContainer(Container parent) {
		
		for(int i = 0; i < parent.getComponentCount(); i++) {
			Component komponenta = parent.getComponent(i);
			
			Dimension prozor = parent.getSize();
			int sirina = prozor.width;
			int visina = prozor.height;
			
			Insets in = parent.getInsets();
			int left = in.left;
			int right = in.right;
			int top = in.top;
			int bottom = in.bottom;
			//odbaci bordere
			sirina = sirina - (left + right);
			visina = visina - (top + bottom);
			
			//sirina i visina komponente
			int sirinaCelija = (int)Math.round((double)(sirina - razmak * 6) / stupci);
			int odstupanjeSirina = sirina - (sirinaCelija * stupci);
			//+ uvecaj neparne
			//- umanji parne
			int visinaCelija = (int)Math.round((double)(visina - razmak * 4) / redci);
			int odstupanjeVisina = visina - (visinaCelija * redci);
			//+ uvecaj neparne
			//- umanji parne
			
			for(RCPosition key : komponente.keySet()) {
				if(komponente.get(key).equals(komponenta)) {
					int row = key.getRow();
					int column = key.getColumn();
					
					if(key.equals(RCPosition.parse("1,1"))) {
						int x = right;
						int y = top;
						int width = 5 * (sirinaCelija + razmak) - razmak;
						int height = visinaCelija;

						if(odstupanjeVisina > 0) {
							if(key.getRow() % 2 != 0) {
								height = visinaCelija + 1;
								odstupanjeVisina--;
							}
						}else if(odstupanjeVisina < 0) {
							if(key.getRow() % 2 == 0) {
								height = visinaCelija - 1;
								odstupanjeVisina++;
							}
						}
						komponenta.setBounds(x, y, width, height);
						break;
					}else {
						int x = right + (column - 1) * (sirinaCelija + razmak);
						int y = top + (row -1) * (visinaCelija + razmak);
						int width = sirinaCelija;
						int height = visinaCelija;
						if(odstupanjeSirina > 0) {
							if(key.getColumn() % 2 != 0) {
								width = sirinaCelija + 1;
								odstupanjeSirina--;
							}
						}else if(odstupanjeSirina < 0) {
							if(key.getColumn() % 2 == 0) {
								width = sirinaCelija - 1;
								odstupanjeSirina++;
							}
						}
						if(odstupanjeVisina > 0) {
							if(key.getRow() % 2 != 0) {
								height = visinaCelija + 1;
								odstupanjeVisina--;
							}
						}else if(odstupanjeVisina < 0) {
							if(key.getRow() % 2 == 0) {
								height = visinaCelija - 1;
								odstupanjeVisina++;
							}
						}
						komponenta.setBounds(x, y, width, height);
						break;
					}
				}
			}
		}
	}

	/**
	 * Metoda kojom dodajemo komponentu u nas kontejner
	 */
	@Override
	public void addLayoutComponent(Component comp, Object constraints) {
		if(constraints == null || comp == null) {
			throw new NullPointerException();
		}
		if(!(constraints instanceof RCPosition) &&
		   !(constraints instanceof String)) {
			throw new IllegalArgumentException();
		}
		
		RCPosition pozicija = null;
		if(constraints instanceof String) {
			String ogranicenje = (String) constraints;
			pozicija = RCPosition.parse(ogranicenje);
		}else if(constraints instanceof RCPosition) {
			pozicija = (RCPosition) constraints;
		}
		
		if(komponente.containsKey(pozicija)){
			throw new CalcLayoutException();
		}
		
		int red = pozicija.getRow();
		int stupac = pozicija.getColumn();
		if(red < 1 || red > 5) throw new CalcLayoutException();
		if(stupac < 1 || stupac > 7) throw new CalcLayoutException();
		
		komponente.put(pozicija, comp);
	}

	@Override
	public float getLayoutAlignmentX(Container target) {
		return 0;
	}

	@Override
	public float getLayoutAlignmentY(Container target) {
		return 0;
	}

	@Override
	public void invalidateLayout(Container target) {
	}
	
	/**
	 * Metoda koja za dani kontejner vraca preferirane, minimalne ili maksimalne dimenzije.
	 * @param parent predani kontejner za koji racunamo dimenzije
	 * @param tip tip dimenzije koju radunamo: preferirana, minimalna, maksimalna
	 * @return dimenzija
	 */
	private Dimension odrediDimenzije(Container parent, TipFunkcije tip) {
		double sirinaCelije;
		double visinaCelije;
		if(tip.equals(TipFunkcije.MINIMUM)) {
			sirinaCelije = Double.MAX_VALUE;
			visinaCelije = Double.MAX_VALUE;
		}else {
			sirinaCelije = Double.MIN_VALUE;
			visinaCelije = Double.MIN_VALUE;
		}
		
		
		Insets insets = parent.getInsets();
		
		for(int i = 0; i < parent.getComponentCount(); i++) {
			Component komponenta = parent.getComponent(i);
			
			for(RCPosition key : komponente.keySet()) {
	
				if(komponenta.equals(komponente.get(key))) {
					if(key.equals(RCPosition.parse("1,1"))) {
						if(tip.equals(TipFunkcije.PREFERRED)) {
							double sirina = komponenta.getPreferredSize().width;
							double visina = komponenta.getPreferredSize().height;
							
							double izracunajSirinu = (sirina - 4 * razmak) / 5;
							
							if(izracunajSirinu >= sirinaCelije) sirinaCelije = izracunajSirinu;
							if(visina >= visinaCelije) visinaCelije = visina;
							
						}else if(tip.equals(TipFunkcije.MINIMUM)) {
							double sirina = komponenta.getMinimumSize().width;
							double visina = komponenta.getMinimumSize().height;
							
							double izracunajSirinu = (sirina - 4 * razmak) / 5;
							
							if(izracunajSirinu <= sirinaCelije) sirinaCelije = izracunajSirinu;
							if(visina <= visinaCelije) visinaCelije = visina;
							
						}else if(tip.equals(TipFunkcije.MAXIMUM)) {
							double sirina = komponenta.getMaximumSize().width;
							double visina = komponenta.getMaximumSize().height;
							
							double izracunajSirinu = (sirina - 4 * razmak) / 5;
							
							if(izracunajSirinu >= sirinaCelije) sirinaCelije = izracunajSirinu;
							if(visina >= visinaCelije) visinaCelije = visina;
						}
					}else {
						if(tip.equals(TipFunkcije.PREFERRED)) {
							double sirina = komponenta.getPreferredSize().width;
							double visina = komponenta.getPreferredSize().height;
							
							if(sirina >= sirinaCelije) sirinaCelije = sirina;
							if(visina >= visinaCelije) visinaCelije = visina;
							
						}else if(tip.equals(TipFunkcije.MINIMUM)) {
							double sirina = komponenta.getMinimumSize().width;
							double visina = komponenta.getMinimumSize().height;
							
							if(sirina <= sirinaCelije) sirinaCelije = sirina;
							if(visina <= visinaCelije) visinaCelije = visina;
							
						}else if(tip.equals(TipFunkcije.MAXIMUM)) {
							double sirina = komponenta.getMaximumSize().width;
							double visina = komponenta.getMaximumSize().height;
							
							if(sirina >= sirinaCelije) sirinaCelije = sirina;
							if(visina >= visinaCelije) visinaCelije = visina;
						}
					}
				}
			}
		}
		int insetsSirina = insets.left + insets.right;
		int insetsVisina = insets.top + insets.bottom;
		
		int razmaciSirina = (stupci - 1) * razmak;
		int razmaciVisina = (redci -1) * razmak;
		return new Dimension((int)(sirinaCelije * stupci + razmaciSirina + insetsSirina),
				(int)(visinaCelije * redci + razmaciVisina + insetsVisina));
	}

	enum TipFunkcije{
		PREFERRED,
		MINIMUM,
		MAXIMUM
	}
}
