package hr.fer.zemris.java.gui.calc;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.Stack;
import java.util.function.DoubleBinaryOperator;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.Border;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalcValueListener;
import hr.fer.zemris.java.gui.calc.model.MyButton;
import hr.fer.zemris.java.gui.layouts.CalcLayout;
import hr.fer.zemris.java.gui.layouts.RCPosition;

/**
 * Razred koji implementira jednostavan kalkulator, koristeci vlasitit layou manager
 * @author Filip
 *
 */
public class Calculator extends JFrame{
	private static final long serialVersionUID = 1L;
	
	/**
	 * Stog koristen za kalkulator
	 */
	Stack<Object> stack = new Stack<>();
	
	/**
	 * Varijabla pamti je li oznacen inverz ili nije
	 */
	boolean inverz = false;
	
	/**
	 * Model kalkulatora koji je pozadina cijelog sucelja
	 */
	CalcModelImpl calcModel = new CalcModelImpl();

	/**
	 * Konstruktor
	 */
	public Calculator() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		initGUI();
		pack();
	}
	
	/**
	 * Iscrtavanje kalultatora, zelimo stvoriti objekte tipa MyButton i na temelju
	 * mojeg layout managera ih rasporediti unutar prozora
	 */
	private void initGUI() {
		Container cp = getContentPane();
		cp.setLayout(new CalcLayout(7));
		
		//stvori ekran
		JLabel ekran = postaviEkran();
		dodajKomponentu(ekran, 1, 1, cp);
		calcModel.addCalcValueListener(new CalcValueListener() {

			@Override
			public void valueChanged(CalcModel model) {
				ekran.setText(model.toString());
			}
			
		});
		
		//stvori buttone brojeva 0 - 9
		MyButton.stvori(10, stvoriActionListener(Operacija.INSERT_DIGIT, ekran), cp);
		
		//clr
		(new MyButton("clr", new RCPosition(1, 7))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.CLEAR, ekran), cp);
		
		//reset
		(new MyButton("reset", new RCPosition(2, 7))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.CLEAR_ALL, ekran), cp);
		
		// +/-
		(new MyButton("+/-", new RCPosition(5, 4))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.SWAP_SIGN, ekran), cp);
		
		// .
		(new MyButton(".", new RCPosition(5, 5))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.INSERT_DECIMAL_POINT, ekran), cp);
		
		// +
		(new MyButton("+", new RCPosition(5, 6))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.SET_PENDING_BINARY_OPERATION_PLUS, ekran), cp);
		
		// -
		(new MyButton("-", new RCPosition(4, 6))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.SET_PENDING_BINARY_OPERATION_MINUS, ekran), cp);
		
		// *
		(new MyButton("*", new RCPosition(3, 6))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.SET_PENDING_BINARY_OPERATION_PUTA, ekran), cp);
		
		// /
		(new MyButton("/", new RCPosition(2, 6))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.SET_PENDING_BINARY_OPERATION_DIJELI, ekran), cp);
		
		// =
		(new MyButton("=", new RCPosition(1, 6))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.GET_PENDING_BINARY_OPERATION, ekran), cp);
		
		// push
		(new MyButton("push", new RCPosition(3, 7))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.PUSH, ekran), cp);
		
		// pop
		(new MyButton("pop", new RCPosition(4, 7))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.POP, ekran), cp);
		
		// checkBox Inv
		postaviCheckBox(ekran, cp);
		
		//sin
		(new MyButton("sin", new RCPosition(2, 2))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.SIN, ekran), cp);
		
		//cos
		(new MyButton("cos", new RCPosition(3, 2))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.COS, ekran), cp);
		
		//tan
		(new MyButton("tan", new RCPosition(4, 2))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.TAN, ekran), cp);
		
		//ctg
		(new MyButton("ctg", new RCPosition(5, 2))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.CTG, ekran), cp);
		
		//x^n
		(new MyButton("x^n", new RCPosition(5, 1))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.XN, ekran), cp);
		
		//log
		(new MyButton("log", new RCPosition(3, 1))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.LOG, ekran), cp);
		
		//ln
		(new MyButton("ln", new RCPosition(4, 1))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.LN, ekran), cp);
		
		// 1 / x
		(new MyButton("1/x", new RCPosition(2, 1))).inicijalizirajButtonOperacije(stvoriActionListener(Operacija.X, ekran), cp);
		
		
	}

	/**
	 * Metoda main
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(()->{
			new Calculator().setVisible(true);
		});
	}
	
	/**
	 * Metoda postavlja glavnu labelu koja je ekran kalkulatora
	 * @return Ekran kalkulatora
	 */
	private JLabel postaviEkran() {
		JLabel ekran = new JLabel("0");
		ekran.setBackground(new Color(225, 225, 0));
		ekran.setEnabled(true);
		ekran.setOpaque(true);
		ekran.setFont(ekran.getFont().deriveFont(30f));
		ekran.setHorizontalAlignment(SwingConstants.RIGHT);
		Border blackLine = BorderFactory.createLineBorder(Color.black);
		ekran.setBorder(blackLine);
		return ekran;
	}
	
	/**
	 * Metoda dodaje komponentu na poziciji (i, j)
	 * @param ekran
	 * @param i
	 * @param j
	 * @param cp
	 */
	private void dodajKomponentu(JComponent ekran, int i, int j, Container cp) {
		RCPosition pozicija = new RCPosition(i, j);
		cp.add(ekran, pozicija);
	}
	
	/**
	 * Metoda postavlja CheckBox za inverz
	 * @param ekran
	 * @param cp
	 * @return
	 */
	private JCheckBox postaviCheckBox(JLabel ekran, Container cp) {
		JCheckBox inv = new JCheckBox("Inv");
		inv.addActionListener(stvoriActionListener(Operacija.INVERZ, ekran));
		cp.add(inv, new RCPosition(5, 7));
		inv.setFont(new Font("Sans Serif", Font.PLAIN, 25));
		inv.setBackground(new Color(221, 221, 255));
		return inv;
	}

	/**
	 * Metoda tvornica action listenera ovisno o operaciji
	 * @param o operacija za koju stvaramo listener
	 * @param ekran
	 * @return
	 */
	private ActionListener stvoriActionListener(Operacija o, JLabel ekran) {
		if(o.equals(Operacija.INSERT_DIGIT)) {
			return (event) -> {
				MyButton button = (MyButton) event.getSource();
				calcModel.insertDigit(button.getBroj());
				ekran.setText(calcModel.toString());
			};
		}else if(o.equals(Operacija.CLEAR)) {
			return (event) -> {
				calcModel.freezeValue(null);
				calcModel.clear();
			};
		}else if(o.equals(Operacija.CLEAR_ALL)) {
			return (event) -> {
				calcModel.clearAll();
			};
		}else if(o.equals(Operacija.SWAP_SIGN)) {
			return (event) -> {
				calcModel.swapSign();
			};
		}else if(o.equals(Operacija.INSERT_DECIMAL_POINT)) {
			return (event) -> {
				calcModel.insertDecimalPoint();
			};
		}else if(o.equals(Operacija.SET_PENDING_BINARY_OPERATION_PLUS)) {
			return (event) -> {
				if(calcModel.isActiveOperandSet()) {
					double rezultat = calcModel.getPendingBinaryOperation().applyAsDouble(
							calcModel.getActiveOperand(),
							calcModel.getValue());
					calcModel.setActiveOperand(rezultat);
					calcModel.freezeValue(String.valueOf(rezultat));
					
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left + right;
						}
					});
					calcModel.clear();
				}else {
					calcModel.setActiveOperand(calcModel.getValue());
					calcModel.freezeValue(calcModel.getVarijabla());
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left + right;
						}
					});
					calcModel.clear();
				}
			};
		}else if(o.equals(Operacija.SET_PENDING_BINARY_OPERATION_MINUS)) {
			return (event) -> {
				if(calcModel.isActiveOperandSet()) {
					double rezultat = calcModel.getPendingBinaryOperation().applyAsDouble(
							calcModel.getActiveOperand(),
							calcModel.getValue());
					calcModel.setActiveOperand(rezultat);
					calcModel.freezeValue(String.valueOf(rezultat));
					
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left - right;
						}
					});
					calcModel.clear();
				}else {
					calcModel.setActiveOperand(calcModel.getValue());
					calcModel.freezeValue(calcModel.getVarijabla());
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left - right;
						}
					});
					calcModel.clear();
				}
			};
		}else if(o.equals(Operacija.SET_PENDING_BINARY_OPERATION_PUTA)) {
			return (event) -> {
				if(calcModel.isActiveOperandSet()) {
					double rezultat = calcModel.getPendingBinaryOperation().applyAsDouble(
							calcModel.getActiveOperand(),
							calcModel.getValue());
					calcModel.setActiveOperand(rezultat);
					calcModel.freezeValue(String.valueOf(rezultat));
					
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left * right;
						}
					});
					calcModel.clear();
				}else {
					calcModel.setActiveOperand(calcModel.getValue());
					calcModel.freezeValue(calcModel.getVarijabla());
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left * right;
						}
					});
					calcModel.clear();
				}
			};
		}else if(o.equals(Operacija.SET_PENDING_BINARY_OPERATION_DIJELI)) {
			return (event) -> {
				if(calcModel.isActiveOperandSet()) {
					double rezultat = calcModel.getPendingBinaryOperation().applyAsDouble(
							calcModel.getActiveOperand(),
							calcModel.getValue());
					calcModel.setActiveOperand(rezultat);
					calcModel.freezeValue(String.valueOf(rezultat));
					
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left / right;
						}
					});
					calcModel.clear();
				}else {
					calcModel.setActiveOperand(calcModel.getValue());
					calcModel.freezeValue(calcModel.getVarijabla());
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							return left / right;
						}
					});
					calcModel.clear();
				}
			};
				
		}else if(o.equals(Operacija.GET_PENDING_BINARY_OPERATION)) {
			return (event) -> {
				double rezultat = calcModel.getPendingBinaryOperation().applyAsDouble(
						calcModel.getActiveOperand(),
						calcModel.getValue());
				calcModel.clearActiveOperand();
				calcModel.freezeValue(String.valueOf(rezultat));
				calcModel.clear();
			};
		}else if(o.equals(Operacija.PUSH)) {
			return (event) -> {
				stack.push(calcModel.getValue());
			};
		}else if(o.equals(Operacija.POP)) {
			return (event) -> {
				Double vrijednost = (Double) stack.pop();
				if(vrijednost == null) {
					return;
				}
				calcModel.setValue(vrijednost);
				calcModel.freezeValue(String.valueOf(vrijednost));
			};
		}else if(o.equals(Operacija.INVERZ)) {
			return (event) -> {
				inverz = !inverz;
			};
		}else if(o.equals(Operacija.SIN)) {
			return (event) -> {
				double rezultat = 0.;
				if(inverz) {
					rezultat = Math.asin(calcModel.getValue());
				}else {
					rezultat = Math.sin(calcModel.getValue());
				}
				calcModel.setValue(rezultat);
				calcModel.freezeValue(String.valueOf(rezultat));
			};
		}else if(o.equals(Operacija.COS)) {
			return (event) -> {
				double rezultat = 0.;
				if(inverz) {
					rezultat = Math.acos(calcModel.getValue());
				}else {
					rezultat = Math.cos(calcModel.getValue());
				}
				calcModel.setValue(rezultat);
				calcModel.freezeValue(String.valueOf(rezultat));
			};
		}else if(o.equals(Operacija.TAN)) {
			return (event) -> {
				double rezultat = 0.;
				if(inverz) {
					rezultat = Math.atan(calcModel.getValue());
				}else {
					rezultat = Math.tan(calcModel.getValue());
				}
				calcModel.setValue(rezultat);
				calcModel.freezeValue(String.valueOf(rezultat));
			};
		}else if(o.equals(Operacija.CTG)) {
			return (event) -> {
				double rezultat = 0.;
				if(inverz) {
					rezultat = Math.atan(1 / calcModel.getValue());
				}else {
					rezultat = 1 / Math.tan(calcModel.getValue());
				}
				calcModel.setValue(rezultat);
				calcModel.freezeValue(String.valueOf(rezultat));
			};
		}else if(o.equals(Operacija.XN)) {
			return (event) -> {
				if(calcModel.isActiveOperandSet()) {
					double rezultat = calcModel.getPendingBinaryOperation().applyAsDouble(
							calcModel.getActiveOperand(),
							calcModel.getValue());
					calcModel.setActiveOperand(rezultat);
					calcModel.freezeValue(String.valueOf(rezultat));
					
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							if(inverz) {
								return Math.pow(left, 1 / right);
							}else {
								return  Math.pow(left, right);
							}
						}
					});
					calcModel.clear();
				}else {
					calcModel.setActiveOperand(calcModel.getValue());
					calcModel.freezeValue(calcModel.getVarijabla());
					calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {
						@Override
						public double applyAsDouble(double left, double right) {
							if(inverz) {
								return Math.pow(left, 1 / right);
							}else {
								return  Math.pow(left, right);
							}
						}
					});
					calcModel.clear();
				}
			};
		}else if(o.equals(Operacija.LOG)) {
			return (event) -> {
				double rezultat = 0.;
				if(inverz) {
					rezultat = Math.pow(10, calcModel.getValue());
				}else {
					rezultat = Math.log10(calcModel.getValue());
				}
				calcModel.setValue(rezultat);
				calcModel.freezeValue(String.valueOf(rezultat));
			};
 		}else if(o.equals(Operacija.LN)) {
 			return (event) -> {
				double rezultat = 0.;
				if(inverz) {
					rezultat = Math.pow(Math.E, calcModel.getValue());
				}else {
					rezultat = Math.log(calcModel.getValue());
				}
				calcModel.setValue(rezultat);
				calcModel.freezeValue(String.valueOf(rezultat));
			};
 		}else if(o.equals(Operacija.X)) {
 			return (event) -> {
 				double rezultat = 0.;
 	 			rezultat = 1 / calcModel.getValue();
 	 			calcModel.setValue(rezultat);
				calcModel.freezeValue(String.valueOf(rezultat));
 			};
 		}
		return null;
	}
	
	
}
/**
 * Sve podrzane operacije
 * @author Filip
 *
 */
enum Operacija{
	INSERT_DIGIT,
	CLEAR,
	CLEAR_ALL,
	SWAP_SIGN,
	INSERT_DECIMAL_POINT,
	SET_PENDING_BINARY_OPERATION_PLUS,
	SET_PENDING_BINARY_OPERATION_MINUS,
	SET_PENDING_BINARY_OPERATION_PUTA,
	SET_PENDING_BINARY_OPERATION_DIJELI,
	GET_PENDING_BINARY_OPERATION,
	PUSH,
	POP,
	INVERZ,
	SIN,
	COS,
	TAN,
	CTG,
	XN,
	LOG,
	LN,
	X
}
