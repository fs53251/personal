package hr.fer.zemris.java.gui.layouts;

/**
 * Razred iznimke
 * @author Filip
 *
 */
public class CalcLayoutException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public CalcLayoutException(String msg) {
		super(msg);
	}
	
	public CalcLayoutException() {
		
	}
}
