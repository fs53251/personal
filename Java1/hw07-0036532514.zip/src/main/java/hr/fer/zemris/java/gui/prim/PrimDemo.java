package hr.fer.zemris.java.gui.prim;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

/**
 * Razred predstavlja prozor u kojem se prikazuju 2 liste.
 * Model inkrementalno generira prim brojeve pritiskom na 
 * gumb "sljedeci". 
 * @author Filip
 *
 */
public class PrimDemo extends JFrame{
	private static final long serialVersionUID = 1L;

	/**
	 * Kontstruktor u kojem postavljamo lokaciju prozora i velicinu.
	 * Dispose on close nalaze da se zatvaranjem prozora uklone i
	 * zauzeti resursi.
	 */
	public PrimDemo() {
		setLocation(20, 50);
		setSize(300, 200);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		initGUI();
	}
	
	/**
	 * Implementacija ugnjezdene staticke klase koja implementira model dodavanja brojeva.
	 * 
	 * @author Filip
	 *
	 * @param <T>
	 */
	static class PrimListModel<T> implements ListModel<T> {
		/**
		 * Elementi koji se prikazuju u prozorima
		 */
		private List<T> elementi = new ArrayList<>();
		
		/**
		 * Kolekcija promatraca
		 */
		private List<ListDataListener> promatraci = new ArrayList<>();
		
		/**
		 * Varijabla koja cuva zadnji dodani prim broj
		 */
		private int currentNumber = 1;
		
		/**
		 * Metoda koja u kolekciju promatraca registrira novog promatraca
		 */
		@Override
		public void addListDataListener(ListDataListener l) {
			promatraci.add(l);
		}
		
		/**
		 * Metoda koja uklanja iz kolekcije promatraca registriranog promatraca
		 */
		@Override
		public void removeListDataListener(ListDataListener l) {
			promatraci.remove(l);
		}
		
		
		/**
		 * Metoda vraca broj dodanih elemenata u prozor
		 */
		@Override
		public int getSize() {
			return elementi.size();
		}
		
		/**
		 * Metoda koja vraca prim broj s indexom index
		 */
		@Override
		public T getElementAt(int index) {
			return elementi.get(index);
		}
		
		/**
		 * Medoda koja prima element i dodaje ga u prozor.
		 * Objavljuje promjenu svim promatracima.
		 * @param element element koji dodajemo u prozor
		 */
		public void add(T element) {
			int pos = elementi.size();
			elementi.add(element);
			
			ListDataEvent event = new ListDataEvent(this, ListDataEvent.INTERVAL_ADDED, pos, pos);
			for(ListDataListener l : promatraci) {
				l.intervalAdded(event);
			}
		}
		
		/**
		 * Metoda dohvaća sljedeci prim broj koji je na redu
		 * @return sljedeci prim broj
		 */
	    public int next() {
	        while (true) {
	            currentNumber++;
	            if (isPrime(currentNumber)) {
	                return currentNumber;
	            }
	        }
	    }

	    /**
	     * Metoda provjerava je li broj prim ili nije
	     * @param number broj koji se provjerava
	     * @return true ako je broj prim, false inače
	     */
	    private boolean isPrime(int number) {
	        if (number <= 1) {
	            return false;
	        }
	        for (int i = 2; i <= Math.sqrt(number); i++) {
	            if (number % i == 0) {
	                return false;
	            }
	        }
	        return true;
	    }
	}
	
	/**
	 * Metoda koja stvara sučelje
	 */
	private void initGUI() {
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		
		PrimListModel<Integer> model = new PrimListModel<>();
		
		JList<Integer> list1 = new JList<>(model);
		JList<Integer> list2 = new JList<>(model);
		
		JPanel bottomPanel = new JPanel(new GridLayout(1, 0));

		JButton dodaj = new JButton("sljedeći");
		bottomPanel.add(dodaj);
		model.add(1);
		dodaj.addActionListener(e -> {
			model.add(model.next());
		});

		JPanel central = new JPanel(new GridLayout(1, 0));
		central.add(new JScrollPane(list1));
		central.add(new JScrollPane(list2));
		
		cp.add(central, BorderLayout.CENTER);
		cp.add(bottomPanel, BorderLayout.PAGE_END);
	}

	/**
	 * Metoda main koja u posebnoj dretvi EDT poziva korisnicko sucelje
	 * @param args
	 */
	public static void main(String[] args) {

		SwingUtilities.invokeLater(() -> {
			JFrame frame = new PrimDemo();
			frame.pack();
			frame.setVisible(true);
		});
	}
}
