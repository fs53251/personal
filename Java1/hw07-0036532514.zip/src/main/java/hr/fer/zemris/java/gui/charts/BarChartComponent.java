package hr.fer.zemris.java.gui.charts;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.List;

import javax.swing.JComponent;
/**
 * Komponenta koja na svojoj površini stvara prikaz podataka
 * koji su definirani primljenim objektom.
 * @author Filip
 *
 */
public class BarChartComponent extends JComponent{
	private static final long serialVersionUID = 1L;
	/**
	 * Referenca na BarChart koji nam nudi neke postavke oko crtanja grafa
	 */
	public BarChart barChart;
	
	/**
	 * Varijabla koja cuva fiksni razmak
	 */
	int fiksniRazmak = 20;
	
	/**
	 * Varijabla koja cuva velicunu fonta brojeva na osima
	 */
	int brojeviFontVelicina = 17;
	
	/**
	 * Varijabla koja cuva duljinu crtica na osima, crtice jedinicne duljine
	 */
	int duljinaCrteNaOsi = 9;
	
	/**
	 * Varijabla cuva duljine koje zauzima border sa svih stana komponente
	 */
	static Insets insets;
	
	/**
	 * Font koji koristim za prikaz brojeva na osima
	 */
	static Font fontZaPrikazBrojeva;
	
	/**
	 * Velicina fonta koji koristim za opis uz osi
	 */
	static int velicinaFontaOpis;
	
	/**
	 * Boja kojom bojam stupce
	 */
	static Color bojaStupca = new Color(244, 119, 72);
	static Color bojaDefault;
	
	/**
	 * Broj stupaca
	 */
	static int brojStupaca;
	
	/**
	 * Varijabla pamti broj koji zauzima najvise mjesta
	 */
	static int maksimalnaDuljinaBroja = 1;
	
	public static int visina = 0;
	public static int sirina = 0;
	
	/**
	 * Konstruktor
	 * @param bc
	 */
	public BarChartComponent(BarChart bc) {
		this.barChart = bc;
		brojStupaca = bc.getPolje().size();
	}
	
	/**
	 * Metoda crta osi i stupce dijagrama, svoju zadacu delegira
	 * @param g2 objekt za renderiranje oblika
	 */
	private void draw(Graphics2D g2) {
		nacrtajStupceDijagrama(g2);
		nacrtajOsi(g2);
	}
	
	/**
	 * Metoda koja se brine za inicijalizaciju atributa i poziv metode draw koja crta oblike
	 */
	public void paintComponent(Graphics g) {
		BarChartComponent barChartComponent = new BarChartComponent(this.barChart);
		postaviVisinuSirinu();
		
		Graphics2D g2 = (Graphics2D) g;
		postaviFont(g2);
		inicijalizirajMaksimalnuDuljinuBroja();
		insets = this.getInsets();
		
		barChartComponent.draw(g2);
	}
	
	/**
	 * Metoda postavlja font na font izveden iz Graphics2D
	 * @param g2
	 */
	private void postaviFont(Graphics2D g2) {
		fontZaPrikazBrojeva = g2.getFont();
		Font font = g2.getFont();
		velicinaFontaOpis = font.getSize();
	}
	
	/**
	 * Metoda postavlja visinu i sirinu prozora
	 */
	private void postaviVisinuSirinu() {
		visina = this.getSize().height;
		sirina = this.getSize().width;
	}
	
	/**
	 * Metoda prolazi po brojevima na osi i bira najveceh na x osi
	 */
	private void inicijalizirajMaksimalnuDuljinuBroja() {
		for(XYValue obj: barChart.getPolje()) {
			if(String.valueOf(obj.getX()).length()>maksimalnaDuljinaBroja) {
				maksimalnaDuljinaBroja=String.valueOf(obj.getX()).length();
			}
		}
	}

	/**
	 * Metoda crta stupce
	 * @param g2
	 */
	private void nacrtajStupceDijagrama(Graphics2D g2) {
		bojaDefault = g2.getColor();
		
		maksimalnaDuljinaBroja = Integer.toString(barChart.getMaxY()).length();
		
		int zauzetiProstor = fiksniRazmak * 2 + maksimalnaDuljinaBroja * brojeviFontVelicina + velicinaFontaOpis;
		int sirinaIskoristivogProzora = sirina - zauzetiProstor;
		int duljinaPojedinogStupca = sirinaIskoristivogProzora / brojStupaca;
		
		int yMax = barChart.getMaxY();
		int yMin = barChart.getMinY();
		
		int razmakIzmeduDvijeCrtice = barChart.getRazmak();
		
		int zauzetiProsorVisina = insets.top + insets.bottom + 2*fiksniRazmak + maksimalnaDuljinaBroja*brojeviFontVelicina + velicinaFontaOpis;
		int visinaIskoristivogProstora = visina - zauzetiProsorVisina;
		int brojJedinicnihDuljina = (yMax - yMin) / razmakIzmeduDvijeCrtice;
		int razmakPremaJedinicamaEkrana = visinaIskoristivogProstora / brojJedinicnihDuljina;
		
		List<XYValue> polje = barChart.getPolje();
		g2.setColor(bojaStupca);
		int jedinicniRazmak = razmakPremaJedinicamaEkrana / razmakIzmeduDvijeCrtice;
		for(int i = 0; i < brojStupaca; i++) {
			int x = fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + i * duljinaPojedinogStupca;
			
			int rezy1 = razmakPremaJedinicamaEkrana * ((polje.get(i).getY()-yMin)/razmakIzmeduDvijeCrtice);
			int rezy2 = ((polje.get(i).getY() - yMin) % razmakIzmeduDvijeCrtice) * jedinicniRazmak;
			int rezy =  rezy1 + rezy2;
			int y = visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - rezy;
			int width = duljinaPojedinogStupca-1;
			
			int rezh1 = razmakPremaJedinicamaEkrana*((polje.get(i).getY()-yMin)/razmakIzmeduDvijeCrtice);
			int rezh2 = ((polje.get(i).getY()-yMin)%razmakIzmeduDvijeCrtice)*jedinicniRazmak;
			int height = rezh1 + rezh2;
			Rectangle rec = new Rectangle(x, y, width, height);
			g2.setColor(bojaStupca);
			g2.fill(rec);
			g2.setColor(bojaDefault);	
		}
	}

	/**
	 * Metoda crta osi
	 * @param g2
	 */
	private void nacrtajOsi(Graphics2D g2) {
		
		maksimalnaDuljinaBroja = Math.max(String.valueOf(barChart.getMaxY()).length(), maksimalnaDuljinaBroja);
		int zauzetiProsorSirina = maksimalnaDuljinaBroja * brojeviFontVelicina + velicinaFontaOpis + fiksniRazmak*2;
		int sirinaIskoristivogProstora = sirina - zauzetiProsorSirina;
		int duljinaStupca = sirinaIskoristivogProstora / brojStupaca;
		
		
		//x os
		String xLabel = barChart.getOpisX();
		int strWidth = (int) g2.getFontMetrics().getStringBounds(xLabel, g2).getWidth();
		nacrtajOsX(g2);
		
		
		//opis x
		nacrtajOpisX(g2, xLabel, strWidth);

		//brojke ispod x osi
		Font currFont = g2.getFont();
		g2.setFont(fontZaPrikazBrojeva);
		nacrtajBrojeveIspodOsiX(g2, duljinaStupca);
		g2.setFont(currFont);
		
		// crtice na x osi
		nacrtajCrteNaOsiX(g2, duljinaStupca);
				
				
		//strelica
		nacrtajStrelicu(g2, duljinaStupca);
		
		// doljne krilce
		nacrtajDonjeKrilce(g2, duljinaStupca);
		
		// gornja krilce
		nacrtajGornjeKrilce(g2, duljinaStupca);

		//y os
		String yLabel = barChart.getOpisY();
		strWidth = (int) g2.getFontMetrics().getStringBounds(yLabel, g2).getWidth();
		nacrtayOsY(g2);
		

		// opis y
		nacrtajOpisY(g2, currFont, yLabel, strWidth);

		// brojke uz y os
		g2.setFont(fontZaPrikazBrojeva);

		int yMax = barChart.getMaxY();
		int yMin = barChart.getMinY();
		int brojcaniRazmak = barChart.getRazmak();

		int zauzetiProsorVisina = insets.top + insets.bottom + maksimalnaDuljinaBroja * brojeviFontVelicina + velicinaFontaOpis + fiksniRazmak*2;
		int visinaIskoristivogProstora = visina - zauzetiProsorVisina;
		int brojJedinicnihDuljina = (yMax - yMin) / brojcaniRazmak;
		
		int razmakPremaJedinicamaEkrana = visinaIskoristivogProstora / brojJedinicnihDuljina;
		nacrtajBrojevePoredOsiY(g2, currFont, yMax, yMin, brojcaniRazmak, razmakPremaJedinicamaEkrana);

		// crtice na y osi
		nacrtajCrteNaOsiY(g2, yMax, brojcaniRazmak, razmakPremaJedinicamaEkrana);

		//strelica
		nacrtajStrelicuY(g2, razmakPremaJedinicamaEkrana, brojcaniRazmak, yMax);
		
		// ljevo krilce
		nacrtajLijevoKrilce(g2, razmakPremaJedinicamaEkrana, yMax, brojcaniRazmak);
		
		// desno krilce
		nacrtajDesnoKrilce(g2, razmakPremaJedinicamaEkrana, yMax, brojcaniRazmak);
		
	}

	private void nacrtajDesnoKrilce(Graphics2D g2, int razmakPremaJedinicamaEkrana, int yMax,
			int brojcaniRazmak) {
		int x1 = fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left;
		int y1 = visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom - razmakPremaJedinicamaEkrana * (yMax / (brojcaniRazmak)) - duljinaCrteNaOsi*2;
		int x2 = fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left + duljinaCrteNaOsi;
		int y2 = visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
				- razmakPremaJedinicamaEkrana * (yMax / (brojcaniRazmak))-duljinaCrteNaOsi;
		g2.drawLine(x1, y1, x2, y2);
	}

	private void nacrtajLijevoKrilce(Graphics2D g2, int razmakPremaJedinicamaEkrana, int yMax,
			int brojcaniRazmak) {
		g2.drawLine(fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- razmakPremaJedinicamaEkrana * (yMax / (brojcaniRazmak)) - duljinaCrteNaOsi*2,

				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left - duljinaCrteNaOsi,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- razmakPremaJedinicamaEkrana * (yMax / (brojcaniRazmak))- duljinaCrteNaOsi);

	}

	private void nacrtajStrelicuY(Graphics2D g2, int razmakPremaJedinicamaEkrana, int brojcaniRazmak, int yMax) {
		g2.drawLine(fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- razmakPremaJedinicamaEkrana * (yMax / (brojcaniRazmak)),

				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- razmakPremaJedinicamaEkrana * (yMax / (brojcaniRazmak)) - duljinaCrteNaOsi * 2);

	}

	private void nacrtajCrteNaOsiY(Graphics2D g2, int yMax, int brojcaniRazmak, int razmakPremaJedinicamaEkrana) {
		for (int i = 0; i < yMax / brojcaniRazmak + 1; i++) {
			g2.drawLine(fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left,

					visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
							- razmakPremaJedinicamaEkrana * i,

					fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
							- duljinaCrteNaOsi,

							visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
							- razmakPremaJedinicamaEkrana * i);
		}
	}

	private void nacrtajBrojevePoredOsiY(Graphics2D g2, Font currFont, int yMax, int yMin, int brojcaniRazmak, int razmakPremaJedinicamaEkrana) {
		for (int i = yMin, j = 0; i <= yMax; i = i + brojcaniRazmak, j++) {
			int xOS=fiksniRazmak + velicinaFontaOpis;
			if(String.valueOf(i).length()<maksimalnaDuljinaBroja) {
				xOS=xOS+(brojeviFontVelicina/2)*(maksimalnaDuljinaBroja-String.valueOf(i).length());
			}
			g2.drawString(String.valueOf(i), xOS,
					visina - fiksniRazmak- velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - razmakPremaJedinicamaEkrana * j - insets.bottom);
		}
		g2.setFont(currFont);
	}

	private void nacrtajOpisY(Graphics2D g2, Font currFont, String yLabel, int strWidth) {
		Font font = new Font(null, currFont.getStyle(), currFont.getSize());
		AffineTransform affineTransform = new AffineTransform();
		affineTransform.rotate(Math.toRadians(-90), 0, 0);
		Font rotatedFont = font.deriveFont(affineTransform);
		g2.setFont(rotatedFont);
		g2.drawString(yLabel, fiksniRazmak + insets.left,
				(visina - 2 * fiksniRazmak - maksimalnaDuljinaBroja * brojeviFontVelicina - velicinaFontaOpis - strWidth
						- insets.top - insets.left) / 2 + fiksniRazmak * 2 + maksimalnaDuljinaBroja * brojeviFontVelicina
						+ velicinaFontaOpis);
		g2.setFont(currFont);
	}

	private void nacrtayOsY(Graphics2D g2) {
		g2.drawLine(fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left,
				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- insets.top,
				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left,
				fiksniRazmak - insets.top);
	}

	private void nacrtajGornjeKrilce(Graphics2D g2, int duljinaStupca) {
		g2.drawLine(
				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
						+ duljinaStupca * (barChart.getPolje().size()) + duljinaCrteNaOsi * 2,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- insets.top,

				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
						+ duljinaStupca * (barChart.getPolje().size()) + duljinaCrteNaOsi,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- insets.top - duljinaCrteNaOsi);
	}

	private void nacrtajDonjeKrilce(Graphics2D g2, int duljinaStupca) {
		g2.drawLine(
				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
						+ duljinaStupca * (barChart.getPolje().size()) + duljinaCrteNaOsi * 2,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- insets.top,

				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
						+ duljinaStupca * (barChart.getPolje().size()) + duljinaCrteNaOsi,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- insets.top + duljinaCrteNaOsi);

	}

	private void nacrtajStrelicu(Graphics2D g2, int duljinaStupca) {
		g2.drawLine(
				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
						+ duljinaStupca * (barChart.getPolje().size()),

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- insets.top,

				fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
						+ duljinaStupca * (barChart.getPolje().size()) + duljinaCrteNaOsi * 2,

				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
						- insets.top);

	}

	private void nacrtajCrteNaOsiX(Graphics2D g2, int duljinaStupca) {
		for (int i = 1; i <= barChart.getPolje().size() + 1; i++) {
			g2.drawLine(
					fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
							+ duljinaStupca * (i - 1),
					visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
							- insets.top,
					fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left
							+ duljinaStupca * (i - 1),
					visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom
							- insets.top + duljinaCrteNaOsi);
		}
	}

	private void nacrtajBrojeveIspodOsiX(Graphics2D g2, int duljinaStupca) {
		for (int i = 0; i < barChart.getPolje().size(); i++) {
			g2.drawString(String.valueOf(barChart.getPolje().get(i).getX()),
					fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + duljinaStupca / 2
							+ duljinaStupca * i + insets.left,
					visina - fiksniRazmak - velicinaFontaOpis - insets.bottom - insets.top);
		}
	}

	private void nacrtajOpisX(Graphics2D g2, String xLabel, int strWidth) {
		g2.drawString(xLabel,
				((sirina - 2 * fiksniRazmak - maksimalnaDuljinaBroja * brojeviFontVelicina - velicinaFontaOpis) - strWidth) / 2
						+ maksimalnaDuljinaBroja * brojeviFontVelicina + velicinaFontaOpis + fiksniRazmak,
				visina - fiksniRazmak);
	}

	private void nacrtajOsX(Graphics2D g2) {
		g2.drawLine(fiksniRazmak + velicinaFontaOpis + maksimalnaDuljinaBroja * brojeviFontVelicina + insets.left,
				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja*brojeviFontVelicina - insets.bottom -insets.top,
				sirina - fiksniRazmak - insets.right,
				visina - fiksniRazmak - velicinaFontaOpis - maksimalnaDuljinaBroja * brojeviFontVelicina - insets.bottom - insets.top
				);
	}
}
