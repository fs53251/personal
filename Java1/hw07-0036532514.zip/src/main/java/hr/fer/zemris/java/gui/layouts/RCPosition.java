package hr.fer.zemris.java.gui.layouts;

import java.util.Objects;

public class RCPosition {
	private int row;
	private int column;
	
	public RCPosition(int row, int column) {
		this.row = row;
		this.column = column;
	}
	
	public RCPosition() {
		this.row = 0;
		this.column = 0;
	}

	public int getRow() {
		return row;
	}

	public int getColumn() {
		return column;
	}
	
	public static RCPosition parse(String text) {
		String[] pozicija = text.split(",");
		if(pozicija.length == 2) {
			try {
				int row = Integer.parseInt(pozicija[0].trim());
				int column = Integer.parseInt(pozicija[1].trim());
				return new RCPosition(row, column);
			}catch(Exception e) {
				System.out.println("Nemogu isparsirati argumente kao dva cijela broja.");
				throw new IllegalArgumentException();
			}
		}else {
			System.out.println("Predano više od dva parametra"
					+ "\nOčekujem: row,column");
		}
		return null;
	}

	@Override
	public int hashCode() {
		return Objects.hash(column, row);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RCPosition other = (RCPosition) obj;
		return column == other.column && row == other.row;
	}
}
