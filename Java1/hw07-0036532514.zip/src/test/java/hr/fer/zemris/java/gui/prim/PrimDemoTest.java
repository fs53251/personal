package hr.fer.zemris.java.gui.prim;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.gui.prim.PrimDemo.PrimListModel;

public class PrimDemoTest {
	PrimListModel<Integer> model = new PrimListModel<>();
	
	@Test
	public void inicijalniPrim() {
		assertEquals(2, model.next()); 
		assertEquals(3, model.next()); 
		assertEquals(5, model.next()); 
		assertEquals(7, model.next()); 
		assertEquals(11, model.next()); 
		assertEquals(13, model.next()); 
		assertEquals(17, model.next()); 
		assertEquals(19, model.next()); 
		assertEquals(23, model.next()); 
		assertEquals(29, model.next()); 
		assertEquals(31, model.next()); 
		assertEquals(37, model.next()); 
		assertEquals(41, model.next()); 
		assertEquals(43, model.next()); 
		assertEquals(47, model.next()); 
		assertEquals(53, model.next()); 
	}
}
